---
name: "drmm-alert-noise-review"
description: Read-only alert fatigue review for a Datto RMM account or chosen sites. Opens with a start-up note (version, expected wait). Reads recent resolved and open alerts, groups them into signatures by monitor type, device and detail, and measures how each group behaves — volume, self-resolve rate and speed, flapping, whether it fires at the same time every day, whether it opens tickets nobody needed, whether it fires on dead devices. Gives every group a transparent noise score and a specific tuning recommendation (raise the threshold, add a duration, move a schedule, stop ticket creation, take the policy off retired gear) — while protecting alerts that are noisy but real, such as a disk that keeps filling. Use this whenever the user asks about alert noise, alert fatigue, too many alerts, false positives, flapping or recurring alerts, which monitors to tune, why the alert queue is so long, or how to make the real alerts stand out. For why one device keeps alerting, use drmm-device-quick-look instead.
metadata:
  version: "0.1.13"
  last_updated: "2026-10-05"
  type: "Datto RMM Skill"
  stage: "alpha"
  execution: "read-only"
  author: "Kaseya Automation Content Team"
compatibility: Requires the Datto RMM connector (drmm v0.4.0 tool set — the "Datto RMM" desktop extension or the datto-mcp remote server). See "Tools" below.
---

# Alert Noise Review

## Run banner and readme

A full run takes several minutes, and in Claude Desktop the user sees only a collapsed
progress box while tools run. So the skill's output has two parts: a short start-up note,
written as a chat message once you have read this file and before the first Datto RMM
call (step 0 below), and then the report. The start-up note is these four lines:

```
Alert Noise Review v0.1.13 · last updated 5 Oct 2026 · read-only · Datto RMM
Developer note: alpha release by the Kaseya Automation Content Team. Check results before acting on them, and report anything odd.
Starting: reading open and resolved alerts. This can take a few minutes on a large account; any permission prompts are for read-only Datto RMM tools.
Tip: say "drmm-alert-noise-review readme" for the full guide and all parameters.
```

Then gather the data and write the report. Its Coverage line carries the version and the
alpha mark too, so the reader still sees them if the note scrolls away.

**Readme mode.** When the message contains the word `readme` (with or without a slash) or
asks you to explain this skill: `readme` is a mode word, not a file — do not search for a
README file. Open `references/readme-guide.md` in this skill's folder and follow it.
Gather no data and call no Datto RMM tools.

---

## Goal

Answer one question for whoever owns the monitoring policies:

> **Which alerts cost us attention without telling us anything, and what exactly should we
> change so the real ones stand out?**

The output is a short, ranked tuning list — each item a change someone can make in a
monitoring policy this week, with the volume it would remove. It is not a histogram of
alert types.

The failure this skill most needs to avoid is **recommending that a real problem be
silenced.** A disk-space alert that fires every night because the disk really is filling
is not noise; it is an unfixed problem, and it goes in its own section. Every
recommendation is checked against the protected list below before it is made.

Alert Noise Review is diagnostic only. It never mutes, resolves or edits anything, and
cannot change a monitoring policy — the connector has no policy tools.

---

## Tools

All calls go through the **Datto RMM connector** (drmm v0.4.0). Use these and nothing else.

| Purpose | Tool | Notes |
|---|---|---|
| Resolved alerts | `list_alerts` `status: "resolved"`, `account_wide: true` or `site_uid` | Newest first, **no date filter**. Max 50 per page (~35 KB). `count` is the page size here, not a total — follow `next_page`. |
| Open alerts | `list_alerts` `status: "open"`, same scope | For muted and long-open alerts. |
| Sites | `list_sites` | Names; per-site device totals for rates. |
| Dead-gear check | `list_devices` with filter `Offline > 1 Week` | Resolve the filter by name with `list_device_filters`. Device set only. |

### Page sizes

Claude Desktop rejects a tool result over about 50 KB. Per call, never request more than:
devices 100, open alerts 100, resolved alerts 50, sites 100, device software 250 (a Mac
needs two or more pages), patches 100, components 50. If the same page fails twice with
HTTP 500, one record in that range is unreadable: retry the range in smaller pages to read
around it, and report the range. Measured sizes: `references/connector-notes.md`.

---

## Parameters

Apply the default when not given, and state any non-default value in the coverage
footer. Users set these in plain words ("only Northwind Legal", "look back 14 days").

| Parameter | Default | Effect |
|---|---|---|
| `days` | 7 | Review window. 14 or 30 give better time-of-day evidence but cost more pages. |
| `sites` | none | Restrict to named sites. |
| `min_events` | 5 | Groups smaller than this are not scored. |
| `triage_minutes` | 5 | Minutes a person spends per ticketed alert — used only for the hours estimate. |
| `timezone` | the user's | The connector has no account timezone; ask or use UTC and say so. Time-of-day patterns depend on it. |
| `html` | off | On when the user's message contains the word `html` ("drmm-alert-noise-review html", "as HTML"). Same run, delivered as a styled HTML page: read `references/html-report.md` before writing the report. |

**Reading parameters.** Text in quotes is one value, taken exactly (`"Google Chrome"`,
`sites "- Datto Devices"`). Without quotes, a value runs until the next parameter word
(`version`, `sites`, `days`, `html`, `readme` …, or "for"/"at" before a site). Multi-word
names match as a whole phrase, case-insensitively, never word by word. If a word could
belong to two values, ask once before reading data. Coverage echoes what was understood
(Searched for "Google Chrome" · sites: Northwind Legal).

**Advanced — budgets.** Change these only when a run stops early on a large account.

| Budget | Default | Effect |
|---|---|---|
| `page_budget` | 60 | Resolved-alert pages (at 50 — 3,000 alerts) before stopping; the window actually covered is reported. |
| `open_page_budget` | 4 | Open-alert pages. |

---

## Scope boundary

| In scope | Out of scope |
|---|---|
| Alert behaviour patterns and tuning | Fixing the underlying problem → `drmm-device-quick-look` |
| Tickets raised by noise | Alerts that should have a ticket and don't → `alert-to-ticket-pipeline` |
| Alerts on long-offline gear | Removing that gear → `drmm-stale-and-ghost-devices` |

---

## Data gathering

0. **Post the start-up note** from "Run banner and readme" as a chat message, before
   any Datto RMM call below. Then continue straight away; do not wait for a reply.
   Between steps, a one-line progress note is fine ("Devices read, reading alerts next").

1. `list_alerts status resolved` (account-wide, or per site), `max: 50`, paged until the
   oldest alert on a page is older than `days`, or `page_budget` is reached. If the budget
   ends first, the window is **shorter than asked**: report the time actually covered and
   compute all rates over that span, never over `days`.
2. `list_alerts status open`, paged to `open_page_budget`.
3. `list_device_filters default` → `Offline > 1 Week` and `All Server O/S`; page
   `list_devices filter_id` for each → dormant device set and server set. Alerts carry no
   OS or class, and `device_type` is the chassis type (a Windows Server shows as
   `Main System Chassis`), so "on a server" below always means "in the server set".
   Network devices: page `All Network Devices` the same way when a protected rule needs it.
4. `list_sites` for names.

Retry a failing page once; on a second failure stop paging that collection and mark it
partial.

### Gotchas

Confirmed against a live drmm v0.4.0 connector. The full field list for each tool is in
`references/connector-notes.md`; read it when a field you need is missing or a value looks wrong.

- `resolution.by` of `CAG` or `AUTORESOLVER`, compared case-insensitively, means the alert
  cleared itself; anything else was resolved by a person or an integration. Record the
  values seen in coverage.
- An alert is **ticketed** when `ticketNumber` is non-empty **or** `actions` contains
  `TICKET_CREATED`; both occur without the other.
- `diagnostics` is absent on offline, `perf_mon_ctx` and component alerts.
- `priority` is the monitor's setting, not severity.
- Alerts have no date filter and come newest first. Report the window actually covered.

---

## Computation

### Signatures

Group alerts by **signature** = `monitor_type` + **key** + `device_uid`:

| monitor_type | Key taken from `diagnostics` |
|---|---|
| `perf_disk_usage_ctx` | drive letter or volume |
| `eventlog_ctx` | event source + event ID |
| `srvc_status_ctx`, service monitors | service name |
| `comp_script_ctx` | the diagnostics text with numbers removed (first 60 chars) when present; usually absent in v0.4.0 → none |
| `patch_ctx` | result code |
| `perf_resource_usage_ctx` | `cpu` or `memory` if stated, else none. Separately record the **first process** in the list (see "Top process") |
| `online_offline_status_ctx` | none |
| anything else | none |

Then roll signatures up into **patterns** = `monitor_type` + key across devices, per site
and account-wide. Recommendations are made on patterns (a policy change affects many
devices), with the top devices named.

### Behaviour per group

- **Volume** — events in the window; events per day.
- **Self-resolve rate** — share resolved by `CAG` or `AUTORESOLVER` (any case).
- **Median duration** — `resolution.on − timestamp`.
- **Flapping** — the signature raised 3+ times in any 24 hours, each resolving within 60
  minutes.
- **Time-of-day** — 60 % or more of events start inside the same 2-hour local window, on
  3 or more different days. Name the window.
- **Ticket burden** — ticketed events (see above) that self-resolved within 15 minutes.
- **Dead gear** — events on devices in the `Offline > 1 Week` set.
- **Muted** — open alerts with `muted: true` in the pattern.
- **Top process** (`perf_resource_usage_ctx` only) — the first process named in
  `diagnostics` (`AEMAgent.exe : 73 % …`). Share of the group's events per top process.
  When the Datto RMM agent (`AEMAgent.exe`, `CagService.exe`, `RMM.WebRemote.exe`) is the
  top process in 50 % or more of events, the group is **agent-caused**. Live check
  (30 Sep 2026): the CPU monitor produced 99 % of all resolved alerts in 6.8 days, and the
  agent topped 81–89 % of them on all three noisy devices.
- **Delivery errors** — events whose `actions` contain `TICKET_CREATION_ERROR` or any code
  with `ERROR` / `FAIL` (seen live).
- **Stacked monitors** — the same `monitor_type` raising 2 or more alerts on one device
  within the same 5 seconds, at 3 or more separate moments. Count distinct device-moments
  against alerts. Live check (30 Sep 2026): 1,856 CPU alerts were 842 moments, with up to 22
  alerts in one second on one server, and one workstation going offline raised 6 offline
  alerts. It means several copies of one monitor (account, site and device policies) apply to
  the device.

### Noise score (0–100)

A transparent ranking aid, not a measurement:

```
noise = 35 × self-resolve rate
      + 25 × share resolved within 15 minutes
      + 20 × min(1, events per device per day ÷ 3)
      + 10 × (1 if flapping or time-of-day, else 0)
      + 10 × share with a ticket that self-resolved
```

Groups under `min_events` are not scored. A pattern that exists only as **open** alerts —
nothing has resolved, which is typical of offline alerts on dead gear — cannot be scored
either: rank it in Tune first by volume and label it "not scored (none has resolved)". Show the score with its two biggest inputs, so
a reader can argue with it.

### Protected — never recommend silencing

A pattern matching any of these goes to **Noisy but real**, whatever its score:

- `perf_disk_usage_ctx` on a fixed volume where any event in the group shows under 10 %
  free, or free space falls across the window.
- Anything mentioning backup failed, paused, not registered or not detected;
  `backup_management_ctx`.
- `eventlog_ctx` Ntfs 55 (file system corruption), Kernel-Power 41 / EventLog 6008 on a
  server (unexpected shutdown).
- AD replication, RAID / SMART / disk health, UPS on battery.
- `online_offline_status_ctx` on a server or network device that is **not** in the
  dormant set.
- `patch_ctx` with result `0x80070070` (disk full) or repeated failure on a server.

For these the recommendation is to **fix the cause** (with `→ drmm-device-quick-look` for the
worst device), never to raise a threshold.

### Recommendations

One recommendation per pattern, the first that fits:

| Pattern behaviour | Recommendation |
|---|---|
| Agent-caused (the RMM agent tops the process list in ≥ 50 % of events) | Say the monitor is mostly measuring the Datto RMM agent itself. Exclude the agent processes from the CPU monitor or raise its threshold for them, and check what the agent is doing at those times (audits, components, remote sessions) — if the load is abnormal, open a case with Datto support. A duration alone hides the symptom. |
| Dead gear is most of the volume | Remove the monitoring policy from retired devices, or retire them → `drmm-stale-and-ghost-devices`. |
| Self-resolves within 15 min, median duration short | Add a duration ("alert only if the condition lasts [n] minutes", n just above the median duration). |
| Flapping around a threshold | Raise the threshold or add hysteresis; state the values seen in `diagnostics` if any. |
| Time-of-day cluster | Exclude or reschedule around that window; name the likely cause (backup, AV scan, patch window) as a hypothesis. |
| Tickets on self-resolving alerts | Turn off ticket creation for this monitor, or require the alert to persist before a ticket. |
| High volume, low self-resolve, no ticket, never acted on | Review whether anyone needs this monitor at all; lower its priority. |
| Muted but still firing | Decide: fix, tune or remove — muting hides it from everyone. |

**Stacked monitors** adds a line to a pattern's recommendation; it never replaces it:
"keep one [monitor] per device — n alerts were m moments; removes ~(n − m)/week". It applies
to protected patterns too, because it removes duplicates, not the signal.

**Volume removed** per recommendation = events in the pattern that the change would have
prevented, over the window, scaled to per week. The **hours estimate** = ticketed noise
events × `triage_minutes`, labelled "estimate".

### Verdict

- **NOISY** — the top five patterns account for over 50 % of all alerts in the window.
- **SOME NOISE** — any scored pattern above 60.
- **CLEAN** — neither.

---

## Output

The start-up note is already written; write the report below it. The reader is a
technician deciding what to do next: lead with the answer, keep lines short, and put
how the data was read at the end.

```markdown
# Alert Noise Review: [account | sites]
**[date time tz]** · window [start]–[end] ([n] days covered) · [n] alerts read

## [🔴|🟠|🟢] Verdict: [NOISY|SOME NOISE|CLEAN]
[The top patterns' share of volume, in one or two sentences.]

---

## Tune first
| # | Removes | Task | Why |
|---|---|---|---|
| 1 | ~[n] a week | **[Verb] [change] on [monitor]** | score [n] ([two biggest inputs]); top devices [a, b, c] |

**Where to start on item 1:** [the policy setting to change first].

---

## Noisy but real — fix the cause, do not tune
- **[pattern on device]** [volume and evidence] → drmm-device-quick-look

---

## What else we found
**Ticket burden**
- [tickets opened by self-resolving alerts; hours estimate; delivery errors]

**Dead gear**
- [alerts on devices offline over 7 days, by site]

**Muted**
- [open muted alerts by pattern]

## By site
| Site | Alerts | Devices | Per device |
|---|---|---|---|

---

## Coverage
| Area | Status |
|---|---|
| Resolved alerts · Open alerts · Groups scored | [complete, or partial and how far] |

[Window covered], [timezone] · [n] read-only calls · Alert Noise Review v[version] (alpha)
Monitoring policy names are not exposed; recommendations are by monitor type.
```

**Format.** Markdown laid out like the template — not a code block, not plain text: a `#`
title, a bold date line, the verdict as a `##` heading with its colour dot, `---` between
sections, the action list as a table, and Coverage as an Area | Status table. Omit any
section that would be empty.

**Writing rules.**
- Lead with the answer: one or two sentences under the verdict, with the key device names
  and numbers in **bold**.
- Action rows start with a verb ("Free up disk on…", "Reboot…", "Deploy…"). The Why cell
  holds the evidence and the ticket number or "No ticket." in one or two short sentences.
- Under the action table, a **Where to start on item 1:** line names the concrete first
  check. Add one for item 2 only when it needs its own.
- Other sections use a bold lead line with short bullets under it, one fact per bullet.
- Raw field and monitor names (`perf_disk_usage_ctx`, `patch.status`) appear only in "Data
  you shouldn't trust" and Coverage. Elsewhere say "disk alerts", "reboot pending".
- Dates as "11 Sep"; times in the user's timezone.
- End Coverage with one line: window or scope, timezone and where it came from, `[n]
  read-only calls`, and the skill name and version. If a fuller run would close a gap,
  offer it in one closing sentence after Coverage — never more than one.

Tune first is capped at 10 rows. Each names the top three devices or sites in the
pattern.

**Coverage** — Area | Status rows and the closing line, covering: pages read, window actually covered, alerts read (resolved / open), groups
scored, `resolution.by` values seen, timezone, non-default parameters, and: "Monitoring
policy names are not exposed by the connector; recommendations are by monitor type."

**HTML.** With `html` on, build the page from `assets/report-template.html` as
`references/html-report.md` describes, instead of the Markdown report.

See `references/example-output.md` for the shape.

---

## Handoffs

| Finding | Hand off to |
|---|---|
| Noisy but real on a device | `drmm-device-quick-look` |
| Noise from retired gear | `drmm-stale-and-ghost-devices` |
| Real alerts with no ticket | `alert-to-ticket-pipeline` |
| When did a pattern start? | `drmm-device-timeline` |

---

## Quit conditions

- The first resolved-alert page fails twice.
- Zero alerts in scope — report it; a quiet account is CLEAN only if pages were read.

---

## Known gaps

What this skill cannot do yet, and how to tell that it worked, is in
`references/known-gaps.md`. Read it in readme mode, or when the user asks about limits.
