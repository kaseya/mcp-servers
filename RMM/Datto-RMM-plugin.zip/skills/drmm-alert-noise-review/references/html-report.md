# Alert Noise Review — HTML report

Read this only when `html` is set. The data, rules and ranking are exactly those of the
normal run; only the presentation changes. Every number comes from the run — never invent
a value to fill a slot. Leave a section out rather than fill it.

## Build

1. Read `assets/report-template.html`. Copy its `<head>`, including the whole `<style>`
   block, **unchanged**. Add no CSS, scripts or other external resources; the page must read
   correctly without the Google Fonts link.
2. Rebuild `<body>` with the template's elements and class names, section by section, from
   this run's data (mapping below). Escape `&`, `<` and `>` in names.
3. Set `<title>` to `Alert Noise Review: [scope], [weekday date]` and end with
   `<footer>Alert Noise Review v[version] (alpha) · [scope] · times in [timezone] · [n] read-only calls</footer>`.
4. **Check before delivering.** The page starts with exactly `<!DOCTYPE html>`,
   `<html lang="en">`, `<head>`, `<meta charset="utf-8">`, nothing between them; it has one
   `<html>`, one `<head>`, one `<style>`, one `<body>`, and no `<script>`. If anything is out
   of place, rebuild from the template. With code execution, check with a short script.
5. Deliver it as an **HTML artifact** with the same title; where artifacts are not
   available, save `alert-noise-review-[scope]-[yyyy-mm-dd].html` and give the user the file.
6. In the chat, write at most three lines: the verdict sentence, action 1, and the version
   line. Do not repeat the Markdown report.

## Mapping

| Template element | Fill with |
|---|---|
| `header.verdict` | Colour: red NOISY, amber SOME NOISE, green CLEAN. Stats: alerts read, top pattern share, dead-gear alerts, tickets created, groups scored. |
| `.warn` | A window shorter than asked, or partial pulls. |
| Tune first `.plan .card` | Up to 3 cards: change as title, monitor · removes per week, facts with score inputs, why. |
| Noisy but real | Table: pattern, evidence, next skill. |
| What else we found | Left panel: dead gear by site as `.offrow` bars. Right panel: ticket burden and small groups as a `.defer` list. |
| Data quality and coverage | `details` "Data-quality flags ([n])" with `.dq` items; `details` "Coverage ([n] API calls)" with four `.cov` boxes (class `partial` when partial) and a note. |
