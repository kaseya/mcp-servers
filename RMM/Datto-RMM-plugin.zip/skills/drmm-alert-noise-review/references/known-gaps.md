# Alert Noise Review — known gaps and success measures

## Known gaps

- No date filter on alerts: a busy account covers only hours per page. Server-team ask:
  `from`/`until` on `list_alerts`.
- Monitoring policies and monitor thresholds are not exposed; recommendations name the
  monitor type, not the policy. Server-team ask: read-only policy tools.
- `diagnostics` is free text; key extraction is heuristic.
- No history beyond one window: trends across runs need the user to rerun.

## Measuring whether this worked

- A policy owner can make every Tune first change without further analysis.
- No protected signal is ever recommended for silencing.
- Rates always use the window actually covered.
- Alert volume drops on the next run for the patterns that were tuned.
