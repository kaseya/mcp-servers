# Alert Noise Review — connector notes

Reference for the drmm v0.4.0 Datto RMM connector, measured live on 30 Sep 2026.
Read when a field you need is missing, a value looks wrong, or a page fails.

## Page sizes

A tool result larger than about 50 KB fails in Claude Desktop, so never request more than
these per call (sizes measured live on 30 Sep 2026):

| Call | Max per page | Size at that max |
|---|---|---|
| `list_devices` | 100 | ~45 KB |
| `list_alerts` open | 100 | ~45 KB |
| `list_alerts` resolved | 50 | ~35 KB |
| `list_sites` | 100 | ~35 KB (150 measured ~50 KB — too close to the limit) |
| `list_device_software` | 250 | ~25 KB on Windows; macOS lists run past 250 rows of system components |
| `list_patches` | 100 | small |
| `list_components` | 50 | ~23 KB |

If the same page fails twice with HTTP 500, one record in that range is unreadable (seen live:
sites 2,550–2,599 failed at every page size). Retry the range in smaller pages — half, then a
tenth — to recover the rest, and report the range that could not be read.

## Fields by tool

From a live drmm v0.4.0 connector: `alertUid`, `priority` (`Critical`, `High`,
`Moderate`, `Low`, `Information` — reflects how the monitor was configured, not
severity), `timestamp` (epoch ms, when raised), `resolved`, `resolution{by, on}` (`on` is
epoch ms; `by` seen: `CAG` and `AUTORESOLVER` on alerts that cleared by themselves),
`muted`, `ticketNumber` (null or empty string when none), `diagnostics` (monitor output
text — **absent** on offline, `perf_mon_ctx` and component alerts), `monitor_type`,
`source{device_uid, device_name, site_uid, site_name}`, `actions` (codes, seen:
`EMAIL_SENT`, `TICKET_PENDING`, `TICKET_CREATED`, `COMPONENT`).

Treat `resolution.by` of `CAG` or `AUTORESOLVER` — compared **case-insensitively**
(`autoresolver` also seen live) — as self-resolved; anything else as
"resolved by a person or integration". Record the values seen in coverage so the mapping
can be confirmed. An alert counts as **ticketed** when `ticketNumber` is non-empty **or**
`actions` contains `TICKET_CREATED` (both occur live without the other).
