# Example output — Alert Noise Review

From a live run against a Datto RMM sandbox account on 30 Sep 2026. Device, site and user
names are replaced; the numbers are real. Long lists are shortened. The fences only mark the
example — the real report is rendered Markdown, not a code block. The sandbox is a test tenant, so the dead-gear volume is far higher than on a
production account.
Prompt: *"Which alerts are just noise?"*

**Start-up note** — its own chat message, before the first Datto RMM call:

```
Alert Noise Review v0.1.13 · last updated 5 Oct 2026 · read-only · Datto RMM
Developer note: alpha release by the Kaseya Automation Content Team. Check results before acting on them, and report anything odd.
Starting: reading open and resolved alerts. This can take a few minutes on a large account; any permission prompts are for read-only Datto RMM tools.
Tip: say "drmm-alert-noise-review readme" for the full guide and all parameters.
```

**Report:**

````markdown
# Alert Noise Review: account
**30 Sep 2026, 14:26 CEST** · window 23 Sep 14:20 – 30 Sep 13:48 (7.0 days covered) · 3,361 alerts read

## 🔴 Verdict: NOISY
Two patterns make up **99.7 % of all alerts**: the **CPU monitor (56 %)** and **offline alerts on long-dead devices (44 %)**.

---

## Tune first

| # | Removes | Task | Why |
|---|---|---|---|
| 1 | ~1,640 a week | **Exclude the RMM agent from the CPU monitor** | Score 88 (99.9 % clear themselves, 91 % within 15 min). The agent is the top process on 88 % of them. Top devices NWL-APP01, HF-WS022, PCC-WS01. |
| 2 | ~1,220 a week | **Keep one CPU monitor per device** | 1,852 alerts were only 632 moments — up to 30 alerts at once from stacked monitors. |
| 3 | ~1,455 | **Take the offline policy off retired devices** | 1,455 of 1,468 offline alerts sit on devices offline over 7 days. Top sites Old Mill Brewing, Bluebird Dental, Legacy Lab. → drmm-stale-and-ghost-devices |
| 4 | ~5 a week | **Add a 10-minute duration to the performance monitor on NWL-APP01** | Score 70. Fires twice a day at 15:48 and clears after a median of 7 minutes. |

**Where to start on item 1:** the CPU monitor's process exclusions. If the agent load itself looks abnormal, open a case with Datto support.

---

## Noisy but real — fix the cause, do not tune
- **Disk usage on NWL-APP01** — 3 open alerts (11, 26, 28 Sep), C: at 5.3 % free → drmm-device-quick-look
- **Disk usage on HF-WS022** — 3 open alerts on 30 Sep, level not reported; offline since 12:31
- **Offline on NWL-APP01, a live server** — 23 Sep for 103 minutes, 30 Sep for 2 minutes

---

## What else we found

**Ticket burden**
- 11 CPU alerts on PCC-WS01 created tickets; 8 cleared themselves within 15 minutes — about 40 minutes of triage for nothing (estimate).
- Ticket creation failed on 2 CPU alerts from NWL-APP01 (24 Sep 02:28, 29 Sep 00:22).

**Dead gear**
- Open alerts on devices offline over 7 days: Old Mill Brewing 511 · Bluebird Dental 504 · Legacy Lab 22 · other sites 418

## By site

| Site | Alerts | Devices | Per device |
|---|---|---|---|
| Northwind Legal | 843 | 1 | 843 |
| Hillford Freight | 674 | 1 | 674 |
| Pinecrest Clinic | 370 | 11 | 34 |

---

## Coverage

| Area | Status |
|---|---|
| Resolved alerts | 3,000 read (the budget), back to 16 Sep — the 7-day window is covered |
| Open alerts | 1,500 read, oldest 29 Sep 11:03 — partial |
| Groups scored | 2 · muted open alerts: 0 · resolved by: CAG 1,857, AUTORESOLVER 2, a person 2 |

7 days, Europe/Stockholm (from the user) · read-only · Alert Noise Review v0.1.13 (alpha) · non-default: open_page_budget 15
Monitoring policy names are not exposed; recommendations are by monitor type.
````
