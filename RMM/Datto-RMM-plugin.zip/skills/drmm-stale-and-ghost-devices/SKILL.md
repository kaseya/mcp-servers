---
name: "drmm-stale-and-ghost-devices"
description: Read-only inventory audit of a Datto RMM account. Opens with a start-up note (version, expected wait). Finds devices that are gone (offline for weeks or months), ghosts (re-imaged or renamed machines whose old agent record was never removed, duplicate enrolments of the same hardware), suspended agents, and sites that hold nothing but dead records. Uses the account's own device filters to count account-wide in a few calls, then reasons over hostnames, MAC addresses and last-seen dates to decide which records are safe to remove, which to investigate and which to leave alone. Produces a clean action list with an estimate of the billable agent seats involved. Use this whenever the user asks about stale, dead, inactive, ghost, orphaned, duplicate or old devices, devices that have not checked in, inventory cleanup, licence or seat reconciliation, what to delete from RMM, or why the device count looks too high — for the whole account or for one site. For one named device, use drmm-device-quick-look instead.
metadata:
  version: "0.1.13"
  last_updated: "2026-10-05"
  type: "Datto RMM Skill"
  stage: "alpha"
  execution: "read-only"
  author: "Kaseya Automation Content Team"
compatibility: Requires the Datto RMM connector (drmm v0.4.0 tool set — the "Datto RMM" desktop extension or the datto-mcp remote server). See "Tools" below.
---

# Stale & Ghost Devices

## Run banner and readme

A full run takes several minutes, and in Claude Desktop the user sees only a collapsed
progress box while tools run. So the skill's output has two parts: a short start-up note,
written as a chat message once you have read this file and before the first Datto RMM
call (step 0 below), and then the report. The start-up note is these four lines:

```
Stale & Ghost Devices v0.1.13 · last updated 5 Oct 2026 · read-only · Datto RMM
Developer note: alpha release by the Kaseya Automation Content Team. Check results before acting on them, and report anything odd.
Starting: reading device filters, sites and old device records. This can take a few minutes on a large account; any permission prompts are for read-only Datto RMM tools.
Tip: say "drmm-stale-and-ghost-devices readme" for the full guide and all parameters.
```

Then gather the data and write the report. Its Coverage line carries the version and the
alpha mark too, so the reader still sees them if the note scrolls away.

**Readme mode.** When the message contains the word `readme` (with or without a slash) or
asks you to explain this skill: `readme` is a mode word, not a file — do not search for a
README file. Open `references/readme-guide.md` in this skill's folder and follow it.
Gather no data and call no Datto RMM tools.

---

## Goal

Answer one question for the person who owns the RMM inventory:

> **Which device records no longer stand for a real, managed machine, and what should we
> do with each of them?**

The output is an action list, not a list of offline devices. Every record lands in exactly
one bucket — **remove**, **investigate**, or **leave** — with the evidence for that call.
Dumping 1,500 offline rows is the failure this skill most needs to avoid; so is telling
someone to delete a server that is simply switched off for the weekend.

Stale & Ghost Devices is diagnostic only. It never deletes, moves, suspends or edits a
device, and never writes a UDF. The connector exposes write tools (`update_device_udfs`,
`resolve_alert`, `create_job`); this skill calls none of them. Removing a device is done by
a person in the Datto RMM web portal — the public API offers no delete.

---

## Tools

All calls go through the **Datto RMM connector** (drmm v0.4.0). The same tools appear as
`datto-mcp` (remote) or `Datto RMM` (desktop extension). Use these and nothing else.

| Purpose | Tool | Notes |
|---|---|---|
| Filter IDs | `list_device_filters` | `filter_type: "default"` and `"custom"`. Resolve every filter **by name**; IDs can differ by platform. |
| Account-wide slices | `list_devices` with `filter_id` | `count` is the **true total** for filter queries. Max 100 per page. |
| One site | `list_devices` with `site_uid` | `list_devices` takes **exactly one** selector. There is no unfiltered account-wide list. |
| Online set | `list_devices` with `filter_id: <Online Devices>` | Every online device account-wide — usually small (13 in the live check). The source of online twins. |
| Duplicate check by name | `list_devices` with `hostname` | Partial match, account-wide. Only for the few cases in "Candidate checks". |
| Duplicate check by hardware | `list_devices` with `mac_address` | 12 hex characters, **no separators**. |
| Sites | `list_sites` | Carries `devices.total / online / offline` per site and `autotaskCompanyId`. `count` is the true total. |
| Hardware identity | `get_device_audit` | `nics[].macAddress` (with colons), `bios.serialNumber`. Only for candidates — see budget. Fails with 400 on some network-discovered devices. Audits of VMware guests run to about 8 KB each (dozens of empty memory slots). |
| Signs of life | `list_alerts` `status: "open"` with `device_uid` | Only for stale infrastructure — see "Signs of life". |

**Filters this skill uses** (default names, resolve to IDs at run time):

| Filter name | Why |
|---|---|
| `Last Seen > 30 days` | The main stale population. |
| `Offline > 1 Week` | The early-warning population (offline 7–30 days). |
| `Suspended Devices` | Agents already suspended but still on record. |
| `Offline Server O/S` | Servers, which never go to "remove" without investigation. |
| `All Devices` | Denominator for the stale percentage (use `count` only; do not page it). |
| `Online Devices` | The online set, for twin detection. |

If a filter name is missing on the account, say so in coverage and fall back to paging
sites for that slice.

### Page sizes

Claude Desktop rejects a tool result over about 50 KB. Per call, never request more than:
devices 100, open alerts 100, resolved alerts 50, sites 100, device software 250 (a Mac
needs two or more pages), patches 100, components 50. If the same page fails twice with
HTTP 500, one record in that range is unreadable: retry the range in smaller pages to read
around it, and report the range. Measured sizes: `references/connector-notes.md`.

---

## Parameters

Apply the default when not given, and state any non-default value in the coverage
footer. Users set these in plain words ("only Northwind Legal", "look back 14 days").

| Parameter | Default | Effect |
|---|---|---|
| `stale_days` | 30 | Offline longer than this is stale. Values under 30 fall back to site paging (no default filter matches). |
| `remove_days` | 90 | Offline workstation older than this with no counter-evidence goes to **remove**. |
| `server_remove_days` | 180 | Same for servers and infrastructure — a higher bar. |
| `sites` | none | Restrict to named sites. Switches gathering to per-site mode. |
| `seat_price` | none | If given, the seat estimate is also shown as a monthly amount. |
| `currency` | none | Currency for `seat_price` (for example EUR, USD, SEK). If a price is given without one, ask. Never assume a currency. |
| `timezone` | the user's | The connector has no account timezone. UTC if unknown — say so. |
| `html` | off | On when the user's message contains the word `html` ("drmm-stale-and-ghost-devices html", "as HTML"). Same run, delivered as a styled HTML page: read `references/html-report.md` before writing the report. |

**Reading parameters.** Text in quotes is one value, taken exactly (`"Google Chrome"`,
`sites "- Datto Devices"`). Without quotes, a value runs until the next parameter word
(`version`, `sites`, `days`, `html`, `readme` …, or "for"/"at" before a site). Multi-word
names match as a whole phrase, case-insensitively, never word by word. If a word could
belong to two values, ask once before reading data. Coverage echoes what was understood
(Searched for "Google Chrome" · sites: Northwind Legal).

**Advanced — budgets.** Change these only when a run stops early on a large account.

| Budget | Default | Effect |
|---|---|---|
| `page_budget` | 50 | Pages (at 100) of any one filter before stopping and asking. |
| `audit_budget` | 40 | `get_device_audit` calls for hardware-identity checks. |
| `alert_budget` | 40 | Stale infrastructure devices checked for signs of life. |

---

## Scope boundary

| In scope | Out of scope |
|---|---|
| Records offline beyond `stale_days` | Devices that dropped overnight → `drmm-morning-pulse` |
| Duplicate and re-imaged enrolments | Why one device is offline → `drmm-device-quick-look` |
| Suspended agents still on record | Whether PSA/IT Glue still list the device → `weekly-system-alignment` |
| Sites holding only dead records | Patch state of live devices → `drmm-patch-posture` |

---

## Data gathering

0. **Post the start-up note** from "Run banner and readme" as a chat message, before
   any Datto RMM call below. Then continue straight away; do not wait for a reply.
   Between steps, a one-line progress note is fine ("Devices read, reading alerts next").

### Account mode (default)

1. `list_device_filters` (default, then custom) → resolve the five filter names.
2. `list_devices` with `All Devices`, `max: 1` → denominator from `count`. Do not page.
3. `list_devices` with `Last Seen > 30 days`, `max: 100`, paged. Before paging, compare
   `count / 100` with `page_budget`. Above budget: report the count, the per-site
   breakdown of the pages already read, and ask whether to continue or narrow to sites.
4. `list_devices` with `Suspended Devices`, paged. `list_devices` with
   `Offline Server O/S`, paged → keep the `device_uid` set (the server class; see Classes).
5. `list_devices` with `Offline > 1 Week`, `max: 1` → count only (early-warning figure).
6. `list_sites`, paged at 100 → per-site totals, for dead-site detection.
7. Candidate checks (below), within their budgets.

### Site mode (`sites` given, or `stale_days` < 30)

Page `list_devices site_uid` for each named site and apply the same rules to the rows.

### Candidate checks

These turn "offline for a long time" into a decision. Run them in this order and stop at
the budget; unchecked candidates go to **investigate** with "not checked".

1. **Hostname twins — no extra calls.** Page the `Online Devices` filter once. Group every
   row already read (stale set + online set) by hostname, case-insensitive. An exact match
   between a stale row and an online row is an online twin; two or more stale rows with the
   same hostname are offline duplicates. **An online twin counts only if it is an agent
   device** — 36-character `device_uid` and a non-null `operatingSystem`. A phantom online
   record (malformed UID, no OS) is a data-quality flag, not a twin; the live check found one
   "online" beside two real offline agents of the same name. Skip hostnames that are UUIDs, IP addresses, MAC
   strings or blank — they are network-discovered records. Do **not** call
   `list_devices hostname` per stale device: in the live check that would have been 1,479
   calls for the same answer. Use it only to confirm a single suspicious pair.
   **Bulk clones:** a hostname with 10 or more records, all offline, is load-test or
   imaging debris (live check: "skynet" ×128, "thecoolercomputer" ×116). Report each as one
   line with its count and sites, in Remove.
2. **Hardware twins.** For stale **servers and workstations only**, `get_device_audit`,
   take the first physical NIC MAC (skip virtual adapters: Hyper-V virtual switch, VPN,
   `PANGP`, `TAP`, `Npcap`, `VirtualBox Host-Only`, `VMware Virtual Ethernet`, Bluetooth), strip colons,
   `list_devices mac_address`. **Prefer the built-in adapter**: skip USB and docking-station adapters
   (`USB`, `ASIX`, `Realtek USB`, `Targus`, `Dock` in the name) and any MAC that is empty or mostly zeros
   (live: `00:00:00:00:01:8C` on a USB adapter) — a shared dock would give two laptops the same MAC. On a
   virtual machine the guest adapter (`Hyper-V Network Adapter`, `vmxnet3`, `Intel 82574L`) is the identity.
   The lookup returns **every** record with that MAC — read them all, not only the first. Record
   `bios.serialNumber` too.
3. **Signs of life** (stale infrastructure only, within `alert_budget`, oldest first):
   `list_alerts device_uid status open max 20`. A sign of life is an alert of **any type
   except `online_offline_status_ctx`** raised within `stale_days`. Offline alerts do not
   count: an offline policy fires on dead gear — in the live check it raised 966 alerts in
   one hour on devices dead for years, which would otherwise have sent every dead server to
   Investigate. Offline agent workstations cannot raise other alerts, so workstations are
   not checked.

### Gotchas

Confirmed against a live drmm v0.4.0 connector. The full field list for each tool is in
`references/connector-notes.md`; read it when a field you need is missing or a value looks wrong.

- There is no enrolment or creation date and no last-audit date. The skill cannot tell
  "never checked in" from "checked in long ago". Use `lastSeen` only, and never invent a
  date.
- `lastSeen` means something only when `online` is false.
- `device_type` is the hardware chassis (`Main System Chassis` is a Windows Server). Never
  read "server" from it.
- Agentless records have a `device_uid` of `<siteUid>-<MAC>`, longer than 36 characters.
  A normal UUID's last group is also 12 hex characters, so never test "ends in 12 hex"
  alone. Malformed UIDs occur (73 characters, no OS).

---

## Computation

### Classes

- **Agent device** — `operatingSystem` is not null.
- **Server** — in the `Offline Server O/S` set (the stale servers this skill needs), or
  `operatingSystem` contains `Server`.
- **Infrastructure** — servers, `device_type` `ESXi Host`, `Network Device`, `Router`,
  `Firewall`, `Switch`, `Network Appliance`, `UPS`, `SAN`, `NAS`, or starting `Datto `.
  (`device_type` is the chassis; servers also appear as `Other`, `Server` or
  `Main System Chassis` — the OS rule above catches them.)
- **Agentless / discovered** — `device_uid` longer than 36 characters, or
  `operatingSystem` null. (The live check caught the earlier rule, "ends in `-<12 hex>`",
  marking all 1,532 stale devices agentless — every UUID ends that way.) These cost no agent seat; they are clutter, not waste. Report them as a count per
  site, never as removal items.

### Days offline

`floor((now − lastSeen) / 86 400 000)`. A `lastSeen` of 0 or null is **"never seen"**.
Datto networking devices can report `online: false` with a current `lastSeen`; treat
their offline time as unknown and send them to investigate.

### Ghost patterns

A ghost is a record whose machine still exists under another record. Each pattern needs
the named evidence; nothing is a ghost on name similarity alone.

**Live twin.** In the patterns below "online" means *live*: the twin is online now, **or** it is
offline but was seen within `stale_days`. A machine that was renamed or moved last week and is
switched off today still makes its old record a ghost. Live check (30 Sep 2026): a desktop
record offline for 302 days shared its MAC with a differently named device at another site last
seen 6 days earlier; the online-only rule missed it. State the twin's last-seen date when it is
not online.

**One machine, several dead records.** Two or more stale records with the same MAC (and BIOS
serial where reported) and no live twin are one machine enrolled more than once (live: one VM
at three sites). They follow the normal age rules; list them together under Ghosts as
"same hardware ×n" so they are removed as a set.

| Pattern | Evidence | Bucket |
|---|---|---|
| **Re-imaged / re-enrolled** | Exact hostname twin that is **online**, same site. | Remove the offline one. |
| **Hardware twin** | Offline record's physical MAC or BIOS serial matches an **online** record. | Remove the offline one. |
| **Moved site** | Exact hostname or MAC twin online at a **different** site. | Investigate — may be a deliberate move that left the old record, or two customers with a `DESKTOP-XXXX` collision. |
| **Renamed** | MAC twin online with a different hostname. | Remove the offline one; name both. |
| **Double enrolment** | Two **online** records with the same MAC at the same site. | Investigate — one agent is reporting twice, or a cloned VM. |
| **Default-name collision** | Hostname matches `DESKTOP-`, `WIN-`, `LAPTOP-`, `EC2AMAZ-` plus random suffix and the only twin is at another site. | Not a ghost. Ignore the twin. |

### Buckets

Walk every stale record once:

**Remove** — safe to delete in the portal:
- Ghost pattern with an online twin (re-imaged, hardware twin, renamed).
- Agent workstation offline beyond `remove_days` with no twin.
- Infrastructure offline beyond `server_remove_days` with no sign of life (checked, not
  assumed — beyond `alert_budget` it goes to Investigate as "not checked").
- Bulk clone groups.
- Suspended agent offline beyond `remove_days`.

**Investigate** — a human must decide:
- Any **infrastructure** offline beyond `stale_days` but under `server_remove_days`.
  Servers are shut down for migrations, DR tests and seasonal sites.
- Infrastructure beyond `server_remove_days` with a sign of life — something other than
  the offline policy is still reporting on it.
- Moved-site and double-enrolment patterns.
- Records the budget did not reach ("not checked").
- Datto networking devices with unknown offline time.

**Leave** — stale but not actionable:
- Offline between `stale_days` and `remove_days` with no twin (laptops on leave, seasonal
  machines). Counted per site, not listed.
- Agentless / discovered records (counted per site).

### Dead sites

A site where `devices.total > 0` and `devices.online == 0` and every device in it appeared
in the stale set is a **dead site**. One line each: site name, device count, most recent
`lastSeen`, and `autotaskCompanyId` (null means not mapped to a PSA company). A dead site
is usually an off-boarded customer still carrying agent records — the strongest seat
reconciliation finding. Sites with `devices.total == 0` are listed as a count only
(empty staging and on-demand sites are normal).

### Seat estimate

Seats at stake = agent devices in **remove** + agent devices in dead sites (count each
once). Never include agentless records. With `seat_price`, multiply and label it
"estimate — depends on your Datto RMM agreement".

### Verdict

- **RED** — stale agent devices are over 15 % of all devices, or any dead site exists.
- **AMBER** — any device in remove or investigate.
- **GREEN** — nothing to remove or investigate.

---

## Output

The start-up note is already written; write the report below it. The reader is a
technician deciding what to do next: lead with the answer, keep lines short, and put
how the data was read at the end.

```markdown
# Stale & Ghost Devices: [account or sites]
**[date time tz]** · [n] devices · stale after [n] days

## [🔴|🟠|🟢] Verdict: [RED|AMBER|GREEN]
[Seats at stake, dead sites, ghosts — in one or two sentences.]

---

## What to do
| # | Records | Task | Why |
|---|---|---|---|
| 1 | [n] | **[Remove / Investigate / Merge] [what]** ([sites]) | [evidence] |

**Where to start on item 1:** [the concrete first check].

---

## Remove ([n])
| Site | Device | Type | Offline | Reason |
|---|---|---|---|---|

---

## Investigate ([n])
- **[device or group]** ([site], offline [n] d) — [what to check]

---

## Ghosts
- **[offline record] ⇄ [live record]** — [evidence]

---

## Dead sites
| Site | Records | Agent records |
|---|---|---|

**Seats at stake:** [n] agent seats[, ~[amount] [currency] a month]. Early warning: [n]
offline over a week but not yet stale. Left alone: [counts].

---

## Data you shouldn't trust
- **[lead]** [one line]

---

## Coverage
| Area | Status |
|---|---|
| Filters · Sites · Hardware-twin checks · Signs-of-life checks | [complete, or partial and budget used] |

[Scope], [timezone] · [n] read-only calls · Stale & Ghost Devices v[version] (alpha)
```

**Format.** Markdown laid out like the template — not a code block, not plain text: a `#`
title, a bold date line, the verdict as a `##` heading with its colour dot, `---` between
sections, the action list as a table, and Coverage as an Area | Status table. Omit any
section that would be empty.

**Writing rules.**
- Lead with the answer: one or two sentences under the verdict, with the key device names
  and numbers in **bold**.
- Action rows start with a verb ("Free up disk on…", "Reboot…", "Deploy…"). The Why cell
  holds the evidence and the ticket number or "No ticket." in one or two short sentences.
- Under the action table, a **Where to start on item 1:** line names the concrete first
  check. Add one for item 2 only when it needs its own.
- Other sections use a bold lead line with short bullets under it, one fact per bullet.
- Raw field and monitor names (`perf_disk_usage_ctx`, `patch.status`) appear only in "Data
  you shouldn't trust" and Coverage. Elsewhere say "disk alerts", "reboot pending".
- Dates as "11 Sep"; times in the user's timezone.
- End Coverage with one line: window or scope, timezone and where it came from, `[n]
  read-only calls`, and the skill name and version. If a fuller run would close a gap,
  offer it in one closing sentence after Coverage — never more than one.

**Remove** is sorted by site, then days offline descending, capped at 50 rows with the
remainder counted per site. Each row carries its reason in five words or fewer ("online
twin CLOUD-FS01", "offline 412 d, no alerts"). Where more than 50, add one line: "Full
list available — ask for it as a CSV."

**Investigate** always names the concrete thing to check: "server — confirm
decommissioned with customer", "same MAC online at Site B — was it moved?".

**Data you shouldn't trust** — candidates: double enrolments; adapters unusable as identity (USB or dock adapters, zero MACs);
phantom online records (malformed `device_uid`,
no OS); hostnames that are UUIDs or blank on agent devices; devices with `lastSeen` in the future; Datto networking devices with unknown
offline time; `Last Seen > 30 days` total differing from the rows actually read.

**Coverage** — Area | Status rows and the closing line, covering: calls made, filters used by name and ID, pages read vs total, candidates
checked vs budget, anything partial, timezone (the connector exposes no account
timezone — use the user's, else UTC and say so), non-default parameters.

**HTML.** With `html` on, build the page from `assets/report-template.html` as
`references/html-report.md` describes, instead of the Markdown report.

See `references/example-output.md` for the shape. Read it before the first run of a session.

---

## Handoffs

| Finding | Hand off to |
|---|---|
| One device needs a closer look before deciding | `drmm-device-quick-look` |
| Dead site — check PSA contract and IT Glue before off-boarding | `weekly-system-alignment` |
| Infrastructure dropped in the last day or two | `drmm-morning-pulse` |
| Stale devices still raising alerts | `drmm-alert-noise-review` |

---

## Quit conditions

- The first `list_device_filters` or `list_sites` call fails twice.
- The stale filter exceeds `page_budget` and the user has not answered.
- Every collection comes back empty — say the account appears empty; never report GREEN.

---

## Known gaps

What this skill cannot do yet, and how to tell that it worked, is in
`references/known-gaps.md`. Read it in readme mode, or when the user asks about limits.
