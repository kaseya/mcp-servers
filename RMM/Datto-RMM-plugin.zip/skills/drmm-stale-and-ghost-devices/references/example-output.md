# Example output — Stale & Ghost Devices

From a live run against a Datto RMM sandbox account on 30 Sep 2026. Device, site and user
names are replaced; the numbers are real. Long lists are shortened. The fences only mark the
example — the real report is rendered Markdown, not a code block. The sandbox is a test tenant full of long-dead records, so the numbers are far higher
than on a production account.
Prompt: *"Which devices can we remove from RMM?"*

**Start-up note** — its own chat message, before the first Datto RMM call:

```
Stale & Ghost Devices v0.1.13 · last updated 5 Oct 2026 · read-only · Datto RMM
Developer note: alpha release by the Kaseya Automation Content Team. Check results before acting on them, and report anything odd.
Starting: reading device filters, sites and old device records. This can take a few minutes on a large account; any permission prompts are for read-only Datto RMM tools.
Tip: say "drmm-stale-and-ghost-devices readme" for the full guide and all parameters.
```

**Report:**

````markdown
# Stale & Ghost Devices: account
**30 Sep 2026, 14:26 CEST** · 1,554 devices · stale after 30 days

## 🔴 Verdict: RED
**1,339 stale agent records are 86 % of the account.** 105 sites hold nothing but dead records, and **1,325 agent seats** are at stake.

---

## What to do

| # | Records | Task | Why |
|---|---|---|---|
| 1 | 1,121 | **Remove the bulk clones** (Bluebird Dental, Old Mill Brewing) | 11 hostnames enrolled 99–128 times each, all offline — load-test or imaging debris. |
| 2 | 70 | **Remove individual dead records** | Offline 92 to 2,455 days, no online twin, no alerts. |
| 3 | 308 | **Confirm with the customer before removing** | Mostly 93 backup appliances at Continuity Lab, offline 41–49 days — infrastructure gets a higher bar. |
| 4 | 1 | **Remove the old record of a renamed PC** | DESKTOP-4KD82LP shares its MAC with PCC-WS01, which is still in use. |

**Where to start on item 1:** the full list is available as a CSV — ask for it.

---

## Remove (1,191)

| Site | Device | Type | Offline | Reason |
|---|---|---|---|---|
| Bluebird Dental, Old Mill Brewing | skynet ×128, thecoolercomputer ×116, beep ×115, … | Mixed | 2017 | Bulk clones |
| Brightside Media | rh8srv | Server | 2,371 d | No alerts |
| Hillford Freight | HF-WS091 ×3 | Workstation | 214–225 d | Same hardware ×3 |
| Legacy Lab | WIN-2008R2-64 | Server | 2,371 d | No alerts |
| Pinecrest Clinic (old site) | DESKTOP-4KD82LP | Workstation | 302 d | Renamed — same MAC as PCC-WS01 |

…and 45 more individual rows. Full list available — ask for it as a CSV.

---

## Investigate (308)
- **Continuity Lab** (93 backup appliances, offline 41–49 d) — confirm decommissioned with the customer.
- **42 infrastructure records offline over 180 d** — signs of life not checked (budget of 40 used on the oldest). Check for non-offline alerts, then remove.
- **164 workstations offline over 90 d** — hardware twin not checked (budget used). No hostname twin is online for any of them.

---

## Ghosts
- **DESKTOP-4KD82LP ⇄ PCC-WS01** — same MAC address; the machine was renamed and moved. The old record is in Remove.
- **HF-WS091 ×3** — same MAC and BIOS serial at three sites, all offline.
- No offline record has an online twin by hostname, MAC or BIOS serial.

---

## Dead sites

| Site | Records | Agent records |
|---|---|---|
| Bluebird Dental | 548 | 548 |
| Old Mill Brewing | 545 | 545 |
| Legacy Lab | 11 | 11 |
| 102 more sites | 284 | 212 |

**Seats at stake:** 1,325 agent seats (no seat price given, so no amount). Early warning: 5 devices offline over a week but not yet stale. Left alone: 33 (recent or agentless).

---

## Data you shouldn't trust
- **Phantom online record:** DESKTOP-Q2N534J at Pinecrest Clinic has a 73-character `device_uid` and no OS.
- **Filter count differs:** "Last Seen > 30 days" says 1,530; 1,532 rows qualify by `lastSeen`.
- **WGR-LT03 lists USB adapters** with zero-padded MACs — unusable as identity.

---

## Coverage

| Area | Status |
|---|---|
| Filters | All Devices 1,554 · Last Seen > 30 days 1,530 · Offline > 1 Week 1,535 · Suspended 0 |
| Sites | 2,563 of 2,613 (2,550–2,599 unreadable) |
| Hardware-twin checks | 40 of 242 candidates (budget 40) |
| Signs-of-life checks | 40 of 82 (budget 40) |

Account, Europe/Stockholm (from the user) · read-only · Stale & Ghost Devices v0.1.13 (alpha)
````
