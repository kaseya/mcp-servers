# Stale & Ghost Devices — readme guide

Use this only in readme mode. Call no Datto RMM tools; this file is the guide. Print the first two lines and the last line of the start-up
note from `SKILL.md`, then this guide, built from `SKILL.md`, in the same Markdown style as
the reports: a `#` title, one `##` heading per item below, short bullets, and the
Parameters as a table.

1. **What it answers** — the question in Goal, in one line.
2. **When to use it, and when not** — from the scope and handoff sections, naming the
   other skill to use instead.
3. **What it reads and what it may change** — connectors and tools from Tools; any write,
   and the approval it needs.
4. **Parameters** — every row of the Parameters table: name, default, effect. Mention that
   advanced budgets exist without listing them. Then show these examples exactly, one per
   line, and add: "Use quotes when a name has spaces and you add other settings."
   - `drmm-stale-and-ghost-devices stale_days 60 remove_days 180`
   - `drmm-stale-and-ghost-devices sites "- Datto Devices"` — quotes keep the leading dash and spaces
   - `drmm-stale-and-ghost-devices seat_price 3 currency EUR` — adds a monthly amount
   - `drmm-stale-and-ghost-devices html`
5. **Output** — the output section headers in order, one line each.
   Mention that adding the word `html` gives the same report as a styled page.
6. **Known limits** — one line each, from `references/known-gaps.md`.

Keep it to what a technician needs to decide how to run the skill.

End with **one yes/no offer that names the scope it will use**, for example "Run it now
for the whole account? Or name a site or device instead." Never end with an either/or
question: a plain "yes" must have exactly one meaning. If the user answers "yes", run with
the scope you named and state it in the coverage footer.

End the guide with a `## Developer note` section: author Kaseya Automation Content Team;
stage alpha — output and parameters may change between versions, results should be
checked before acting on them, and feedback is welcome.
