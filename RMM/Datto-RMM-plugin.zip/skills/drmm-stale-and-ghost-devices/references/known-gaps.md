# Stale & Ghost Devices — known gaps and success measures

## Known gaps

- **No enrolment date** on the device record, so "never checked in" cannot be separated
  from "checked in long ago". Server-team ask: return `creationDate`.
- No delete or suspend tool; removal is manual in the portal.
- Hardware twin checks cost one audit call each; accounts with thousands of stale records
  need a MAC or serial field on the device list. Server-team ask.
- No PSA or IT Glue cross-check in the Lite tier — that is `weekly-system-alignment`.
- Default filter thresholds are fixed at 7 and 30 days; other thresholds need site paging.

## Measuring whether this worked

- Every row in REMOVE could be deleted without a follow-up question.
- No server lands in REMOVE on age alone.
- A re-imaged workstation's old record is caught by its twin, not by guesswork.
- Dead sites surface as one line each, not as hundreds of device rows.
- Agentless records never inflate the seat estimate.
