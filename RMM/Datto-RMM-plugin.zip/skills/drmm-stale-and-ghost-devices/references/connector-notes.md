# Stale & Ghost Devices — connector notes

Reference for the drmm v0.4.0 Datto RMM connector, measured live on 30 Sep 2026.
Read when a field you need is missing, a value looks wrong, or a page fails.

## Page sizes

A tool result larger than about 50 KB fails in Claude Desktop, so never request more than
these per call (sizes measured live on 30 Sep 2026):

| Call | Max per page | Size at that max |
|---|---|---|
| `list_devices` | 100 | ~45 KB |
| `list_alerts` open | 100 | ~45 KB |
| `list_alerts` resolved | 50 | ~35 KB |
| `list_sites` | 100 | ~35 KB (150 measured ~50 KB — too close to the limit) |
| `list_device_software` | 250 | ~25 KB on Windows; macOS lists run past 250 rows of system components |
| `list_patches` | 100 | small |
| `list_components` | 50 | ~23 KB |

If the same page fails twice with HTTP 500, one record in that range is unreadable (seen live:
sites 2,550–2,599 failed at every page size). Retry the range in smaller pages — half, then a
tenth — to recover the rest, and report the range that could not be read.

## Fields by tool

Confirmed against a live drmm v0.4.0 connector.

**Device rows** (`list_devices`, `get_device` return the same trimmed shape):
`hostname`, `device_uid`, `siteUid`, `device_type`, `operatingSystem`, `online`
(boolean), `lastSeen` (epoch **milliseconds**), `rebootRequired`, `patch{status,
installed, approved_pending, not_approved}`, `antivirus{product, status}`.
Site names come from `_enhanced.siteNames`, keyed by `siteUid`.

**Not available through this connector:** creation or enrolment date, last audit date,
numeric device ID, UDFs, domain, last logged-in user, warranty. The skill therefore
cannot tell "enrolled and never checked in" from "checked in once, long ago". Do not
invent a creation date; use `lastSeen` only.

`device_type` is the **hardware chassis type**, not the RMM category. Values seen:
`Desktop`, `Portable`, `Notebook`, `MacBook`, `Main System Chassis` (a Windows Server),
`ESXi Host`, `Network Device`, and `Datto …` networking types. Never read "server" from
`device_type`. Agentless records have a `device_uid` of the form `<siteUid>-<MAC>` — longer
than 36 characters. A normal agent `device_uid` is a plain UUID (36 characters), whose last
group is also 12 hex characters, so never test "ends in 12 hex" on its own. Malformed UIDs
also occur (live: 73 characters, an `x` plus the UUID twice, on a record with no OS).

`lastSeen` is **not a heartbeat** on online devices — it can be days old on a healthy
server. It is meaningful only when `online` is false, where it approximates the drop time.
