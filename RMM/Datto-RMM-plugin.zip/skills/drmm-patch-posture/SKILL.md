---
name: "drmm-patch-posture"
description: Read-only patch exposure report for Datto RMM sites or the whole account. Opens with a short start-up note naming its version and that the run takes a few minutes. Reads the OS patch status of every server, desktop and laptop in scope, reads the patch lists of sites and failing devices to name the updates that are failing or pending, finds patch failures and the conditions that will break the next patch cycle (servicing-store corruption, disk-full patch codes), and ranks the devices to fix first — servers before workstations, offline devices kept apart as last-known. Use this whenever the user asks about patch status, patch compliance, patch exposure, missing or failed patches, which devices are unpatched, pending reboots after patching, or whether a customer is patched — for a site, a customer, a list of them, or the whole account. For one named device, use drmm-device-quick-look instead.
metadata:
  version: "0.2.17"
  last_updated: "2026-10-05"
  type: "Datto RMM Skill"
  stage: "alpha"
  execution: "read-only"
  author: "Kaseya Automation Content Team"
compatibility: Requires the Datto RMM connector (drmm v0.4.0 tool set — the "Datto RMM" desktop extension or the datto-mcp remote server). See "Tools" below.
---

# Patch Posture

## Run banner and readme

A full run takes several minutes, and in Claude Desktop the user sees only a collapsed
progress box while tools run. So the skill's output has two parts: a short start-up note,
written as a chat message once you have read this file and before the first Datto RMM
call (step 0 of Data gathering), and then the report. The start-up note is these four lines:

```
Patch Posture v0.2.17 · last updated 5 Oct 2026 · read-only · Datto RMM
Developer note: alpha release by the Kaseya Automation Content Team. Check results before acting on them, and report anything odd.
Starting: reading device patch status, patch lists and alerts. This can take a few minutes on a large account; any permission prompts are for read-only Datto RMM tools.
Tip: say "drmm-patch-posture readme" for the full guide and all parameters.
```

Then gather the data and write the report. Its Coverage line carries the version and the
alpha mark too, so the reader still sees them if the note scrolls away.

**Readme mode.** When the message contains the word `readme` (with or without a slash) or
asks you to explain this skill: `readme` is a mode word, not a file — do not search for a
README file. Open `references/readme-guide.md` in this skill's folder and follow it.
Gather no data and call no Datto RMM tools.

---

## Goal

Answer one question for an MSP team:

> **Where are we exposed on patching, and which devices should we fix first?**

This is an operational report for the people who will do the fixing. It is not evidence
for a customer, an auditor or an insurer, and must never be presented as such: the
connector has no patch history, so everything here is a point-in-time reading.

The most common true answer on a well-run site is short: a handful of devices, one or two
real failures. Padding the report with every fully patched device is the failure to avoid.

Patch Posture is diagnostic only. It never approves, installs, defers or retries a patch,
never reboots a device, never resolves an alert. The connector exposes write tools
(`create_job`, `resolve_alert`, `update_device_udfs`); this skill does not call any of them.

---

## Scope

**Devices:** Windows servers, desktops and laptops — devices whose `operatingSystem`
contains `Windows`. Datto RMM patch management reports status only for Windows: in the live
check, 409 macOS, iOS, ESXi and Linux devices all carried `patch.status: null`. Count those
once in coverage as "not a Windows patch target" and leave them out of every rank and figure
— never rank them as "not under patch management". ESXi, network devices, printers and Datto
appliances are excluded too.

`device_type` in v0.4.0 is the **hardware chassis type**, not the RMM category (a Windows
Server shows as `Main System Chassis`, laptops as `Portable` or `Notebook`). Class:
**Server** if the device is in the `All Server O/S` filter set or `operatingSystem`
contains `Server`; otherwise **Workstation** (laptop when `device_type` is `Portable`,
`Notebook`, `Laptop`, `MacBook` or `Sub Notebook`).

**Two modes:**

- **Site mode** — the user names one or more sites or customers. Complete for those sites.
- **Account mode** — the user asks for the whole account. v0.4.0 returns patch status on
  every row of a device list, so this is now practical: devices come from the account's
  OS filters in a few pages. Patch lists (to name failing updates) are read only for the
  top-ranked devices and the worst sites, within budget; say so in coverage.

If the in-scope device count exceeds `device_budget`, state the total and ask the user to
narrow to sites or raise the budget before starting.

For a single named device, stop and hand off to `drmm-device-quick-look`.

---

## Tools

All calls go through the **Datto RMM connector** (drmm v0.4.0). Use these and nothing else.

| Purpose | Tool | Notes |
|---|---|---|
| Sites, and the access check | `list_sites` | The first call; a failure means stop. `devices{total, online, offline}` per site; `count` is the true total. Max 100. |
| Filter IDs | `list_device_filters` `filter_type: "default"` | Resolve `All Server O/S`, `All Desktop O/S`, `All Laptops`, `Reboot > 30 days` **by name**. |
| Devices at a site | `list_devices` `site_uid` | **Includes patch fields** (`patch.status`, counts) and `rebootRequired`. Max 100. |
| Devices account-wide | `list_devices` `filter_id` | Same row shape; `count` is the true total. |
| Named patches | `list_patches` `site_uid` **or** `device_uid` | Never both. Site scope aggregates per patch with `devices_affected`. |
| Open alerts | `list_alerts` `status: "open"` with `site_uid` (site mode) or `account_wide: true` | Max 100, all alert types mixed, **no type filter**. `count` is the page size — follow `next_page`. |
| Recent failures | `list_alerts` `status: "resolved"`, same scope | Newest first, **no date filter**. Patch alerts auto-resolve, so failures from the window can live only here. |

`get_device` is not needed: it returns the same fields as the list rows.

Timezone: the connector exposes no account timezone. Use the user's; otherwise UTC, and say
so in coverage.

### Page sizes

Claude Desktop rejects a tool result over about 50 KB. Per call, never request more than:
devices 100, open alerts 100, resolved alerts 50, sites 100, device software 250 (a Mac
needs two or more pages), patches 100, components 50. If the same page fails twice with
HTTP 500, one record in that range is unreadable: retry the range in smaller pages to read
around it, and report the range. Measured sizes: `references/connector-notes.md`.

---

## Parameters

Apply the default when not given, and state any non-default value in the coverage
footer. Users set these in plain words ("only Northwind Legal", "look back 14 days").

| Parameter | Default | Effect |
|---|---|---|
| `sites` | none | Site names (case-insensitive substring match) or UIDs. None → account mode, after saying so. |
| `include_workstations` | true | When false, only servers are in scope (useful before a server review): in account mode skip the `All Desktop O/S` and `All Laptops` pages. Say so in coverage. |
| `window_days` | 7 | Window for patch failures from alerts. |
| `dormant_after` | 30 days | Offline longer than this is noted as likely retired. |
| `timezone` | the user's | The connector has no account timezone. UTC if unknown — say so. |
| `html` | off | On when the user's message contains the word `html` ("drmm-patch-posture html", "as HTML"). Same run, delivered as a styled HTML page: read `references/html-report.md` before writing the report. |

**Reading parameters.** Text in quotes is one value, taken exactly (`"Google Chrome"`,
`sites "- Datto Devices"`). Without quotes, a value runs until the next parameter word
(`version`, `sites`, `days`, `html`, `readme` …, or "for"/"at" before a site). Multi-word
names match as a whole phrase, case-insensitively, never word by word. If a word could
belong to two values, ask once before reading data. Coverage echoes what was understood
(Searched for "Google Chrome" · sites: Northwind Legal).

**Advanced — budgets.** Change these only when a run stops early on a large account.

| Budget | Default | Effect |
|---|---|---|
| `device_budget` | 2,000 | In-scope devices per run before asking the user to narrow. |
| `patch_list_budget` | 25 | `list_patches` calls (sites + devices). |
| `alert_page_budget` | 5 | Open-alert pages (at 100) per site, or 15 account-wide. |
| `history_page_budget` | 10 | Resolved-alert pages (at 50) per site, or 30 account-wide. |

---

## Data gathering

0. **Post the start-up note** from "Run banner and readme" as a chat message, before step 1.
   If no sites were named, add one line: "No sites named, so this covers the whole
   account." Then continue straight away; do not wait for a reply.
1. `list_sites`; resolve named sites. Ambiguous name → list matches and ask.
2. `list_device_filters default` → the four filter IDs. Page `All Server O/S` and
   `Reboot > 30 days` and keep their `device_uid` sets (in site mode, only if their
   `count` is under 2,000; otherwise classify servers by `operatingSystem` only and say so).
3. **Devices.**
   - Site mode: page `list_devices site_uid` for each site.
   - Account mode: page `All Server O/S`, `All Desktop O/S` and `All Laptops`; de-duplicate
     by `device_uid`.
   - **Mostly offline account** (account mode): first read the `count` of `Online Devices`.
     When it is under 300, page `Online Devices` instead and keep Windows rows — every
     ranked device is online anyway. Take offline totals from the `count` of the three
     filters above and per-site offline figures from `list_sites`, and say in coverage that
     offline devices were counted, not read one by one.
   Keep Windows devices (`operatingSystem` contains `Windows`); count the rest by OS family
   for coverage.
4. Budget check against `device_budget`. Over → stop and ask.
5. **Alerts.** Page open alerts to the budget; keep `patch_ctx` alerts, and `eventlog_ctx`
   alerts whose `diagnostics` name `Ntfs` and event `55`. Page resolved alerts newest first
   until the oldest alert is outside `window_days` or the budget is reached; keep
   `patch_ctx`. With 20 or fewer online Windows devices, read alerts per device
   (`list_alerts device_uid`) instead of account-wide.
   **Flooded history:** when three resolved pages in a row hold no `patch_ctx` alert and
   one other monitor type fills them, stop paging resolved alerts for that scope. Take
   failures from the patch lists (`installStatus` containing `FAIL` or `ERROR`) of the
   online devices instead, and say in coverage how far back the alerts reached.
6. **Patch lists** (within `patch_list_budget`), in this order:
   - `list_patches device_uid` for every online **server** with `patch.status:
     InstallError`, or with a `patch_ctx` failure whose `diagnostics` do not name the patch;
   - `list_patches site_uid` for each site in site mode (or, in account mode, for the five
     sites with the most rank 1–3 devices) — the per-patch view with `devices_affected`.
   Page each to the end.

Between steps, a one-line progress note is fine ("Servers read, reading laptops next").

Retry a failing call once; if it fails again, mark that site, device or collection
"unavailable" and continue. Never retry on `rate_limited` — narrow the scope.

### Offline devices

Everything read from an offline device is last-known, as of `lastSeen`. Offline devices
are **never ranked and never counted in the posture figures.** They get their own section.

### Gotchas

Confirmed against a live drmm v0.4.0 connector. The full field list for each tool is in
`references/connector-notes.md`; read it when a field you need is missing or a value looks wrong.

- `patch.status` values seen: `FullyPatched`, `InstallError`, `NoPolicy`, `NoData`,
  `RebootRequired`, `ApprovedPending`. Report any other value raw and flag it. Non-Windows
  devices carry `null`.
- `FullyPatched` covers **approved** patches only; a device can be fully patched with
  patches waiting on approval. `installed` is a per-cycle count: show it, never rank on it.
- In patch lists, `APPROVED_PENDING` is approved and waiting: name it (title, KB) on the
  device's Fix first row under rank 3. Any other `installStatus` that is not `INSTALLED`
  is not installed; values containing `FAIL` or `ERROR` are failures. Record every value
  seen in coverage.
- Patch alerts give the result code (`0x` + 8 hex) and patch name only in `diagnostics`
  text. Use the alert `timestamp`, not times inside the text.
- **Servicing corruption** is `eventlog_ctx` naming `Ntfs`, event `55`, and a path under
  `\Windows\servicing` or `\Windows\WinSxS`. Without the path, report "file system
  corruption, location not reported" — still a cycle-at-risk signal on a server.
- `releaseDate` has no timezone: show the date only.

---

## Computation

### Per device (online only)

- **OS:** `patch.status`, approved pending, not approved.
- **Reboot:** `rebootRequired` or `patch.status: RebootRequired`; "no reboot in 30+ days"
  when the device is in the `Reboot > 30 days` set.
- **Failures:** `patch_ctx` alerts in the window — patch name, result code, time, ticket —
  and patch-list entries whose `installStatus` is a failure. Group by device + patch name +
  result code; repeated attempts are one line with a count.
- **Cycle at risk:** servicing corruption, or a patch result of `0x80070070` (disk full),
  `0x80073712` (component store corrupt) or `0x800f081f` (source files missing).

### Ranking

Rank online devices only. Highest rank a device meets decides its place; list every
reason on its line.

1. **Server with a patch failure** — `patch.status: InstallError`, a failed `patch_ctx`
   alert in the window, or a failed entry in its patch list.
2. **Server whose next patch cycle is at risk** — servicing corruption or a cycle-at-risk
   result code, whatever its status says. A device can be `FullyPatched` today and still
   belong here.
3. **Behind on patching** — approved patches pending, reboot required, or a workstation
   meeting rule 1 or 2. Servers before workstations.
4. **Not under patch management** — Windows device with `NoPolicy` or `NoData` (never `null`).
5. **Patches not approved** — `not_approved` above zero. Word it as a policy task:
   "N patches not approved — review approvals in the patch policy." Unapproved patches are
   often neglect of the policy, not a decision.

Within a rank: servers first, then the number of reasons, then the most recent evidence.

### Result codes

Explain only the codes below; show any other code as-is without interpretation.

| Code | Meaning |
|---|---|
| `0x80070643` | Installation failed (generic installer failure — check the product's own setup log) |
| `0x80070070` | Not enough disk space |
| `0x80073712` | Windows component store is corrupt |
| `0x800f081f` | Update source files could not be found |

### Verdict

- **RED** — anything at rank 1 or 2.
- **AMBER** — anything at rank 3, 4 or 5.
- **GREEN** — nothing ranked. Say so in one line.

Offline devices never affect the verdict.

---

## Output

The start-up note is already written; write the report below it. The reader is a
technician deciding what to do next: lead with the answer, keep lines short, and put
how the data was read at the end.

```markdown
# Patch Posture: [sites | account]
**[date time tz]** · [n] devices in scope · [n] online · [n] offline

## [🔴|🟠|🟢] Verdict: [RED|AMBER|GREEN]
[What drove it, in one or two sentences.]

---

## Fix first
| # | Rank | Task | Why |
|---|---|---|---|
| 1 | [1–5 · reason in two words] | **[Verb] [what] on [device]** ([site], [class]) | [status, update and KB, code] [ticket or "No ticket."] |

**Where to start on item 1:** [the concrete first check]. → drmm-device-quick-look

---

## Sites
| Site | Online | OS fully patched | Approved pending | Reboot required | No patch policy | Not approved |
|---|---|---|---|---|---|---|

---

## Patch failures
| Update | KB · code | Devices | First – last seen | Ticket |
|---|---|---|---|---|

---

## What else we found
**Not under patch management**
- [device or count per site]

**Offline — last known**
- [device · class · offline since · last-known status], or per-site counts

---

## Data you shouldn't trust
- **[lead]** [one line]

---

## Coverage
| Area | Status |
|---|---|
| Devices · Patch lists · Open alerts · Resolved alerts | [complete, or partial and how far] |

[Mode], [window], [timezone] · [n] read-only calls · Patch Posture v[version] (alpha)
Point-in-time reading: the connector has no patch history or third-party compliance.
```

**Format.** Markdown laid out like the template — not a code block, not plain text: a `#`
title, a bold date line, the verdict as a `##` heading with its colour dot, `---` between
sections, the action list as a table, and Coverage as an Area | Status table. Omit any
section that would be empty.

**Writing rules.**
- Lead with the answer: one or two sentences under the verdict, with the key device names
  and numbers in **bold**.
- Action rows start with a verb ("Free up disk on…", "Reboot…", "Deploy…"). The Why cell
  holds the evidence and the ticket number or "No ticket." in one or two short sentences.
- Under the action table, a **Where to start on item 1:** line names the concrete first
  check. Add one for item 2 only when it needs its own.
- Other sections use a bold lead line with short bullets under it, one fact per bullet.
- Raw field and monitor names (`perf_disk_usage_ctx`, `patch.status`) appear only in "Data
  you shouldn't trust" and Coverage. Elsewhere say "disk alerts", "reboot pending".
- Dates as "11 Sep"; times in the user's timezone.
- End Coverage with one line: window or scope, timezone and where it came from, `[n]
  read-only calls`, and the skill name and version. If a fuller run would close a gap,
  offer it in one closing sentence after Coverage — never more than one.

**Fix first:** ranked, at most 10 rows, then "and N more at rank X". Each row: rank,
device, site, class, every reason with its evidence (status, counts, patch name, KB and
code, ticket or "no ticket"), and where to start. End each Why cell with `→ drmm-device-quick-look`
so the technician can go deeper on that device.

**Sites:** one row per site, online devices only. In account mode, list the ten worst
sites by rank 1–3 devices and collapse the rest into "[n] sites fully patched".

**Patch failures:** one row per patch: title and KB, code if known, devices affected
(from the site patch list or the device lists), first and last time seen, tickets.

**Offline — last known:** one bullet per offline device: name, class, offline since,
last-known OS status. Devices offline longer than `dormant_after` are marked "likely
retired — remove or bring back online". In account mode, per-site counts instead of names
when more than 20.

**Data you shouldn't trust** — candidates:
- `InstallError` with no failure evidence in alerts or the patch list
- `patch_ctx` alerts whose `actions` include `TICKET_CREATED` but have no `ticketNumber`
- Unknown `patch.status` or `installStatus` values, reported raw
- Patch alerts whose `diagnostics` name no patch or code
- Devices or sites whose data could not be read

**Coverage** — Area | Status rows and the closing line, covering: calls made, mode, sites and device counts, filters used, patch lists read vs
budget, alert pages read and whether partial (with the oldest alert seen), the window,
timezone and where it came from, non-default parameters, `installStatus` values seen, and
always: "Point-in-time reading; the connector exposes no patch history. Third-party
application compliance is not returned by this connector version."

**HTML.** With `html` on, build the page from `assets/report-template.html` as
`references/html-report.md` describes, instead of the Markdown report.

See `references/example-output.md` for a worked example. Read it before the first run of
a session and match its shape.

---

## Handoffs

| Finding | Hand off to |
|---|---|
| Any device in Fix first, or a single named device | `drmm-device-quick-look` |
| When did the failing patch job run, and what else ran | `drmm-device-timeline` |
| Offline devices marked likely retired | `drmm-stale-and-ghost-devices` |
| Which devices carry an outdated application | `drmm-software-finder` |
| A rank 1 or 2 server with no ticket | `alert-to-ticket-pipeline` |

---

## Quit conditions

- The first `list_sites` call fails twice.
- The in-scope count exceeds `device_budget` and the user has not narrowed it.
- A site's device list cannot be read twice in a row (site mode) — report the rest.
- No in-scope devices — say so; never report GREEN on nothing.

---

## Known gaps

What this skill cannot do yet, and how to tell that it worked, is in
`references/known-gaps.md`. Read it in readme mode, or when the user asks about limits.
