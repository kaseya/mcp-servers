# Patch Posture — known gaps and success measures

## Known gaps

- **No patch history.** No install dates, no time-since-patch, no trend. Server-team ask.
- **Third-party application compliance (`softwareStatus`) is not returned** in v0.4.0.
  Server-team ask: restore it on the device rows.
- **Structured patch alert context** (`result`, `patchUid`, `info`) is not returned; codes
  and names come from `diagnostics` text. Server-team ask.
- `installStatus` value set confirmed only for `INSTALLED` and `APPROVED_PENDING`; no failure
  value has been seen live yet.
- `releaseDate` has no zone and differs by platform for the same patch.
- No alert-type filter on alert lists; patch alerts are found by paging everything. On a
  noisy server one CPU monitor filled 50 resolved alerts in 45 minutes (1 Oct 2026), so the
  7-day failure window is out of reach. Server-team ask: a `monitor_type` filter on
  `list_alerts`.
- Domain controllers cannot be identified reliably without the `Domain Controllers`
  filter; no DC tier yet.
- `lastReboot` is not returned; reboot age is only "30+ days" from the filter.

## Measuring whether this worked

- The team fixes the rank 1 and 2 items before the next patch window.
- A device that looks fully patched but will fail next cycle is caught beforehand.
- Offline devices never inflate or deflate the site's figures.
- Every failure line names the update, not just the device.
- A missing field is reported as "not returned", never guessed.
