# Example output — Patch Posture

Adapted to the drmm v0.4.0 connector from a live check of the Clouds Above IT site on
21 Sep 2026 (made with the earlier connector). Third-party application compliance is not
returned by v0.4.0. The patch-failure row assumes the alert's `diagnostics` name the update
and code; `FAILED` is illustrative — only `INSTALLED` and `APPROVED_PENDING` have been seen
live. The fences only mark the example — the real report is rendered Markdown.
Prompt: *"What's the patch posture at Clouds Above IT?"*

**Start-up note** — its own chat message, before the first Datto RMM call:

```
Patch Posture v0.2.17 · last updated 5 Oct 2026 · read-only · Datto RMM
Developer note: alpha release by the Kaseya Automation Content Team. Check results before acting on them, and report anything odd.
Starting: reading device patch status, patch lists and alerts. This can take a few minutes on a large account; any permission prompts are for read-only Datto RMM tools.
Tip: say "drmm-patch-posture readme" for the full guide and all parameters.
```

**Report:**

````markdown
# Patch Posture: Clouds Above IT
**21 Sep 2026, 10:30 EDT** · 21 devices in scope · 14 online · 7 offline

## 🔴 Verdict: RED
A **SQL Server security update is failing on GC-SQL2019**, and **CAIT-N-FILE2's update store is corrupt** ahead of the next patch cycle.

---

## Fix first

| # | Rank | Task | Why |
|---|---|---|---|
| 1 | 1 · failing update | **Fix the SQL Server update on GC-SQL2019** (Server) | KB5122771 failed 19 Sep 05:00 with 0x80070643. 4 approved updates are waiting behind it. Ticket T20260919.0005. → drmm-device-quick-look |
| 2 | 2 · cycle at risk | **Repair the update store on CAIT-N-FILE2** (Server) | Reports fully patched, but 25 file-system corruption alerts on 18 Sep point inside \Windows\servicing and \Windows\WinSxS. Ticket T20260918.0008. → drmm-device-quick-look |

**Where to start on item 1:** the SQL Server setup log for the 19 Sep 05:00 attempt.
**Where to start on item 2:** check the file system and the component store before the next patch window.

---

## Sites

| Site | Online | OS fully patched | Approved pending | Reboot required | No patch policy | Not approved |
|---|---|---|---|---|---|---|
| Clouds Above IT | 14 | 13 of 14 | 4 | 0 | 0 | 0 |

---

## Patch failures

| Update | KB · code | Devices | First – last seen | Ticket |
|---|---|---|---|---|
| SQL Server 2022 security update | KB5122771 · 0x80070643 | GC-SQL2019 | 19 Sep 05:00 | T20260919.0005 |

---

## What else we found

**Offline — last known** (all 7 offline over 30 days: likely retired, remove or bring back online)
- DEBDR-VSA · Server · since 8 Jul · install error, 1 approved pending
- APP-SRV07, WEB-SRV01, WEB-SRV02 · Servers · since 30–31 May · no patch policy
- 3 more: CTL-WS01, CTL-WS02, APP-SRV08

---

## Coverage

| Area | Status |
|---|---|
| Devices | 21 of 28 in scope (7 non-agent devices excluded) |
| Patch lists | Site 1, device 1 (GC-SQL2019) · `installStatus` seen: INSTALLED, FAILED |
| Open alerts | 1 page, complete |
| Resolved alerts | 1 page, back to 12 Sep — the 7-day window is covered |

Site mode, 14–21 Sep, America/New_York (from the user) · 8 read-only calls · Patch Posture v0.2.17 (alpha)
Point-in-time reading: the connector has no patch history or third-party compliance.
````

## Notes on the example

- **CAIT-N-FILE2 is the finding a status-only report would miss.** It is fully patched,
  yet ranks second, because the corruption sits where Windows installs updates from.
- **Offline devices carry problems too**, but they are last-known and months old, so they
  sit in their own section and never touch the verdict or the site row.
