# Patch Posture — HTML report

Read this only when `html` is set. The data, rules and ranking are exactly those of the
normal run; only the presentation changes. Every number comes from the run — never invent
a value to fill a slot. Leave a section out rather than fill it.

## Build

1. Read `assets/report-template.html`. Copy its `<head>`, including the whole `<style>`
   block, **unchanged**. Add no CSS, scripts or other external resources; the page must read
   correctly without the Google Fonts link.
2. Rebuild `<body>` with the template's elements and class names, section by section, from
   this run's data (mapping below). Escape `&`, `<` and `>` in names.
3. Set `<title>` to `Patch Posture: [scope], [weekday date]` and end with
   `<footer>Patch Posture v[version] (alpha) · [scope] · times in [timezone] · [n] read-only calls</footer>`.
4. **Check before delivering.** The page starts with exactly `<!DOCTYPE html>`,
   `<html lang="en">`, `<head>`, `<meta charset="utf-8">`, nothing between them; it has one
   `<html>`, one `<head>`, one `<style>`, one `<body>`, and no `<script>`. If anything is out
   of place, rebuild from the template. With code execution, check with a short script.
5. Deliver it as an **HTML artifact** with the same title; where artifacts are not
   available, save `patch-posture-[scope]-[yyyy-mm-dd].html` and give the user the file.
6. In the chat, write at most three lines: the verdict sentence, action 1, and the version
   line. Do not repeat the Markdown report.

## Mapping

| Template element | Fill with |
|---|---|
| `header.verdict` | Colour by verdict. Stats: Windows records, online, patch failures (class `good` when 0), reboots pending, offline. |
| `.warn` | Flooded alert history, partial pulls, or a site that could not be read. |
| Fix first `.plan .card` | One card per Fix first row (at most 3 cards; more rows go to a table under them): device as title, site · class · effort, facts (`hot` on the reason it ranks), why = rank and reason, ticket chips. |
| Sites table | One row per site with online Windows devices, columns as in the Markdown Sites table. |
| Offline — last known | Left panel: recently offline devices (`.defer`). Right panel: last-known status counts as `.offrow` bars; class `all` on install errors. |
| Data quality and coverage | `details` "Data-quality flags ([n])" with `.dq` items; `details` "Coverage ([n] API calls)" with four `.cov` boxes (class `partial` when partial) and a note. |
