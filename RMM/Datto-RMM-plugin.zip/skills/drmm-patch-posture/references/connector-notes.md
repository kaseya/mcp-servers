# Patch Posture — connector notes

Reference for the drmm v0.4.0 Datto RMM connector, measured live on 30 Sep 2026.
Read when a field you need is missing, a value looks wrong, or a page fails.

## Page sizes

A tool result larger than about 50 KB fails in Claude Desktop, so never request more than
these per call (sizes measured live on 30 Sep 2026):

| Call | Max per page | Size at that max |
|---|---|---|
| `list_devices` | 100 | ~45 KB |
| `list_alerts` open | 100 | ~45 KB |
| `list_alerts` resolved | 50 | ~35 KB |
| `list_sites` | 100 | ~35 KB (150 measured ~50 KB — too close to the limit) |
| `list_device_software` | 250 | ~25 KB on Windows; macOS lists run past 250 rows of system components |
| `list_patches` | 100 | small |
| `list_components` | 50 | ~23 KB |

If the same page fails twice with HTTP 500, one record in that range is unreadable (seen live:
sites 2,550–2,599 failed at every page size). Retry the range in smaller pages — half, then a
tenth — to recover the rest, and report the range that could not be read.

## Fields by tool

Confirmed against a live drmm v0.4.0 connector.

**Device rows** (`list_devices`): `hostname`, `device_uid`, `siteUid`, `device_type`
(chassis), `operatingSystem`, `online`, `lastSeen` (epoch ms), `rebootRequired`,
`patch{status, installed, approved_pending, not_approved}`, `antivirus{…}`. Site names in
`_enhanced.siteNames`.
- `patch.status` values seen live: `FullyPatched`, `InstallError`, `NoPolicy`, `NoData`,
  `RebootRequired`, `ApprovedPending` (20 devices in the live check). Any other value:
  report it raw and flag it in data quality. Non-Windows devices carry `null`.
- `FullyPatched` means every **approved** patch is installed. Patches not approved sit
  outside it — a device can be `FullyPatched` with patches waiting on approval.
- `installed` looks like a per-cycle count, not a lifetime total (4–6 on every device in
  the first live check). Show it, never rank on it.
- `not_approved` can be large on neglected policies (104 seen on one server).
- **Not in v0.4.0:** `softwareStatus` (third-party application compliance), `lastReboot`,
  `lastAuditDate`. The third-party dimension of the earlier version is therefore not
  reported; say so in coverage.

**Patch lists** (`list_patches`): `patchId`, `title`, `kbArticleId` (may be empty),
`severity` (seen: `CRITICAL`, `IMPORTANT`, `UNSPECIFIED`), `installStatus` (seen live: `INSTALLED`, `APPROVED_PENDING`), `type`
(seen: `SOFTWARE`), `rebootRequired`, `releaseDate` (platform-local time, **no zone** —
show the date only). Site scope adds `devices_affected`. No install date, no history.
`APPROVED_PENDING` is an approved patch waiting to install: name it (title, KB) on the
device's Fix first row under rank 3 — it is pending, not a failure.
Treat any other `installStatus` that is not `INSTALLED` as not installed; values containing
`FAIL` or `ERROR` are failures. Record every value seen in coverage until the set is
confirmed.

**Alerts:** `monitor_type` (`patch_ctx`, `eventlog_ctx`, …), `timestamp` (epoch ms),
`ticketNumber`, `actions`, `diagnostics` (text), `source{device_uid, device_name,
site_uid, site_name}`. v0.4.0 does not return the structured patch context (`result`,
`patchUid`, `info`). Read `diagnostics` for the HRESULT (`0x` + 8 hex digits) and the patch
name (`Found patch '…'`, `Installing patch '…'`, a KB number). Log times inside the text are
device-local; use the alert `timestamp` for times. The text format through v0.4.0 is **not
yet verified live** — record an example here on the first run that sees a patch alert.

**Servicing corruption:** `eventlog_ctx` whose `diagnostics` name `Ntfs`, event `55`, and
a path under `\Windows\servicing` or `\Windows\WinSxS`. These are the folders Windows
stages updates in. Without the path in the text, report it as "file system corruption,
location not reported" — still a cycle-at-risk signal on a server.
