---
name: "drmm-os-lifecycle"
description: Read-only operating-system lifecycle review for a Datto RMM account or chosen sites. Opens with a start-up note (version, expected wait). Reads every device's operating system and build from the device list and checks it against end-of-life data looked up live on endoflife.date to find devices whose OS is out of vendor support, out of support but still eligible for paid extended updates, or ending within the next months — Windows by release and edition, Windows Server, macOS, common Linux releases and ESXi. Ranks what to upgrade, replace or retire, servers first, and keeps long-offline devices apart as last known. Use this whenever the user asks about unsupported, end-of-life, out-of-support or outdated operating systems, Windows 10 end of support, old Windows Server or macOS versions, which devices need an OS upgrade, OS lifecycle planning, or upgrade budgets for a customer — for the whole account or a site. For patch status of supported devices, use drmm-patch-posture instead.
metadata:
  version: "0.1.3"
  last_updated: "2026-10-05"
  type: "Datto RMM Skill"
  stage: "alpha"
  execution: "read-only"
  author: "Kaseya Automation Content Team"
compatibility: Requires the Datto RMM connector (drmm v0.4.0 tool set — the "Datto RMM" desktop extension or the datto-mcp remote server). See "Tools" below.
---

# OS Lifecycle

## Run banner and readme

A full run takes a few minutes, and in Claude Desktop the user sees only a collapsed
progress box while tools run. So the skill's output has two parts: a short start-up note,
written as a chat message once you have read this file and before the first Datto RMM
call (step 0 below), and then the report. The start-up note is these four lines:

```
OS Lifecycle v0.1.3 · last updated 5 Oct 2026 · read-only · Datto RMM
Developer note: alpha release by the Kaseya Automation Content Team. Check results before acting on them, and report anything odd.
Starting: reading your device list and operating systems. This can take a few minutes on a large account; any permission prompts are for read-only Datto RMM tools.
Tip: say "drmm-os-lifecycle readme" for the full guide and all parameters.
```

Then gather the data and write the report. Its Coverage line carries the version and the
alpha mark too, so the reader still sees them if the note scrolls away.

**Readme mode.** When the message contains the word `readme` (with or without a slash) or
asks you to explain this skill: `readme` is a mode word, not a file — do not search for a
README file. Open `references/readme-guide.md` in this skill's folder and follow it.
Gather no data and call no Datto RMM tools.

---

## Goal

Answer one question:

> **Which managed devices run an operating system that is out of vendor support, or will
> be soon — and what do we upgrade, replace or retire first?**

Datto RMM records each device's OS and build, but not whether that OS still receives
security updates. This skill adds that judgement from **endoflife.date, looked up live** at
run time (`references/os-lifecycle.md` says how, and holds a dated snapshot as the offline
fallback). That data decides; the agent never supplies an end date from memory. An OS string the list cannot place is reported as
"not on the lifecycle list", never guessed.

A device out of support is not proof that it is unpatched: Windows 10, Server 2012/R2 and
Server 2016 can receive paid Extended Security Updates (ESU), and the connector cannot see
whether the customer bought them. The report says "ESU status not visible" instead of
calling such a device unprotected.

The skill is diagnostic only. It never upgrades, schedules or changes anything.

---

## Tools

All Datto RMM calls go through the **Datto RMM connector** (drmm v0.4.0). Use these and
nothing else — with one exception: **web fetch or web search, read-only, for end-of-life data**
from endoflife.date as `references/os-lifecycle.md` describes. Never send device, site or
customer data in a web request.

| Purpose | Tool | Notes |
|---|---|---|
| Filter IDs | `list_device_filters` `filter_type: "default"` | Resolve `All Devices`, `All Server O/S`, `Online Devices` by name. |
| Device list with OS | `list_devices` `filter_id: <All Devices>` | `operatingSystem` holds edition and build. `count` is the true total. |
| Server set | `list_devices` `filter_id: <All Server O/S>` | `device_type` is the chassis, not the class. |
| One site | `list_devices` `site_uid` | With `sites`. Exactly one selector per call. |
| Sites | `list_sites` | Only to resolve named sites. |
| End-of-life dates | web fetch / web search | `https://endoflife.date/api/<slug>.json`, one request per OS family found. Without a web tool, use the file's offline tables. |

No per-device calls are needed: the device list carries everything this skill reads.

### Page sizes

Claude Desktop rejects a tool result over about 50 KB. Never request more than 100 devices
per call. If the same page fails twice with HTTP 500, one record in that range is
unreadable: retry the range in smaller pages to read around it, and report the range.

---

## Parameters

Apply the default when not given, and state any non-default value in the coverage
footer. Users set these in plain words ("only Northwind Legal", "look 6 months ahead").

| Parameter | Default | Effect |
|---|---|---|
| `sites` | none | Restrict to named sites (per-site gathering). |
| `horizon_months` | 12 | Devices whose support ends within this many months are "ending soon". |
| `last_known_after` | 30 days | Devices offline longer than this are last known: counted apart, never in the verdict. |
| `include_offline` | true | When false, only devices seen within `last_known_after` are reported at all. |
| `timezone` | the user's | The connector has no account timezone. UTC if unknown — say so. |
| `html` | off | On when the user's message contains the word `html` ("drmm-os-lifecycle html", "as HTML"). Same run, delivered as a styled HTML page: read `references/html-report.md` before writing the report. |

**Reading parameters.** Text in quotes is one value, taken exactly (`"Google Chrome"`,
`sites "- Datto Devices"`). Without quotes, a value runs until the next parameter word
(`version`, `sites`, `days`, `html`, `readme` …, or "for"/"at" before a site). Multi-word
names match as a whole phrase, case-insensitively, never word by word. If a word could
belong to two values, ask once before reading data. Coverage echoes what was understood
(Searched for "Google Chrome" · sites: Northwind Legal).

**Advanced — budgets.** Change these only when a run stops early on a large account.

| Budget | Default | Effect |
|---|---|---|
| `page_budget` | 50 | Device pages (at 100) before stopping and asking to narrow to sites. |

---

## Scope boundary

| In scope | Out of scope |
|---|---|
| OS support status, ESU eligibility, upcoming end dates | Patch status of supported devices → `drmm-patch-posture` |
| Upgrade, replace or retire priorities | Removing dead records → `drmm-stale-and-ghost-devices` |
| Application end of life | → `drmm-software-finder` (it has its own lifecycle list) |

---

## Data gathering

0. **Post the start-up note** from "Run banner and readme" as a chat message, before
   any Datto RMM call below. Then continue straight away; do not wait for a reply.
   Between steps, a one-line progress note is fine ("Devices read, checking lifecycles next").
1. `list_device_filters default` → IDs for `All Devices` and `All Server O/S`.
2. **Budget check.** `list_devices filter_id <All Devices> max 1` → `count`. Above
   `page_budget` × 100, say how many pages it would take and ask to narrow to sites.
3. **Devices.** Page `All Devices` at 100 (or `list_devices site_uid` per named site).
   Page `All Server O/S` and keep its `device_uid` set.
4. Read `references/os-lifecycle.md`. **Look up end-of-life data live** for each OS family
   present (Windows, Windows Server, macOS, each Linux distribution, ESXi): one endoflife.date
   request per family, posted first as one progress line ("Looking up end-of-life dates on
   endoflife.date"). A lookup that fails falls back to the file's tables for that family.
5. Classify every row (Computation).

Retry a failing page once; on a second failure stop paging that collection and mark it
partial. Never retry on `rate_limited` — narrow the scope instead.

### Gotchas

Confirmed against a live drmm v0.4.0 connector.

- `operatingSystem` varies: `Microsoft Windows 10 Pro 10.0.19045`, `Windows 8.1 6.3.9600`
  without "Microsoft", `Mac OS X 10.15.7` and `macOS 12.2`, a bare `Linux`, and even a
  truncated `MS`. Unreadable strings go to "not on the lifecycle list".
- Windows Server 2025 and Windows 11 24H2 share build 10.0.26100, and Server 2019 and
  Windows 10 1809 share 10.0.17763: decide by the name (`Server`), never by build alone.
- The edition decides the Windows end date: Home/Pro end earlier than Enterprise/Education.
- `device_type` is the hardware chassis; class comes from the OS name and the server set.
- `online` is the only authority for current state; `lastSeen` is not a heartbeat. Devices
  reporting `online: true` with a `lastSeen` years old are flagged, not trusted.
- Rows with no `operatingSystem` (network devices, printers, many agentless records) are
  out of scope; mobiles (iOS, iPadOS, Android) are counted as out of scope.

---

## Computation

### Classify each device

1. **Class:** server if `operatingSystem` contains `Server` or the device is in the server
   set; ESXi host if the OS starts with `VMware ESXi`; otherwise workstation.
2. **Release and end date** from the live endoflife.date data (offline: the file's tables),
   using the reading rules in `references/os-lifecycle.md` and the edition for Windows client.
3. **State:** out of support · out of support, ESU possible · ending soon (within
   `horizon_months`) · supported · not on the list.
4. **Current or last known:** current = online, or offline up to `last_known_after`.

### Ranking (the action table)

1. **Current server out of support, no ESU possible** — upgrade or replace first.
2. **Current server out of support, ESU possible** — confirm ESU, then plan the upgrade.
3. **Current ESXi host out of support** — the VMs on it inherit the risk.
4. **Current workstations out of support** — one row per release, with counts per site.
5. **Current servers ending soon** — plan within the horizon.
6. **Current workstations ending soon** — one row per release (e.g. "Windows 11 24H2
   Home/Pro, ends 13 Oct 2026").

Within a rank: online before offline, then the earliest end date, then most devices.
Last-known devices are never ranked; they are counted per release and handed to
`drmm-stale-and-ghost-devices`.

### Verdict

- **RED** — any rank 1–3 item.
- **AMBER** — any rank 4–5 item, or more than a tenth of current workstations ending soon.
- **GREEN** — otherwise.

---

## Output

The start-up note is already written; write the report below it. The reader is a
technician or account manager deciding what to upgrade: lead with the answer, keep lines
short, and put how the data was read at the end.

```markdown
# OS Lifecycle: [account or sites]
**[date time tz]** · [n] devices with an OS · [n] current · [n] last known

## [🔴|🟠|🟢] Verdict: [RED|AMBER|GREEN]
[What drove it, in one or two sentences.]

---

## What to do
| # | Devices | Task | Why |
|---|---|---|---|
| 1 | [n] | **[Upgrade / Replace / Retire / Confirm ESU for] [what]** ([sites]) | [release, end date, online count] |

**Where to start on item 1:** [the concrete first check].

---

## Out of support
| Release | Support ended | ESU until | Servers | Workstations | Online |
|---|---|---|---|---|---|

## Ending within [n] months
| Release | Ends | Devices | Online | Sites |
|---|---|---|---|---|

## By site
| Site | Current devices | Out of support | Ending soon |
|---|---|---|---|

---

## What else we found
**Last known** (offline over [n] days, never in the verdict)
- [counts per state and top releases] → drmm-stale-and-ghost-devices

**Not on the lifecycle list**
- [OS string]: [n] devices

---

## Data you shouldn't trust
- **[lead]** [one line]

---

## Coverage
| Area | Status |
|---|---|
| Devices · Server set · End of life | [complete, or partial; endoflife.date looked up [time], or "snapshot of [date]" when offline] |

[Scope], horizon [n] months, [timezone] · [n] read-only calls · OS Lifecycle v[version] (alpha)
ESU enrolment is not visible to the connector; "ESU possible" means eligible, not enrolled.
```

**Format.** Markdown laid out like the template — not a code block, not plain text: a `#`
title, a bold date line, the verdict as a `##` heading with its colour dot, `---` between
sections, the action list as a table, and Coverage as an Area | Status table. Omit any
section that would be empty.

**Writing rules.**
- Lead with the answer: one or two sentences under the verdict, with the key releases,
  device names and numbers in **bold**.
- Action rows start with a verb. The Why cell gives the release, the end date (and ESU
  date where it applies) and how many are online.
- Name releases the way people know them: "Windows 10 22H2", "Windows 11 24H2 Home/Pro",
  "Windows Server 2012 R2", "macOS 12 Monterey".
- Dates as "14 Oct 2025"; times in the user's timezone.
- Raw OS strings appear only in "Not on the lifecycle list" and Data you shouldn't trust.
- End Coverage with one line: scope, horizon, timezone and where it came from, `[n]
  read-only calls`, and the skill name and version.

**Data you shouldn't trust — candidates:** devices reporting online with a `lastSeen`
years old; truncated or bare OS strings; servers whose name says Server but are missing
from the server set (or the reverse); duplicate hostnames on several releases.

**HTML.** With `html` on, build the page from `assets/report-template.html` as
`references/html-report.md` describes, instead of the Markdown report.

See `references/example-output.md` for a worked example from a live run. Read it before
the first run of a session and match its shape.

---

## Handoffs

| Finding | Hand off to |
|---|---|
| A specific server in detail | `drmm-device-quick-look` |
| Patch state of the supported devices | `drmm-patch-posture` |
| Long-offline devices on old releases | `drmm-stale-and-ghost-devices` |
| Old application versions on these devices | `drmm-software-finder` |

---

## Quit conditions

- The first `list_device_filters` or device page fails twice.
- Projected device pages exceed `page_budget` and the user has not narrowed it.
- No device in scope has an operating system — report that; never report GREEN.

---

## Known gaps

What this skill cannot do yet is in `references/known-gaps.md`. Read it in readme mode, or
when the user asks about limits.
