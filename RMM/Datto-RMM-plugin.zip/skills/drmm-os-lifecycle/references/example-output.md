# Example output — OS Lifecycle

From a live run against a Datto RMM sandbox account on 2 Oct 2026. Device and site names are
replaced; the numbers are real. Match this shape; never copy its numbers.
Prompt: *"Which devices run an unsupported operating system?"*

**Start-up note** — its own chat message, before the first Datto RMM call:

```
OS Lifecycle v0.1.3 · last updated 5 Oct 2026 · read-only · Datto RMM
Developer note: alpha release by the Kaseya Automation Content Team. Check results before acting on them, and report anything odd.
Starting: reading your device list and operating systems. This can take a few minutes on a large account; any permission prompts are for read-only Datto RMM tools.
Tip: say "drmm-os-lifecycle readme" for the full guide and all parameters.
```

**Report:**

# OS Lifecycle: account
**2 Oct 2026, 10:10 CEST** · 1,350 devices with an OS · 12 current · 1,338 last known

## 🔴 Verdict: RED
**ESXi host "ESX-LAB01" runs ESXi 6.7, out of support since 15 Oct 2022**, and reports online. **Three Macs run macOS releases Apple no longer updates**, and **WGR-WS07** (Windows 11 24H2 Home/Pro) loses support on **13 Oct 2026**.

---

## What to do
| # | Devices | Task | Why |
|---|---|---|---|
| 1 | 1 | **Upgrade or replace ESXi host ESX-LAB01** (Dev Lab) | ESXi 6.7, support ended 15 Oct 2022 · reports online, last seen 16 Apr 2024 |
| 2 | 3 | **Upgrade macOS on PCC-MAC02, BSM-MAC01 and HF-MAC03** (Pinecrest Clinic, Brightside Media, Hillford Freight) | macOS 10.15, 12 and 13 — security updates ended 2024–2026 · 2 report online |
| 3 | 1 | **Update WGR-WS07 to Windows 11 25H2** (Westgate Retail) | Windows 11 24H2 Home/Pro ends 13 Oct 2026 · offline since 24 Sep |

**Where to start on item 1:** confirm the host still exists — it reports online but has not been seen since 16 Apr 2024. If it runs VMs, list them before planning the upgrade; if it is gone, retire the record.

---

## Out of support
| Release | Support ended | ESU until | Servers | Workstations | Online |
|---|---|---|---|---|---|
| ESXi 6.7 | 15 Oct 2022 | — | 1 host | — | 1 |
| macOS 12 Monterey | 16 Sep 2024 | — | — | 1 | 1 |
| macOS 13 Ventura | 15 Sep 2025 | — | — | 1 | 0 |
| macOS 10.15 Catalina | 2 Feb 2026 | — | — | 1 | 1 |

## Ending within 12 months
| Release | Ends | Devices | Online | Sites |
|---|---|---|---|---|
| Windows 11 24H2 Home/Pro | 13 Oct 2026 | 1 | 0 | Westgate Retail |

## By site
| Site | Current devices | Out of support | Ending soon |
|---|---|---|---|
| Pinecrest Clinic | 2 | 1 | 0 |
| Dev Lab | 1 | 1 | 0 |
| Brightside Media | 1 | 1 | 0 |
| Hillford Freight | 1 | 1 | 0 |
| Westgate Retail | 1 | 0 | 1 |

6 more sites, 6 current devices: all supported (Windows 11 25H2, Windows Server 2019 and 2022, macOS 26).

---

## What else we found
**Last known** (offline over 30 days, never in the verdict)
- **502 out of support:** Windows 10 1903 (209), Windows 7 SP1 (175), Windows 8.1 (12), older Windows 10 releases; **8 servers** on Windows Server 2003 R2 and 2008/2008 R2; 2 ESXi hosts → drmm-stale-and-ghost-devices
- **238 out of support, ESU possible:** Windows Server 2012 R2 (185, ESU ends 13 Oct 2026), Windows 10 22H2 (43), Windows Server 2012 (6), Ubuntu 20.04 (3), Debian 10 (1)
- **194 ending within 12 months:** Windows Server 2016 (189, ends 12 Jan 2027), Windows 11 23H2 Enterprise/Education (4), Ubuntu 22.04 (1)
- **26 supported**

**Not on the lifecycle list**
- `Linux` with no distribution: 191 devices
- `Mac OS X` with no version: 183 devices
- Fedora 30, openSUSE Leap 42.2, a Windows 11 Insider Preview build and `MS`: 1 each

---

## Data you shouldn't trust
- **Online, but not seen for years** — ESX-LAB01, PCC-MAC02 and BSM-MAC01 report online with a last-seen date of 16 Apr 2024. Item 1 rests on that online flag.
- **Bare OS strings** — 374 last-known records say only `Linux` or `Mac OS X`, so their release cannot be read.
- **Evaluation edition** — OMB-SRV01 runs Windows Server 2019 Standard Evaluation; evaluation licences expire long before the support date.

---

## Coverage
| Area | Status |
|---|---|
| Devices | Complete — 1,554 records; 1,350 with an OS, 4 mobiles out of scope, 200 with no OS |
| Online set | Read today (filter "Online Devices", 11 devices) |
| Server set | From `operatingSystem` and the All Server O/S filter |
| End of life | endoflife.date, looked up 2 Oct 2026 10:09 (Windows, Windows Server, macOS, Ubuntu, RHEL, Debian, ESXi) |

Account, horizon 12 months, Europe/Stockholm (from your location) · 2 read-only calls today · OS Lifecycle v0.1.3 (alpha)
ESU enrolment is not visible to the connector; "ESU possible" means eligible, not enrolled. Offline records came from a full device read two days earlier.
