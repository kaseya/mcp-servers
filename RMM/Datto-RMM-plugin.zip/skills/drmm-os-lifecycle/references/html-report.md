# OS Lifecycle — HTML report

Read this only when `html` is set. The data, rules and ranking are exactly those of the
normal run; only the presentation changes. Every number comes from the run — never invent
a value to fill a slot. Leave a section out rather than fill it.

## Build

1. Read `assets/report-template.html`. Copy its `<head>`, including the whole `<style>`
   block, **unchanged**. Add no CSS, scripts or other external resources; the page must read
   correctly without the Google Fonts link.
2. Rebuild `<body>` with the template's elements and class names, section by section, from
   this run's data (mapping below). Escape `&`, `<` and `>` in names.
3. Set `<title>` to `OS Lifecycle: [scope], [weekday date]` and end with
   `<footer>OS Lifecycle v[version] (alpha) · [scope] · times in [timezone] · [n] read-only calls</footer>`.
4. **Check before delivering.** The page starts with exactly `<!DOCTYPE html>`,
   `<html lang="en">`, `<head>`, `<meta charset="utf-8">`, nothing between them; it has one
   `<html>`, one `<head>`, one `<style>`, one `<body>`, and no `<script>`. If anything is out
   of place, rebuild from the template. With code execution, check with a short script.
5. Deliver it as an **HTML artifact** with the same title; where artifacts are not
   available, save `os-lifecycle-[scope]-[yyyy-mm-dd].html` and give the user the file.
6. In the chat, write at most three lines: the verdict sentence, action 1, and the version
   line. Do not repeat the Markdown report.

## Mapping

| Template element | Fill with |
|---|---|
| `header.verdict` | Colour by verdict (red, amber, green). Stats: current devices, out of support, ending within the horizon, supported (class `good`), last known. |
| `.warn` | Devices reporting online with a last-seen date years old, or a partial device read. |
| What to do `.plan .card` | One card per action row (at most 3; more rows go to a table under them): task as title, sites · device count, facts with `hot` on the release and end date, why. |
| Out of support | Table as in the Markdown; `.sig disk` chip on servers and ESXi hosts. |
| Ending within [n] months | Table as in the Markdown; `.sig bak` chip on the earliest end date. |
| By site | Table of sites with findings; the fully supported sites go in the section subtitle. |
| What else we found | Left panel: last-known states as `.offrow` bars (class `all` on out of support) with the biggest releases in a note. Right panel: a `.defer` list of OS strings not on the lifecycle list. |
| Data quality and coverage | `details` "Data-quality flags ([n])" with `.dq` items; `details` "Coverage ([n] API calls)" with four `.cov` boxes (class `partial` on the ESU box) and a note. |
