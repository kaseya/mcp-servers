# OS Lifecycle — known gaps

- **ESU enrolment is not visible.** The connector cannot tell whether a customer bought
  Extended Security Updates; "ESU possible" means eligible, not enrolled. Server-team ask:
  expose ESU licence or KB-based ESU status on the device record.
- **End-of-life data is looked up live on endoflife.date**, so the run needs a web search or
  fetch tool. Without one, the dated tables in `references/os-lifecycle.md` are used and Coverage
  says so — refresh them with every release; a release newer than the snapshot is then reported
  as "not on the lifecycle list".
- **macOS has no published end dates.** The list uses endoflife.date's reading of Apple's
  practice (roughly the three newest releases get security updates).
- **Linux needs the distribution in the OS string.** A bare `Linux` cannot be classified.
- **Mobiles (iOS, iPadOS, Android) are out of scope.**
- **No hardware compatibility check.** Whether a device can run the next release (for
  example Windows 11 TPM and CPU requirements) needs the audit and is not checked here.

## Measuring whether this worked

- Every out-of-support device names its release and end date, with the source (live lookup or snapshot) in Coverage.
- No device is called unpatched only because its OS is out of support.
- Long-offline devices never raise the verdict.
