# Example output — Device Timeline

From a live run against a Datto RMM sandbox account on 30 Sep 2026. Device, site and user
names are replaced; the numbers are real. Long lists are shortened. The fences only mark the
example — the real report is rendered Markdown, not a code block. On this tenant the activity log failed (HTTP 500), so this shows the alerts-only
fallback; with the activity log, JOB, PATCH, REMOTE and AGENT rows appear too.
Prompt: *"What happened on NWL-APP01 before the disk alert?"*

**Start-up note** — its own chat message, before the first Datto RMM call:

```
Device Timeline v0.1.12 · last updated 5 Oct 2026 · read-only · Datto RMM
Developer note: alpha release by the Kaseya Automation Content Team. Check results before acting on them, and report anything odd.
Starting: reading the device's activity log and alerts. This can take a few minutes on a large account; permission prompts before the report are for read-only tools; nothing runs on the device.
Tip: say "drmm-device-timeline readme" for the full guide and all parameters.
```

**Report:**

````markdown
> ⚠️ **Activity log unavailable** — the device activity-log call failed twice (HTTP 500). "Was it us?" rests on alerts only.

# Device Timeline: NWL-APP01
**30 Sep 2026, 14:26 CEST** · Server · Northwind Legal · window 27 Sep 14:20 – 30 Sep 14:20 · anchor 28 Sep 20:51, disk alert raised

## ⚪ Answer: Cannot tell
The activity log is unavailable. Alert evidence shows **one RMM-side change five hours before the disk alert**: the device moved from site Bluebird Dental to Northwind Legal.

---

## Before the problem

| # | When | What happened | Evidence |
|---|---|---|---|
| 1 | 28 Sep 15:48–20:51, up to 5 h before | **Device moved to site Northwind Legal** | Last alert under the old site at 15:48; the disk alert at 20:51 is the first under the new one. A move applies the new site's monitoring policy. |
| 2 | Since 11 Sep | **The disk was already low** | Open disk alerts from 11 and 26 Sep; a High disk alert fired almost daily 27 Aug – 10 Sep. |
| 3 | 28 Sep 03:17, 17 h 34 min before | **RMM agent load, negligible** | CPU alert ×2 with AEMAgent.exe on top at 1 %. |

---

## Timeline
*Newest first · ▲ = non-alert event in the 24 h before the anchor*

| Time | Type | What | Who | |
|---|---|---|---|---|
| 30 Sep 13:48 | ALERT ↑ | CPU ×2, AEMAgent.exe 1–2 %, open | | |
| 30 Sep 13:43 | USER | CPU alert from 13:33 resolved by hand | j.smith | |
| 30 Sep 13:14–13:16 | ALERT | Device offline for 2 minutes, cleared itself | AUTORESOLVER | |
| 30 Sep 01:16 | LOAD | AEMAgent.exe 35–46 % — RMM agent load | | |
| 30 Sep 00:00–02:02 | ALERT | CPU ×138, all cleared themselves | | |
| 29 Sep 15:59 | LOAD | TiWorker.exe 42–50 % — Windows Update servicing | | |
| 28 Sep 21:10 – 29 Sep 01:59 | ALERT | CPU ×308, all cleared themselves — starts 19 min after the anchor | | |
| **28 Sep 20:51** | **ALERT ↑** | **Disk usage, Moderate, open — the anchor** | | |
| 28 Sep 15:48–20:51 | CHANGE | Device moved to site Northwind Legal (inferred) | | ▲ |
| 28 Sep 03:17 | LOAD | AEMAgent.exe 1 % — RMM agent load | | ▲ |

…21 more rows.

---

## By category
- In the window: 849 alerts raised (844 CPU) · 836 resolved · 16 LOAD rows · 2 USER · 1 CHANGE (inferred)
- JOB, PATCH, REMOTE, AGENT: not available without the activity log

---

## Data you shouldn't trust
- **2 alerts were resolved by a person (j.smith) with no ticket.**
- **Up to 14 CPU alerts in the same second** — several CPU monitors apply to this device.
- **Two 11–12 hour stretches with no alerts at all**; the cause is not visible here.

---

## Coverage

| Area | Status |
|---|---|
| Activity log | Unavailable — 0 pages, failed twice |
| Open alerts | Complete (18) |
| Resolved alerts | 999 read, back to 27 Aug — the window is covered |
| Event-log check | Suggested to a technician (Windows device) |

Window 27–30 Sep, Europe/Stockholm (from the user) · read-only · Device Timeline v0.1.12 (alpha)
````
