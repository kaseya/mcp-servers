# Device Timeline — known gaps and success measures

## Known gaps

- The activity log returns HTTP 500 on some tenants (the sandbox); then "was it us?" rests
  on alert process lists. Fields were verified on another tenant on 5 Oct 2026.
- Activity summaries are cut at 200 characters, which hides job UIDs; job output for past
  jobs cannot be fetched (`get_job_status` only works for jobs from `create_job`).
  Server-team ask: a job-history tool.
- Software carries no install date; local installs show only in Windows' event log, which
  the skill suggests a technician checks — it runs nothing to read it.
- No audit history, so hardware or disk changes between audits are not diffed.
- No event-log reading by RMM. Ask (ComStore): a read-only event-log component, which the
  skill could then offer as a quick job under the component policy.

## Measuring whether this worked

- The technician sees the last RMM action before the problem without opening the portal.
- "Was it us?" is answered with named evidence or explicitly "cannot tell".
- No row claims a cause.
- A partial activity log is never presented as "nothing happened".
- Nothing runs on the device; the event-log check is a suggestion in words.
