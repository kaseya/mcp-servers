# Device Timeline — HTML report

Read this only when `html` is set. The data, rules and ranking are exactly those of the
normal run; only the presentation changes. Every number comes from the run — never invent
a value to fill a slot. Leave a section out rather than fill it.

## Build

1. Read `assets/report-template.html`. Copy its `<head>`, including the whole `<style>`
   block, **unchanged**. Add no CSS, scripts or other external resources; the page must read
   correctly without the Google Fonts link.
2. Rebuild `<body>` with the template's elements and class names, section by section, from
   this run's data (mapping below). Escape `&`, `<` and `>` in names.
3. Set `<title>` to `Device Timeline: [scope], [weekday date]` and end with
   `<footer>Device Timeline v[version] (alpha) · [scope] · times in [timezone] · [n] read-only calls</footer>`.
4. **Check before delivering.** The page starts with exactly `<!DOCTYPE html>`,
   `<html lang="en">`, `<head>`, `<meta charset="utf-8">`, nothing between them; it has one
   `<html>`, one `<head>`, one `<style>`, one `<body>`, and no `<script>`. If anything is out
   of place, rebuild from the template. With code execution, check with a short script.
5. Deliver it as an **HTML artifact** with the same title; where artifacts are not
   available, save `device-timeline-[scope]-[yyyy-mm-dd].html` and give the user the file.
6. In the chat, write at most three lines: the verdict sentence, action 1, and the version
   line. Do not repeat the Markdown report.

## Mapping

| Template element | Fill with |
|---|---|
| `.warn` | Always first when the activity log failed or was partial. |
| `header.verdict` | Colour: amber for RMM activity or agent load, blue for a local change, green for nothing, grey for cannot tell. `.word` = a two-word answer. Stats: quiet time before the anchor, lead-window events, related drops, activity rows. |
| Before the problem | Table: #, when (and how long before the anchor), what happened (bold), evidence. |
| Timeline | Table newest first: time, type, what, who, and a last column with ▲ for lead-window events and a red ◀ on the anchor row. |
| Data quality and coverage | `details` "Data-quality flags ([n])" with `.dq` items; `details` "Coverage ([n] API calls)" with four `.cov` boxes (class `partial` when partial) and a note. |
