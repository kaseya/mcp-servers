# Device Timeline — connector notes

Reference for the drmm v0.4.0 Datto RMM connector, measured live on 30 Sep 2026.
Read when a field you need is missing, a value looks wrong, or a page fails.

## Page sizes

A tool result larger than about 50 KB fails in Claude Desktop, so never request more than
these per call (sizes measured live on 30 Sep 2026):

| Call | Max per page | Size at that max |
|---|---|---|
| `list_devices` | 100 | ~45 KB |
| `list_alerts` open | 100 | ~45 KB |
| `list_alerts` resolved | 50 | ~35 KB |
| `list_sites` | 100 | ~35 KB (150 measured ~50 KB — too close to the limit) |
| `list_device_software` | 250 | ~25 KB on Windows; macOS lists run past 250 rows of system components |
| `list_patches` | 100 | small |
| `list_components` | 50 | ~23 KB |

If the same page fails twice with HTTP 500, one record in that range is unreadable (seen live:
sites 2,550–2,599 failed at every page size). Retry the range in smaller pages — half, then a
tenth — to recover the rest, and report the range that could not be read.

## Fields by tool

**Alerts** (live-verified): `alertUid`, `priority`, `timestamp` (epoch ms), `resolved`,
`resolution{by, on}` (`by` seen: `CAG`, `AUTORESOLVER`, `autoresolver` on auto-resolved alerts — compare case-insensitively), `muted`,
`ticketNumber` (null or empty when none), `actions` (codes such as `TICKET_CREATED`, `COMPONENT`), `diagnostics` (text; absent on offline and component alerts), `monitor_type` (e.g. `perf_resource_usage_ctx`,
`perf_disk_usage_ctx`, `online_offline_status_ctx`, `eventlog_ctx`, `patch_ctx`,
`comp_script_ctx`), `source{device_uid, device_name, site_uid, site_name}`.

**Activity log** (verified live 5 Oct 2026; the sandbox returns HTTP 500 for this call):
`id`, `entity` (e.g. `USER`, `DEVICE`), `category` (e.g. `account`), `action` (e.g. `login`),
**`date` — epoch seconds with decimals** (e.g. `1791191241.299`; alerts and `lastSeen` are
milliseconds), `hostname` (null for account events), `actor` (user name or system),
`summary` (JSON text, cut at about 200 characters), `has_output`. Paging: pass
`_enhanced.next_search_after` back as `search_after`. `_enhanced.hostnames` is keyed by
numeric device ID. Summaries can hold a user's e-mail and source IP — never repeat them.
