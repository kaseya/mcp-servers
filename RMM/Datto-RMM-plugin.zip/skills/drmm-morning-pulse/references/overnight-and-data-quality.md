# Morning Pulse — overnight execution and data-quality flags

## Overnight execution

Two sources, used together:

- **Activity log** for the window (`list_activity_logs account_wide` with the window's
  `time_from`/`time_to`). Count jobs, components and patch runs by outcome where the entry
  states one, and keep entries naming a server. Entry fields (verified 5 Oct 2026): `entity`,
  `category`, `action`, **`date` in epoch seconds** (not milliseconds), `hostname`, `actor`,
  `summary` (cut at about 200 characters), `has_output`. Numeric device IDs appear as keys of
  `_enhanced.hostnames`. Never repeat e-mail addresses or IPs found in summaries.
- **Alerts inside the window**: `patch_ctx` for patch failures, `comp_script_ctx` and
  `backup_management_ctx` for job and backup outcomes. Alerts show **failures only**.

If the activity log failed or returned nothing, say so in one line and report failures
only; never report success counts that did not come from the log.

**Devices needing attention:** servers and network devices with an overnight failure, with
repeat count. Cap at ten.

## Data-quality flags

- Monitoring gaps: infrastructure offline with no offline alert (from a complete alert pull or
  per-device reads only — see "Partial alert pulls")
- Critical alerts on devices not in the inventory
- Alerts whose `actions` include `TICKET_CREATED` or `TICKET_PENDING` but whose
  `ticketNumber` is null or empty (seen live) — a ticket may exist that the alert cannot
  point to
- Tickets auto-closed when their alert auto-resolved (`TICKET_CLOSED_CALL` in `actions`) —
  a ticket number is not proof anyone is working it
- Hostnames suggesting a device class the classification disagrees with
- Delivery-failure codes on a single device (below the plan threshold)
- Alerts whose `source.site_name` differs from the device's current site — the device was
  moved or re-enrolled and old-site alerts are still open (seen live)
- Datto networking devices with unknown drop time
- Duplicate enrolments (same hostname, same site, same class, both online)
- Cross-site simultaneous drops
- Sites with zero devices
- Activity log empty or unavailable
- Infrastructure reporting `online: true` while an offline alert is still open, or with a
  `lastSeen` years old (seen live on an ESXi host: online, offline alert open since July) —
  its online state cannot be trusted; say so rather than counting it as up
