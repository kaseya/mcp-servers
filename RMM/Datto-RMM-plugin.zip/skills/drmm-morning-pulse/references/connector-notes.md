# Morning Pulse — connector notes

Reference for the drmm v0.4.0 Datto RMM connector, measured live on 30 Sep 2026.
Read when a field you need is missing, a value looks wrong, or a page fails.

## Page sizes

A tool result larger than about 50 KB fails in Claude Desktop, so never request more than
these per call (sizes measured live on 30 Sep 2026):

| Call | Max per page | Size at that max |
|---|---|---|
| `list_devices` | 100 | ~45 KB |
| `list_alerts` open | 100 | ~45 KB |
| `list_alerts` resolved | 50 | ~35 KB |
| `list_sites` | 100 | ~35 KB (150 measured ~50 KB — too close to the limit) |
| `list_device_software` | 250 | ~25 KB on Windows; macOS lists run past 250 rows of system components |
| `list_patches` | 100 | small |
| `list_components` | 50 | ~23 KB |

If the same page fails twice with HTTP 500, one record in that range is unreadable (seen live:
sites 2,550–2,599 failed at every page size). Retry the range in smaller pages — half, then a
tenth — to recover the rest, and report the range that could not be read.

## Fields by tool

Confirmed against a live drmm v0.4.0 connector.

**Devices** (`list_devices`): `hostname`, `device_uid`, `siteUid`, `device_type`,
`operatingSystem`, `online` (boolean), `lastSeen` (epoch **milliseconds**),
`rebootRequired`, `patch{status, installed, approved_pending, not_approved}`,
`antivirus{product, status}`. Site names in `_enhanced.siteNames`.

`online` is the authority for current state. `lastSeen` is **not a heartbeat** — online
servers routinely carry values days old, and ESXi hosts show `online: true` with `lastSeen`
from years ago. On an offline agent device, `lastSeen` approximates when it dropped, which
is the only use this skill makes of it.

**Not in v0.4.0:** `deviceType.category`, `softwareStatus`, `lastReboot`, internal IP,
UDFs. Rules that used them are rewritten below.

**Alerts** (`list_alerts`): `alertUid`, `priority` (`Critical`, `High`, `Moderate`, `Low`,
`Information` — reflects how the monitor was configured, not how severe the problem is),
`timestamp` (epoch ms), `resolved`, `resolution{by, on}` (`by` seen: `CAG`,
`AUTORESOLVER`, `autoresolver` — compare case-insensitively), `muted`, `ticketNumber` (null or empty string when none), `diagnostics`
(monitor output as text — **absent** on offline and some performance alerts), `actions`
(list of codes, seen: `EMAIL_SENT`, `TICKET_PENDING`, `TICKET_CREATED`, `COMPONENT`),
`monitor_type` (the old `alertContext.@class`, e.g. `online_offline_status_ctx`,
`perf_disk_usage_ctx`, `perf_resource_usage_ctx`, `perf_mon_ctx`, `eventlog_ctx`,
`patch_ctx`, `comp_script_ctx`, `backup_management_ctx`), `source{device_uid,
device_name, site_uid, site_name}`.

**Gone from alerts in v0.4.0:** the structured context fields (`freeSpace`,
`totalVolume`, event `source`/`code`, patch `result`, component `samples`) and
`alertMonitorInfo.createsTicket`. Rules that matched on them now read `diagnostics` text,
and say so when the text is missing. Component-monitor alerts (`comp_script_ctx`) were
seen with **no** `diagnostics`.

## Live evidence behind the rules

Why some rules in `SKILL.md` exist, from live runs:
- Flooding: an offline policy raised 966 alerts on long-dead gear in one hour (30 Sep 2026),
  filled every account-wide page and hid an online server's High disk and service alerts
  from 11–28 Sep. Hence the per-device open-alert step.
- Resolved alerts: in the first live run the most important finding, a SQL server at 2 %
  free disk, existed only as a resolved alert.
- `device_type`: 366 Windows Servers carried `Other`; a firewall was categorised as a
  printer. Live values include `Desktop`, `Portable`, `Notebook`, `Laptop`, `MacBook Pro`,
  `Main System Chassis`, `Server`, `Other`, `Unknown`, `ESXi Host`, `Network Device`,
  `Router`, `Firewall`, `Switch`, `Network Appliance`, `UPS`, `SAN`, `NAS`, `Printer`,
  `iPad`, `iPhone`, `Datto …`, or none.
- Monitoring gaps caught an Exchange server offline six days with no alert. With partial
  alert pulls the same account gave 166 "gaps" at 1,000 alerts read and 142 at 1,500.
- Dormant alerts: 22 of 24 critical alerts were an offline policy applied to long-dead
  servers in a two-day burst.
- Delivery codes seen: `TICKET_CREATION_ERROR`; also expected `WEBHOOK_EXECUTION_ERROR`.
  v0.4.0 gives the code only, not the HTTP status, so an expired credential cannot be told
  apart.
- Cross-site: an ESXi host at one site dropped in the same two minutes as five servers at
  another.
- Ranking: oldest-first would have put a month-old replication warning above a SQL server
  at 2 % free; stopping the plan at the first misfit left an hour idle while a 30-minute
  webhook fix waited at rank 5.
- `diagnostics` text format is not yet verified live for disk, patch and event-log alerts;
  record an example on the first run that sees one.

**Activity log** (verified live 5 Oct 2026):
`id`, `entity` (e.g. `USER`, `DEVICE`), `category` (e.g. `account`), `action` (e.g. `login`),
**`date` — epoch seconds with decimals** (e.g. `1791191241.299`; alerts and `lastSeen` are
milliseconds), `hostname` (null for account events), `actor` (user name or system),
`summary` (JSON text, cut at about 200 characters), `has_output`. Paging: pass
`_enhanced.next_search_after` back as `search_after`. Summaries can hold a user's e-mail and
source IP — never repeat them.
