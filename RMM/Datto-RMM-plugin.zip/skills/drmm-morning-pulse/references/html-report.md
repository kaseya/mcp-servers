# Morning Pulse — HTML report

Read this only when `html` is set. The data, the rules and the ranking are exactly those of
the normal run; only the presentation changes. Every number on the page comes from the
run — never invent a value to fill a slot. Leave a section out rather than fill it.

## Build

1. Read `assets/report-template.html`. Copy its `<head>` — including the whole `<style>`
   block — **unchanged**. Do not add CSS, scripts or other external resources; the Google
   Fonts link already in the template is the only one, and the page must read correctly
   without it.
2. Rebuild `<body>` with the same elements and class names as the template, section by
   section, from this run's data (mapping below). Escape `&`, `<` and `>` in names.
3. Set `<title>` to `Morning Pulse: [account], [weekday date]`.
4. Deliver it as an **HTML artifact** with the same title. Where artifacts are not
   available, save it as `morning-pulse-[account]-[yyyy-mm-dd].html` and give the user the
   file.
5. **Check before delivering.** The page must start with exactly these lines, with
   nothing between them:
   ```
   <!DOCTYPE html>
   <html lang="en">
   <head>
   <meta charset="utf-8">
   ```
   It must contain one `<html>`, one `<head>`, one `<style>` and one `<body>`, and no
   `<script>`. A stray tag or stray text before the `<style>` block breaks every colour on
   the page, so if anything is out of place, rewrite the page from the template. When code
   execution is available, check this with a short script rather than by eye.
6. In the chat, after the artifact, write at most three lines: the verdict sentence, plan
   item 1, and the version line (`Morning Pulse v[version] (alpha) · [n] read-only calls`). Do not
   repeat the Markdown report.

## Mapping, top to bottom

| Template element | Fill with |
|---|---|
| `header.verdict` | Add class `red`, `amber` or `green`. `.word` = Red / Amber / Green. `.sub` = run date and "Data through [time tz]". |
| `.acct` · `h1.headline` | "Morning Pulse for [account]" · the verdict sentence, one or two sentences. |
| `.stats` | Sites, devices, infrastructure, servers at risk (tier 2 count), new overnight drops. Add class `good` to a stat that is 0 and good news. |
| `.warn` | Only for account-wide warnings: alert delivery failing, activity log unavailable, a partial pull that may hide problems. One block each, at most two. Omit when none. |
| `.timeline .track` | One `.blk` per plan item, classes `b1`, `b2`, `b3`… in plan order. Set `style="flex:[minutes ÷ 30]"` so widths match the effort. Name and effort inside; `aria-label` lists the plan in words. |
| `.axis` | One label per hour of capacity (0h … [n]h), evenly spaced. |
| `.cap` | What was dropped for capacity, and that it is not because it is low risk. Omit when nothing was dropped. |
| `.plan .card` | One card per plan item, classes `p1`, `p2`, `p3` matching the blocks. `.step` number, `h3` device, `.site` site and effort. `.facts`: the evidence, with class `hot` on the facts that rank it, then the "start with" check. `.why`: why it ranks there. `.tickets`: one `.tk` per ticket; `.tk.none` for "No ticket". |
| Servers at risk table | One row per tier 2 server, ranked as in the plan. `.sig` chips: `disk`, `bak` (backup), `ntfs` (file system), `ad` (AD replication). Age bar width = days since the latest signal ÷ the largest value in the table × 100 %; class `fresh` when 7 days or less. Today: `.status.in` "Plan #n", or `.status.out` "Deferred". |
| `.grid2` left panel, Not in the plan | `.defer` rows with the rank as `.r`, device in bold, problem and effort band; `.route` "Next: [skill]". `.note` lines for counts handed to other skills. |
| `.grid2` right panel, Long-term offline | One `.offrow` per site, most offline first, at most 10: bar width = offline ÷ site infrastructure × 100 %, class `all` when the whole site is dormant; count as "offline / total". Legend unchanged. `.note` for alerts on dormant devices and dark sites. |
| Overnight repeat offenders | One `.flapcard` per repeated overnight failure or flap, at most four. `.big` = count overnight. `.dots`: one `<i>` per event (at most 60), class `on` for events inside the window. Section head: window, patch failures, backup failures. |
| Data quality and coverage | `details` "Data-quality flags ([n])" with `.dq` items. `details` "Coverage ([n] API calls)" with four `.cov` boxes (sites, devices, open alerts, resolved alerts — class `partial` when partial) and a note on anything else partial and non-default parameters. |
| `footer` | `Morning Pulse v[version] (alpha) · [account] · times in [timezone] · [n] read-only calls` |

When a whole section has nothing in it (no servers at risk, no repeat offenders), leave out
its `<section>` entirely.
