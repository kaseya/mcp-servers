# Example output — Morning Pulse

From a live run against a Datto RMM sandbox account on 1 Oct 2026. Device, site and user
names are replaced; the numbers are real. This is the house format for every Datto RMM
skill: copy its shape. The fences below only mark where the example starts and ends — the
real report is rendered Markdown, not a code block.
Prompt: *"drmm-morning-pulse"*

**Start-up note** — its own chat message, before the first Datto RMM call:

```
Morning Pulse v0.2.15 · last updated 5 Oct 2026 · read-only · Datto RMM
Developer note: alpha release by the Kaseya Automation Content Team. Check results before acting on them, and report anything odd.
Starting: reading your sites, devices and alerts. This can take a few minutes on a large account; any permission prompts are for read-only Datto RMM tools.
Tip: say "drmm-morning-pulse readme" for the full guide and all parameters.
```

**Report:**

````markdown
# Morning Pulse: Datto RMM sandbox
**1 Oct 2026, 14:20 CEST** · 2,613 sites · 1,552 devices · 13 online (7 online infrastructure)

## 🔴 Verdict: RED
**NWL-APP01**, the only online server, is down to **5.2 % free on C:**. It has had disk alerts on three separate days and nobody has a ticket for it.

---

## The first 3 hours
*Capacity: 3 h · 1 technician · 3 h planned*

| # | Effort | Task | Why |
|---|---|---|---|
| 1 | Session, 2 h | **Free up disk on NWL-APP01** (Northwind Legal) | Only 2.6 GB free of 50 GB. Disk alerts from 11, 26 and 28 Sep. No ticket. |
| 2 | Quick, 30 min | **Schedule its pending reboot** | A reboot is pending after patching. Do this after item 1, otherwise the install may fail for lack of space. |
| 3 | Quick, 30 min | **Review the CPU monitor on the same server** | 88 self-closing CPU alerts since 01:09, plus 8 still open. The top process is the RMM agent itself, so this is noise. |

**Where to start on item 1:** Windows Update servicing ran overnight, so check the servicing store (WinSxS) and the patch cache first.

---

## What else happened

**The server dropped offline twice today**
- NWL-APP01 was offline 12:08–12:13 and 13:50–13:55.
- Each drop raised a Critical offline alert that auto-resolved. The cause is unknown.
- This could be linked to the disk problem. Use drmm-device-timeline to dig in.

**Overnight jobs**
- Patch failures: 0 · backup alerts: 0 · component alerts: 0.
- The activity log was unavailable (HTTP 500), so job successes can't be confirmed. Only failures are reported.

**Offline devices**
- No new infrastructure drops were found.
- 1,536 devices have been offline for more than 7 days, including 399 servers. This is long-term state, not news.
- Of the 3 devices that went offline in the last 7 days, only 1 is identified (HF-WS022, a workstation).

---

## Not in today's plan

- **1,536 long-term offline devices** → drmm-stale-and-ghost-devices
- **Older alerts on NWL-APP01:**
  - a "NetLogon started" service alert (26 Sep)
  - a performance-monitor alert (26 Sep)
  - a component alert open since 21 Aug, whose output the connector doesn't expose
- **Workstation alerts:**
  - HF-WS022 has 25 open alerts and has been offline since 30 Sep.
  - ACC-LT014 has 1 open alert.
- **CL-BDR01:** one offline flap at 14:11 that fixed itself within 4 minutes.

---

## Data you shouldn't trust

- **Four devices report "online" but haven't been seen in months or years:**
  - two ESXi hosts, last seen April 2024; LAB-ESX01 also has an offline alert open since July
  - BSM-NAS01, last seen February 2025
  - WGR-TEST01, last seen February 2026
- **NWL-APP01** has 5 open alerts still tagged with its old site, "Bluebird Dental".
- **About 90 offline alerts on long-dead devices** re-fired within seconds of each other on 29 Sep. This is the policy firing on dead gear, not an incident.
- **No alert read carries a ticket number**, so nothing visible is being tracked.

---

## Coverage

| Area | Status |
|---|---|
| Sites | 100 of 2,613 read. The account-wide site-down check was not run. |
| Devices | Online set complete. Offline devices counted via filters only. |
| Open alerts | Partial (100 read). All 7 online infrastructure devices were checked individually. |
| Resolved alerts | Covers 01:09 to now. The 18:00–01:09 part of the window is missing. |
| Activity log | Unavailable (HTTP 500 twice). |

Window: 30 Sep 18:00 to 1 Oct 14:20, Europe/Stockholm (from your location) · 18 read-only calls · Morning Pulse v0.2.15 (alpha)

I can do a full-coverage run (about 20 more calls) to fill the gaps and identify the 2 unknown recent drops.
````
