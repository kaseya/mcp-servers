# Morning Pulse — known gaps and success measures

## Known gaps

- Resolved alerts have no date filter; covering a weekend can take several pages. Server-team ask.
- Structured alert context (disk sizes, event source/code, patch result, component samples)
  is not returned in v0.4.0; rules read `diagnostics` text, which is absent on component
  alerts. Server-team ask: return `alertContext`.
- No account timezone tool. Server-team ask: expose account settings.
- `lastReboot`, `softwareStatus` and `createsTicket` are not returned. Server-team ask.
- The activity log returns HTTP 500 on some tenants (the sandbox); overnight jobs then come
  from alerts only.
- No delta mode: a second run the same day re-pulls every device page.
- Open alerts carry no total count; alert coverage beyond `alert_page_budget` is unknown.
- Tier 2 rules match on alert text for backup and AD replication, which varies by monitor.
- Ownership still means "older than `escalation_age`"; `ticketNumber` is shown but not ranked.
- No antivirus or security section (→ `drmm-security-coverage-gaps`).
- Stateless: "new drop" means inside the window, not "new since the last briefing."

## Measuring whether this worked

- A technician starts item one within two minutes, without opening the console.
- The plan contains nothing that was already broken last week.
- An empty plan on a quiet morning is reported as empty, not padded.
- Tier 2 items are fixed before they become tier 1 items on a later run.
- No overnight event is missed because its alert auto-resolved.
- Partial data is never presented as complete.
