---
name: "drmm-morning-pulse"
description: Daily read-only operations briefing for a Datto RMM account. Opens with a short start-up note naming its version and that the run takes a few minutes. Reads devices and open alerts, counts offline servers and network devices per site, separates new overnight drops from long-dead gear, finds servers about to fail from alert types rather than alert priority, and reads resolved alerts and the overnight activity log to recover what flapped, ran or failed overnight. Produces a ranked plan for the team's first hours of the day, ordered by customer impact rather than alert count. Use this whenever the user asks what broke overnight, wants a morning or daily operations briefing, asks where the team should start today or what to work on first, asks which customers are worst affected, asks what ran or failed overnight, or opens the day with any general "how are we doing" question about the RMM estate. Prefer it over ad-hoc alert listing for whole-account questions.
metadata:
  version: "0.2.15"
  last_updated: "2026-10-05"
  type: "Datto RMM Skill"
  stage: "alpha"
  execution: "read-only"
  author: "Kaseya Automation Content Team"
compatibility: Requires the Datto RMM connector (drmm v0.4.0 tool set — the "Datto RMM" desktop extension or the datto-mcp remote server). See "Tools" below.
---

# Morning Pulse

## Run banner and readme

A full run takes several minutes, and in Claude Desktop the user sees only a collapsed
progress box while tools run. So the skill's output has two parts: a short start-up note,
written as a chat message once you have read this file and before the first Datto RMM
call (step 0 of "Order of operations"), and then the report. The start-up note is these four lines:

```
Morning Pulse v0.2.15 · last updated 5 Oct 2026 · read-only · Datto RMM
Developer note: alpha release by the Kaseya Automation Content Team. Check results before acting on them, and report anything odd.
Starting: reading your sites, devices and alerts. This can take a few minutes on a large account; any permission prompts are for read-only Datto RMM tools.
Tip: say "drmm-morning-pulse readme" for the full guide and all parameters.
```

Then gather the data and write the report. Its Coverage line carries the version and the
alpha mark too, so the reader still sees them if the note scrolls away.

**Readme mode.** When the message contains the word `readme` (with or without a slash) or
asks you to explain this skill: `readme` is a mode word, not a file — do not search for a
README file. Open `references/readme-guide.md` in this skill's folder and follow it.
Gather no data and call no Datto RMM tools.

---

## Goal

Give an MSP operations team, in under two minutes of reading, an ordered answer to one
question:

> **What should we spend our first hours on today to make the most impact for our
> customers?**

That question, not "what is broken," governs every decision in this document. A finding
that is true but would not change how the morning is spent does not belong near the top of
the output, and several true findings do not belong in the output at all.

The most common true finding on a real account is **"nothing new broke."** Most offline
servers on most accounts have been offline for weeks. Saying so plainly is a valid and
valuable briefing. Promoting old dead gear into the plan to fill it is the failure this
skill most needs to avoid.

Morning Pulse is diagnostic only. It never remediates, never creates tickets, never mutes
or resolves an alert. It produces a ranked work plan that a human decides to act on.

---

## Tools

All calls go through the **Datto RMM connector** (drmm v0.4.0). Use these and nothing
else; never call a write tool (`resolve_alert`, `update_device_udfs`, `create_job`).

| Purpose | Tool | Notes |
|---|---|---|
| Access check, sites, counts | `list_sites` | First call is the access check. `devices{total, online, offline}` per site; `count` is the true total. |
| Filter IDs | `list_device_filters` `filter_type: "default"` | Resolve `All Devices`, `All Server O/S`, `Reboot > 30 days` **by name**. |
| Device inventory | `list_devices` `filter_id: <All Devices>` | The only account-wide list. `count` is the true total. |
| Server set | `list_devices` `filter_id: <All Server O/S>` | See "Device class". |
| Open alerts, account-wide | `list_alerts` `status: "open"`, `account_wide: true` | Newest first. Can be flooded — see step 6. |
| Open alerts per device | `list_alerts` `device_uid`, `status: "open"` | Complete for one device. Used for every online infrastructure device. |
| What flapped overnight | `list_alerts` `status: "resolved"`, `account_wide: true` | Newest first, **no date filter**. |
| Per-device history | `list_alerts` `device_uid`, `status: "resolved"` | Repeat counts. |
| Overnight activity | `list_activity_logs` `account_wide: true`, `time_from`, `time_to` | **Both times required.** Page with `search_after`. |
| Disk confirmation | `get_device_audit` | Only for tier 2 disk candidates whose alert gives no numbers. |

If a tool fails, say so and degrade: the skill runs without resolved alerts or the activity
log, but not without sites, devices and open alerts.

### Page sizes

Claude Desktop rejects a tool result over about 50 KB. Per call, never request more than:
devices 100, open alerts 100, resolved alerts 50, sites 100, device software 250 (a Mac
needs two or more pages), patches 100, components 50. If the same page fails twice with
HTTP 500, one record in that range is unreadable: retry the range in smaller pages to read
around it, and report the range. Measured sizes: `references/connector-notes.md`.

---

## Parameters

Apply the default when not given, and state any non-default value in the coverage
footer. Users set these in plain words ("only Northwind Legal", "look back 14 days").

| Parameter | Default | Effect |
|---|---|---|
| `hours` | 3 | Size of the work plan window. |
| `technicians` | 1 | Plan capacity is `hours × technicians`. |
| `sites` | none | Restrict the run to named sites (then page `list_devices site_uid` per site instead of `All Devices`). |
| `overnight_from` | 18:00 previous working day | Start of the overnight window. A Monday run covers the weekend. |
| `timezone` | the user's | The connector has no account timezone. UTC if unknown — say so. |
| `dormant_after` | 7 days | Offline longer than this is long-term state, not news. |
| `escalation_age` | 2 hours | Age at which an open critical alert is flagged unowned. Suppressed when the window exceeds 24 hours. |
| `html` | off | On when the user's message contains the word `html` ("drmm-morning-pulse html", "as HTML"). Same run, delivered as a styled HTML page: read `references/html-report.md` before writing the report. |

**Reading parameters.** Text in quotes is one value, taken exactly (`"Google Chrome"`,
`sites "- Datto Devices"`). Without quotes, a value runs until the next parameter word
(`version`, `sites`, `days`, `html`, `readme` …, or "for"/"at" before a site). Multi-word
names match as a whole phrase, case-insensitively, never word by word. If a word could
belong to two values, ask once before reading data. Coverage echoes what was understood
(Searched for "Google Chrome" · sites: Northwind Legal).

**Advanced — budgets.** Change these only when a run stops early on a large account.

| Budget | Default | Effect |
|---|---|---|
| `page_budget` | 50 | Device pages (at 100) before the skill stops and asks. |
| `alert_page_budget` | 10 | Account-wide open-alert pages (at 100) before the pull stops and is marked partial. |
| `infra_alert_budget` | 50 | Online infrastructure devices whose open alerts are read one by one. |
| `resolved_page_budget` | 30 | Resolved-alert pages (at 50). |
| `activity_page_budget` | 5 | Activity-log pages. |

---

## Scope boundary

| In scope | Out of scope |
|---|---|
| New infrastructure drops, ranked | Long-dead devices and names behind a count → `drmm-stale-and-ghost-devices` |
| Servers about to fail, by alert type | Per-device deep diagnosis → `drmm-device-quick-look` |
| Overnight patch and job failures | Patch state across the estate → `drmm-patch-posture` |
| Ranking sites by customer impact | Alert threshold tuning → `drmm-alert-noise-review` |
| | A question about one named device → `drmm-device-quick-look` |

---

## Data gathering

**Full pull**: device class and per-site denominators decide almost every number.

**Large accounts.** When `All Devices` exceeds `page_budget`, do not stop: site-down tests
need only `list_sites` counts. Page only the infrastructure filters (`All Server O/S`,
`All Network Devices`, `All Firewalls`, `All Routers`, `All Switches`, `ESXi`,
`All Datto Networking Devices`) and say so in coverage.

### Order of operations

0. **Post the start-up note** from "Run banner and readme" as a chat message, before step 1.
   Then continue straight away; do not wait for a reply. Between steps, a one-line progress
   note is fine ("Devices read, reading alerts next").
1. **Sites.** Page `list_sites`. Keep `uid`, `name`, `onDemand`, `devices`. A failure on
   the first call twice means stop.
2. **Filters.** `list_device_filters default` → IDs for `All Devices`, `All Server O/S`,
   `Reboot > 30 days`.
3. **Budget check.** `list_devices filter_id <All Devices> max 1` → `count`. Divide by 100.
   Above `page_budget`, stop and ask (or suggest `sites`).
4. **Devices.** Page `All Devices` at 100. Page `All Server O/S` and keep its
   `device_uid` set. Page `Reboot > 30 days` and keep its set.
5. **Open alerts, account-wide.** Page newest-first until exhausted or
   `alert_page_budget` is reached. Stopping at the budget is normal; mark alerts partial and
   state the oldest timestamp seen.
6. **Open alerts per online infrastructure device.** For every online server, ESXi host and
   network device (cap `infra_alert_budget`), `list_alerts device_uid status open`. Merge with
   step 5 by `alertUid`. **Do not skip this step.** Account-wide pages can be flooded: live,
   966 offline alerts on dead gear in one hour hid an online server's disk alerts.
7. **Resolved alerts in the window.** Page `list_alerts resolved account_wide` and keep only
   those whose `timestamp` falls inside the overnight window; stop when a page's oldest alert
   predates the window or at `resolved_page_budget`. Most monitors auto-resolve within
   minutes, so overnight disk dips, backup pauses and patch failures often exist only here.
8. **Activity log.** `list_activity_logs account_wide: true, time_from: <window start>,
   time_to: <now>` (ISO 8601 with `Z`), following `search_after` to
   `activity_page_budget`. See `references/overnight-and-data-quality.md`.
9. **Repeat counts.** For the devices behind the top ten plan candidates,
   `list_alerts device_uid status resolved` and count how many nights the same problem
   appeared.
10. **Disk confirmation.** For tier 2 disk candidates whose alert carried no numbers,
   `get_device_audit` (cap 10) and read `logicalDisks`.

### Device class

`device_type` is the **hardware chassis type**, not the RMM category (Windows Servers show
as `Main System Chassis` or `Other`; it can be missing). Classify in this order:

1. **Server** — in the `All Server O/S` set, `operatingSystem` contains `Server`, or
   `device_type` = `Server`. Check this first: it is the only rule that finds servers typed
   `Other`.
2. **ESXi host** — `device_type` = `ESXi Host`.
3. **Network** — `device_type` is `Network Device`, `Router`, `Firewall`, `Switch`,
   `Network Appliance`, `UPS`, `SAN` or `NAS`, or starts with `Datto `.
4. **Printer** — `device_type` contains `Printer`.
5. **Workstation** — anything else with a non-null `operatingSystem` (laptop when
   `device_type` is `Portable`, `Notebook`, `Laptop`, `MacBook` or `Sub Notebook`).
6. **Other** — the rest.

Infrastructure is Server, ESXi host and Network. Not infrastructure: workstations,
printers and other.

Flag hostnames that suggest another class (firewall, fw, switch, sw, router, srv, dc) in
data-quality; never reclassify silently. Datto networking devices can report offline with
a current `lastSeen`: count them as infrastructure, drop time unknown, and flag it.

### Budget and failure rules

Retry a failing page once; on a second failure stop paging that collection and label every
number from it partial. If sites or devices cannot be pulled, report and stop. Never retry
on `rate_limited` — narrow the scope instead.

### Gotchas

Confirmed against a live drmm v0.4.0 connector. The full field list for each tool is in
`references/connector-notes.md`; read it when a field you need is missing or a value looks wrong.

- `online` is the only authority for current state. `lastSeen` is **not a heartbeat**:
  online servers carry values days old and ESXi hosts years old. Use `lastSeen` only on an
  offline device, as the approximate drop time.
- `priority` is how the monitor was configured, not how severe the problem is. Never rank
  on it.
- Compare `resolution.by` case-insensitively (`CAG`, `AUTORESOLVER`, `autoresolver` mean
  the alert cleared itself). `ticketNumber` is null **or** an empty string when there is
  no ticket.
- Alerts carry no structured context; read the `diagnostics` text (see below).
- For account-wide alerts, `count` is the page size, not a total. Follow `next_page`.
- Not returned at all: `deviceType.category`, `softwareStatus`, `lastReboot`, IP
  addresses, UDFs.

---

## Computation

Read `references/overnight-and-data-quality.md` before writing the overnight summary and
the Data quality details: it holds the rules for both.

### Definitions

- **Offline** — `online` is false. Nothing else.
- **New drop** — an offline infrastructure device whose `lastSeen` falls inside the
  overnight window. This is the only offline state that is news.
- **Long-term offline** — an offline infrastructure device that is not a new drop.
- **Dormant** — offline longer than `dormant_after`.
- **Unknown drop time** — offline Datto networking devices with a current `lastSeen`.

Offline reporting covers infrastructure only. Workstations and laptops never appear in any
offline count, ranking or outage test. **Offline devices are never listed by name** — every
site is one line, *X of Y*, where Y is infrastructure at that site.

### Offline tiers

- **Site down** — every device at the site is offline, **at least one is infrastructure**,
  and the most recent `lastSeen` is within `dormant_after`. Top of the plan. A
  workstation-only site going dark is not an outage.
- **Site outage** — two or more infrastructure devices offline at a site, **at least one of
  them a new drop**. Ranked. Line reads *X of Y offline (N new)*, with the last-seen span of
  the new drops.
- **Isolated** — exactly one infrastructure device offline and it is a new drop. One line.
- **Long-term offline** — sites whose offline infrastructure contains no new drop. Listed as
  counts, one line per site, **never ranked, never in the plan.** This is where most offline
  gear on most accounts belongs.
- **Dormant sites** — fully offline longer than `dormant_after`, or fully offline with no
  infrastructure at all. One footnote line naming them.

### Monitoring gaps

An offline infrastructure device with **no open `online_offline_status_ctx` alert** is a
monitoring gap. It is always a data-quality flag. If it went offline within `dormant_after`
and has no ticket, it is also a tier 3 plan candidate — nobody has been told.

**Partial alert pulls.** When the account-wide open-alert pull stopped at its budget, a missing
offline alert proves nothing: never print an account-wide gap count. Instead check only infrastructure that went offline within
`dormant_after`: `list_alerts device_uid status open` for each (cap 20), and report "monitoring
gaps: n of m recent drops checked". Older offline gear is not checked for gaps at all.

### Alerts on dormant devices

An offline alert (`online_offline_status_ctx`) on a device whose `lastSeen` predates the
alert by more than `dormant_after` is a policy firing on dead gear, not an incident. Count
these under long-term offline; they never count toward the verdict.

### Reading `diagnostics`

When the text is missing or lacks what a rule needs, say "level not reported"; never guess.
It is absent on offline, disk, `perf_mon_ctx` and most component alerts.

- **Disk** (`perf_disk_usage_ctx`): the level comes only from `get_device_audit` →
  `logicalDisks` (`freespace` / `size`, bytes; fixed volumes are `Local Fixed Disk`). Read
  the audit for every online infrastructure device with a disk alert (cap 10).
- **Patch** (`patch_ctx`): look for an HRESULT (`0x` + 8 hex digits) and a patch name
  (`Installing patch '…'`, a KB number).
- **Event log** (`eventlog_ctx`): look for the source (`Ntfs`, `EventLog`, `Kernel-Power`)
  and the event ID.
- **Component** (`comp_script_ctx`): when the text is absent, report the alert by type only.

### Tier 2 — alert-type rules

Tier 2 is driven by **alert type on an online infrastructure device**, never by `priority`.
Evaluate open alerts and resolved alerts inside the overnight window together.

| Signal | Match | Why it is tier 2 |
|---|---|---|
| **Disk nearly full** | `perf_disk_usage_ctx` with free under 5% in the audit, or under 10% with disk alerts on 3 or more different days; or `patch_ctx` whose `diagnostics` contain `0x80070070` | Services stop and backups fail when the disk fills. A patch failing with 0x80070070 is a disk-full report. |
| **Backup not running** | `backup_management_ctx`; or `comp_script_ctx` whose `diagnostics` mention backup failed, paused, not registered or not detected | Every other failure is recoverable only if backups work. |
| **File system corruption** | `eventlog_ctx` whose `diagnostics` name source `Ntfs` and event `55` | Corruption spreads, and in servicing or WinSxS it breaks the next patch cycle. |
| **AD replication failing** | `comp_script_ctx` whose `diagnostics` report replication critical or failed, on a domain controller | Authentication degrades silently across the whole customer. |

A disk alert with **no level reported** and no audit confirmation is tier 3, labelled
"disk alert, level unknown". A `comp_script_ctx` alert on a server with no `diagnostics`
cannot be matched to backup or AD replication; list it under "Also worth knowing" as
"component alert, output not exposed by the connector".

Everything else that is not an offline alert — service stopped, unexpected shutdown, patch
failures on other codes, CPU, bandwidth — is tier 3 at most, and only when repeated on a
server. Single occurrences go to "Also worth knowing" as counts.

### Other tier 3 sources

- **Pending reboot on a server behind on patching** — online server, `patch.status` not
  `FullyPatched`, and `rebootRequired: true` or `patch.status: RebootRequired`. Quick item:
  schedule the reboot. Say "no reboot in 30+ days" when the device is in the
  `Reboot > 30 days` set (v0.4.0 has no `lastReboot`).
- **Repeated overnight failure on a server** — the same patch or job failing on two or more
  nights, from repeat counts.
- **Monitoring gap** on a recent drop, as above.
- **Alert delivery failing** — resolved alerts carry an `actions` list. When a delivery
  failure code (any code containing `ERROR` or `FAIL`, e.g. `TICKET_CREATION_ERROR`) appears
  on alerts from more than one device in the window, the notification path is broken. One
  quick item, account-wide: name the codes and when they started, and say alerts may not
  have reached anyone.

Servers behind on patching without a pending reboot are a count in "Also worth knowing".

### Cross-site correlation

When infrastructure at **different sites** has new-drop times within five minutes of each
other, flag a possible shared dependency (typically a hypervisor at one site hosting VMs
registered to another). Do not merge the sites; say what dropped together.

### The plan

Rank:

1. **Customer is not working** — site down, or every infrastructure device at a site
   offline with at least one new drop.
2. **Customer is about to stop working** — tier 2 alert-type rules on online servers.
3. **Customer is degraded** — site outages, isolated new drops, other tier 3 sources.

Within **tier 2**, rank by the number of distinct tier 2 signals matched on the device (disk,
backup, file system, AD replication), then by the most recent of those signals. A server that
is out of disk *and* not backing up outranks one with a single problem, and this morning's
signal outranks last month's. Never rank tier 2 oldest-first.

Within tiers 1 and 3: unowned-flagged first, then proportion affected, then most recent.

A muted critical alert jumps the queue as a quick item.

Attach to each item: site, the specific thing to look at, why it ranks there, ticket number
or "no ticket", and an effort band — **quick** (30 min), **session** (2 hours), **needs
scoping** (1 hour).

**Filling capacity.** Walk the ranked list and take each item that fits the capacity still
remaining (`hours × technicians` minus what is already taken). When an item does not fit,
skip it and keep going — a quick item further down should use an hour that would otherwise
sit idle. Keep the plan in rank order; never reorder to pack tighter. Items skipped for
capacity go to "Also worth knowing" with their rank, so the reader sees what was passed over
and why.

If nothing qualifies, **the plan is empty and the briefing says so in one line.** Do not
promote long-term offline gear to fill it.

### Also worth knowing (what is left out of the plan)

Candidates for that section, one line each, with the owning skill (pick at most 5):

- Long-term offline infrastructure, as one account-wide count → `drmm-stale-and-ghost-devices`
- Servers behind on patching without a pending reboot → `drmm-patch-posture`
- High-severity and other alerts not matched by a plan rule, as counts →
  `drmm-alert-noise-review`
- Component alerts whose output the connector does not expose
- Items dropped for capacity

---

## Output

The start-up note is already written; write the report below it. The reader is a
technician deciding what to do next: lead with the answer, keep lines short, and put
how the data was read at the end.

```markdown
# Morning Pulse: [account or sites]
**[date time tz]** · [n] sites · [n] devices · [n] online ([n] online infrastructure)

## [🔴|🟠|🟢] Verdict: [RED|AMBER|GREEN]
[What drove it, in one or two sentences.]

---

## The first [n] hours
*Capacity: [n] h · [n] technician(s) · [n] h planned*

| # | Effort | Task | Why |
|---|---|---|---|
| 1 | [Quick, 30 min · Session, 2 h · Needs scoping, 1 h] | **[Verb] [what] on [device]** ([site]) | [evidence] [ticket or "No ticket."] |

**Where to start on item 1:** [the concrete first check].

---

## What else happened
**Outages** — only when something new dropped
| Site | Infrastructure offline | New drops | Last seen |
|---|---|---|---|

**[Overnight jobs · Offline devices · a device that needs attention]**
- [one fact per bullet]

---

## Not in today's plan
- **[item]** [one line] → [skill]

---

## Data you shouldn't trust
- **[lead]** [one line]

---

## Coverage
| Area | Status |
|---|---|
| Sites · Devices · Open alerts · Resolved alerts (oldest seen) · Activity log | [complete, or partial and how far it reached] |

Window: [start] to [end], [timezone] · [n] read-only calls · Morning Pulse v[version] (alpha)
```

**Format.** Markdown laid out like the template — not a code block, not plain text: a `#`
title, a bold date line, the verdict as a `##` heading with its colour dot, `---` between
sections, the action list as a table, and Coverage as an Area | Status table. Omit any
section that would be empty.

**Writing rules.**
- Lead with the answer: one or two sentences under the verdict, with the key device names
  and numbers in **bold**.
- Action rows start with a verb ("Free up disk on…", "Reboot…", "Deploy…"). The Why cell
  holds the evidence and the ticket number or "No ticket." in one or two short sentences.
- Under the action table, a **Where to start on item 1:** line names the concrete first
  check. Add one for item 2 only when it needs its own.
- Other sections use a bold lead line with short bullets under it, one fact per bullet.
- Raw field and monitor names (`perf_disk_usage_ctx`, `patch.status`) appear only in "Data
  you shouldn't trust" and Coverage. Elsewhere say "disk alerts", "reboot pending".
- Dates as "11 Sep"; times in the user's timezone.
- End Coverage with one line: window or scope, timezone and where it came from, `[n]
  read-only calls`, and the skill name and version. If a fuller run would close a gap,
  offer it in one closing sentence after Coverage — never more than one.

**Verdict rules.** RED if any site is down or any tier 2 match. AMBER if any site outage,
isolated new drop, or tier 3 item. GREEN otherwise. Long-term offline gear and alerts on
dormant devices **never** affect the verdict — otherwise most accounts are red every morning
forever.

**HTML.** With `html` on, build the page from `assets/report-template.html` as
`references/html-report.md` describes, instead of the Markdown report.

See `references/example-output.md` for a worked example from a live run. Read it before
the first run of a session and match its shape.

---

## Handoffs

| Finding | Hand off to |
|---|---|
| A specific device needs investigation | `drmm-device-quick-look` |
| What ran on a device before it broke | `drmm-device-timeline` |
| Long-term offline gear, or names behind a count | `drmm-stale-and-ghost-devices` |
| Patch state of specific devices or sites | `drmm-patch-posture` |
| Recurring alert that may be noise | `drmm-alert-noise-review` |
| Tier 2 match or monitoring gap with no ticket | `alert-to-ticket-pipeline` |
| Who on the team takes which item | `morning-standup` |

---

## Quit conditions

- The first `list_sites` call fails twice.
- Projected device pages exceed `page_budget` and the user has not answered.
- A required field is missing and cannot be substituted.
- Every collection comes back empty — say the account appears empty; never report green.

---

## Known gaps

What this skill cannot do yet, and how to tell that it worked, is in
`references/known-gaps.md`. Read it in readme mode, or when the user asks about limits.
