# Software Finder — connector notes

Reference for the drmm v0.4.0 Datto RMM connector, measured live on 30 Sep 2026.
Read when a field you need is missing, a value looks wrong, or a page fails.

## Page sizes

A tool result larger than about 50 KB fails in Claude Desktop, so never request more than
these per call (sizes measured live on 30 Sep 2026):

| Call | Max per page | Size at that max |
|---|---|---|
| `list_devices` | 100 | ~45 KB |
| `list_alerts` open | 100 | ~45 KB |
| `list_alerts` resolved | 50 | ~35 KB |
| `list_sites` | 100 | ~35 KB (150 measured ~50 KB — too close to the limit) |
| `list_device_software` | 250 | ~25 KB on Windows; macOS lists run past 250 rows of system components |
| `list_patches` | 100 | small |
| `list_components` | 50 | ~23 KB |

If the same page fails twice with HTTP 500, one record in that range is unreadable (seen live:
sites 2,550–2,599 failed at every page size). Retry the range in smaller pages — half, then a
tenth — to recover the rest, and report the range that could not be read.

## Fields by tool

From a live drmm v0.4.0 connector: `list_device_software` returns `{name, version}` per
row; the name often already contains the version. On some devices `version` arrives as a
JSON string — `{"version":"78.0.3904.108","idNumber":"…"}` (seen live on one server). Parse
it and use the inner `version`; never print the raw string, and name the device in coverage. Device rows carry `hostname`,
`device_uid`, `siteUid`, `device_type`, `operatingSystem`, `online`, `lastSeen` (epoch
ms). Site names come from `_enhanced.siteNames`.

`device_type` is the **hardware chassis type** (`Desktop`, `Portable`, `Notebook`,
`MacBook`, `Main System Chassis` for a Windows Server, `ESXi Host`, `Network Device`), not
the RMM category. A device is a **server** when `operatingSystem` contains `Server` (or it
came from the `All Server O/S` filter); skip rows whose `operatingSystem` is null —
network devices and ESXi hosts carry no software list.
