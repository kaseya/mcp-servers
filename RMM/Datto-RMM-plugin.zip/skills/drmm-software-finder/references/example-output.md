# Example output — Software Finder

From a live run against a Datto RMM sandbox account on 30 Sep 2026. Device, site and user
names are replaced; the numbers are real. Long lists are shortened. The fences only mark the
example — the real report is rendered Markdown, not a code block.
Prompt: *"Who has Google Chrome, and which versions?"*

**Start-up note** — its own chat message, before the first Datto RMM call:

```
Software Finder v0.1.17 · last updated 5 Oct 2026 · read-only · Datto RMM
Developer note: alpha release by the Kaseya Automation Content Team. Check results before acting on them, and report anything odd.
Starting: reading device filters and software lists. This can take a few minutes on a large account; any permission prompts are for read-only Datto RMM tools.
Tip: say "drmm-software-finder readme" for the full guide and all parameters.
```

**Report:**

````markdown
# Software Finder: "Google Chrome" · account
**30 Sep 2026, 14:26 CEST** · path A, filter "Google Chrome" · read 40 of 156 devices

## 🟠 Verdict: REVIEW
**156 devices have Chrome.** The 40 read carry **28 different major versions**, from 154 down to 28. Both current Windows devices are on the newest version.

---

## What to do

| # | Devices | Task | Why |
|---|---|---|---|
| 1 | 2 | **Update Chrome on the two Macs** (PCC-MAC02, BSM-MAC01) | Versions 105–106; they report online but were last seen April 2024. |
| 2 | 26 | **Decide whether servers should carry a browser** | All 26 servers in the filter have Chrome, including NWL-APP01. |

---

## Found
- **Google Chrome** on 156 devices (4 online, 152 offline, last known) at 80 sites: 81 workstations · 49 laptops · 26 servers

## Versions
*From 40 of 156 devices (all 26 servers, all 4 online, 10 across sites) — a sample, not the account*

| Version | Devices | Note |
|---|---|---|
| 154.0.8037.58 | 2 | Newest seen — both online Windows devices |
| 153 – 146 | 6 | One device each |
| 123 – 78 | 26 | |
| 41.0.2272.118 | 1 | |
| 28.0.1500.71 | 5 | Oldest — all at Legacy Lab, offline since 2013 |

## Devices that matter

| Device | Type | Site | Version | Why listed |
|---|---|---|---|---|
| NWL-APP01 | Server | Northwind Legal | 154.0.8037.58 | Server with a browser, online |
| ACC-SRV02 | Server | Accura Tax | 153.0.8010.50 | Server with a browser, offline since 21 Sep |
| PCC-MAC02 | MacBook Pro | Pinecrest Clinic | 106.0.5249.119 | Online but far behind |
| BSM-MAC01 | MacBook Pro | Brightside Media | 105.0.5195.125 | Online but far behind |
| WIN-2003R2-64 and 4 more | Servers | Legacy Lab | 28.0.1500.71 | Oldest version, offline since 2013 |

## Names matched
- "Google Chrome" — the only name counted.
- Seen and not counted: "Walkme-Installer-Chrome-Firefox-Edge-Chromium (x64)" on ACC-LT014.

---

## Coverage

| Area | Status |
|---|---|
| Filter | Google Chrome (678, default) — 156 members, 1 page |
| Software lists | 40 of 156 read, none failed; all 40 contained Chrome |
| Odd data | LAB-SRV01 returns versions as JSON strings; the inner version was used |

Account, Europe/Stockholm (from the user) · read-only · Software Finder v0.1.17 (alpha) · non-default: device_budget 40
Full device list available — ask for it as a CSV.
````

---

## Currency mode example

From a live run on 3 Oct 2026 (names replaced). Prompt: *"Are the apps on our current machines up to date?"*
The start-up note is the same as above.

# Software Finder: app currency · account (sample)
**3 Oct 2026, 11:40 CEST** · path C, sample · read 5 of 12 current devices

## 🔴 Verdict: ACTION
**ACC-LT014 runs five out-of-support runtimes** — Java 7 Update 80, .NET 6, Node.js 18, Oracle JDK 11 and 17 — plus a Firefox (143) that no longer gets fixes. Microsoft 365 Apps on two devices is on version **2608**, supported until 8 Dec 2026.

---

## What to do
| # | Devices | Task | Why |
|---|---|---|---|
| 1 | 1 | **Remove or replace Java 7, .NET 6 and Node.js 18 on ACC-LT014** (Accura Tax) | All three out of support (Java 7 since 2022, .NET 6 since Nov 2024, Node.js 18 since Apr 2025) |
| 2 | 1 | **Update Firefox on ACC-LT014** | 143.0.4 against 157 — not an ESR line, so no fixes. Firefox is in Software Management |
| 3 | 3 | **Update 7-Zip on NWL-APP01, ACC-LT014 and PCC-WS01** | 24.08 against 26.03; ACC-LT014 also keeps 7-Zip 9.20 from 2010. 7-Zip is in Software Management |

**Where to start on item 1:** ask the device owner whether the Java 7 and JDK 11/17 installs are still used — the Temurin 21 and 25 JDKs on the same machine are current and may replace them.

---

## Currency
*Current releases looked up live on the vendors' sites, 3 Oct 2026 11:38 · system-wide installs only*

| Product | Current release (looked up) | Current | Behind | Out of support | Oldest seen |
|---|---|---|---|---|---|
| Google Chrome | 155.0.8059.26 | 2 | — | — | 154.0.8037.93 |
| Microsoft Edge | 154.0.4258.53 | 3 | 1 | — | 153.0.4234.48 (PCC-WS01) |
| Microsoft 365 Apps | 2609 (build 20430) | — | 2 | — | 2608 (build 20326), end of service 8 Dec 2026 |
| Mozilla Firefox | 157.0 | — | — | 1 | 143.0.4 |
| 7-Zip | 26.03 | — | 3 | — | 9.20 |
| Zoom Workplace | 6.6.11 | — | 1 | — | 6.0.38135 |
| Adobe Acrobat | 26.002.21931 | — | 1 | — | 26.001.21662 |
| .NET runtime | 10.0.12 · 9.0.20 · 8.0.31 | 3 | — | 1 | 6.0.36 |
| Java / JDK | 8 Update 503 · Temurin 21.0.12 · 25.0.4 | 2 | — | 3 | Java 7 Update 80 |
| Node.js | 26 current · 24 and 22 LTS (endoflife.date) | — | — | 1 | 18.16.0 |

**Not compared** (no version found on the vendor's site — fleet only)
- Visual C++ v14 Redistributable: newest in the fleet 14.50.35719; 14.44 on NWL-APP01, 14.42 (Arm64) on PCC-WS01
- VMware Tools 12.5.3, Datto File Protection Server 8.50.13 — one copy each

## Devices that matter
| Device | Type | Site | Why listed |
|---|---|---|---|
| ACC-LT014 | Desktop | Accura Tax | 6 out-of-support items; 82 applications |
| NWL-APP01 | Server | Northwind Legal | Server, online: 7-Zip and Visual C++ behind |
| PCC-WS01 | Desktop | Pinecrest Clinic | Edge one major behind (153) |
| WGR-WS07 | Desktop | Westgate Retail | Only OneDrive and an old agent build ("CentraStage" 4.4.10128) — nothing else installed system-wide |

---

## Coverage
| Area | Status |
|---|---|
| Path | C — no account-wide software search; sample of current Windows devices |
| Software lists | 5 read (2 online, 3 offline under 30 days), none failed; the 2 online Macs not read |
| Lookups (3 Oct 2026 11:38) | Chrome 155.0.8059.26 (Google version history) · Edge 154.0.4258.53 (Microsoft Learn) · Firefox 157.0 (Mozilla product details) · Microsoft 365 Apps 2609 (Microsoft update history) · 7-Zip 26.03 (7-zip.org) · Zoom 6.6.11 (zoom.us) · Acrobat 26.002.21931 (adobe.com) · .NET, Java, Node.js (endoflife.date) |
| Per-user installs | Not in the software audit — Zoom, Teams or browsers installed for one user are not counted |

Sample of 5 devices, Europe/Stockholm (from your location) · 6 read-only calls · Software Finder v0.1.17 (alpha)
Name sites, or create a device filter, to run it across the whole account.
