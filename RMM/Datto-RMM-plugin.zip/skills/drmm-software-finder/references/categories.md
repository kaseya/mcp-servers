# Software Finder — category lists

**List date: 2 Oct 2026.** Show this date in Coverage ("Category list: browsers, 2 Oct
2026"). Only entries in this file are counted. Names the agent recognises as belonging to a
category but not listed here go to "Possibly also … — not counted"; never into the totals.

How to read the tables:
- **Match** — case-insensitive phrase match on the software name (Matching rules in
  `SKILL.md`). `=Name` means the whole software name must equal it (for short or common
  words such as "Arc", "Jan", "Cursor", "Claude").
- **Exclude** — names that contain the match but are not the product. Exclusions win.
- **Note** — `built in` = present on most devices by default: report one count line, never
  in Devices that matter. `EOL` = end of life: a hit on a current device is an ACTION.
  `server` = flag every hit on a server.

Never count Datto RMM's own components in any category: Datto RMM, CentraStage, CAG,
AEM Agent, Splashtop Streamer.

## browsers

| Product | Match | Exclude | Note |
|---|---|---|---|
| Google Chrome | Google Chrome | Google Chrome Frame; installers and plugins naming several browsers (e.g. "Walkme-Installer-Chrome-Firefox-Edge-Chromium") | server |
| Mozilla Firefox | Firefox | Mozilla Maintenance Service | server |
| Microsoft Edge | Microsoft Edge | Edge WebView2; Edge Update | built in on Windows |
| Safari | =Safari | Safari Technology Preview is counted separately | built in on macOS |
| Brave | Brave Browser; =Brave | | server |
| Opera | =Opera; Opera Stable; Opera GX | | server |
| Vivaldi | Vivaldi | | server |
| Arc | =Arc | | server |
| Tor Browser | Tor Browser | | server; confirm it is sanctioned |
| Chromium | =Chromium | Chromium Embedded Framework; names with "Edge-Chromium" | server |
| Waterfox | Waterfox | | server |
| DuckDuckGo | =DuckDuckGo | | server |
| Internet Explorer | Internet Explorer | | EOL |

## ai-tools

Installed apps only. AI used in a browser, through browser extensions or inside other
products (for example Copilot in Microsoft 365 apps) is not visible to a software
inventory. Coverage must always say so for this category.

| Product | Match | Exclude | Note |
|---|---|---|---|
| ChatGPT desktop | ChatGPT | | server |
| Claude desktop | =Claude | | server |
| Microsoft Copilot app | =Copilot; =Microsoft Copilot | Microsoft 365 Copilot; GitHub Copilot | built in on recent Windows |
| Perplexity | Perplexity | | server |
| Ollama | Ollama | | server — local AI models |
| LM Studio | LM Studio | | server — local AI models |
| GPT4All | GPT4All | | server — local AI models |
| Jan | =Jan | | server — local AI models |
| AnythingLLM | AnythingLLM | | server |
| Msty | =Msty | | server |
| Cursor | =Cursor | | AI code editor |
| Windsurf | Windsurf | | AI code editor |
| Grammarly | Grammarly | | AI writing assistant |

## remote-access

| Product | Match | Exclude | Note |
|---|---|---|---|
| TeamViewer | TeamViewer | | server |
| AnyDesk | AnyDesk | | server |
| RustDesk | RustDesk | | server |
| LogMeIn | LogMeIn | | server |
| GoTo Resolve | GoTo Resolve | | server |
| Microsoft Remote Help | =Remote Help | | server |
| Quick Assist | Quick Assist | | built in on Windows |
| Chrome Remote Desktop | Chrome Remote Desktop | | server |
| VNC | RealVNC; TightVNC; UltraVNC | | server |
| Splashtop Business | Splashtop Business | Splashtop Streamer (Datto RMM's own) | server |

## other-rmm

| Product | Match | Exclude | Note |
|---|---|---|---|
| Kaseya VSA | Kaseya Agent; VSA X | | server |
| ConnectWise | ConnectWise Automate; ScreenConnect; ConnectWise Control | | server |
| N-able | N-central; N-sight; Take Control | | server |
| NinjaOne | NinjaOne; NinjaRMM | | server |
| Atera | Atera | | server |
| Syncro | Syncro | | server |
| Level | =Level | | server |

## personal-vpn

| Product | Match | Exclude | Note |
|---|---|---|---|
| NordVPN | NordVPN | | |
| ExpressVPN | ExpressVPN | | |
| ProtonVPN | ProtonVPN; Proton VPN | | |
| Surfshark | Surfshark | | |
| Private Internet Access | Private Internet Access | | |
| Windscribe | Windscribe | | |
| Hotspot Shield | Hotspot Shield | | |

## p2p-sync

| Product | Match | Exclude | Note |
|---|---|---|---|
| BitTorrent | BitTorrent; uTorrent; qBittorrent; Transmission | | server |
| Syncthing | Syncthing | | server |
| Resilio | Resilio | | server |

## tunnels-admin

| Product | Match | Exclude | Note |
|---|---|---|---|
| ngrok | ngrok | | always ACTION |
| Cloudflared | Cloudflared | | ACTION on workstations |
| PuTTY | PuTTY | | |
| WinSCP | WinSCP | | |
| MobaXterm | MobaXterm | | |

## crypto

| Product | Match | Exclude | Note |
|---|---|---|---|
| Wallets | Electrum; Exodus; Bitcoin Core | | always ACTION |
| Miners | miner | names where "miner" is part of another word (e.g. "Determiner") | always ACTION |

## Groups

- `shadow-it` = remote-access, other-rmm, personal-vpn, p2p-sync, tunnels-admin, crypto.
- Names in `extra_watch_list` are counted under "Customer list" in whichever category was
  asked for.
