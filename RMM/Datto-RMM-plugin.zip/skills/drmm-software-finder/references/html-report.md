# Software Finder — HTML report

Read this only when `html` is set. The data, rules and ranking are exactly those of the
normal run; only the presentation changes. Every number comes from the run — never invent
a value to fill a slot. Leave a section out rather than fill it.

## Build

1. Read `assets/report-template.html`. Copy its `<head>`, including the whole `<style>`
   block, **unchanged**. Add no CSS, scripts or other external resources; the page must read
   correctly without the Google Fonts link.
2. Rebuild `<body>` with the template's elements and class names, section by section, from
   this run's data (mapping below). Escape `&`, `<` and `>` in names.
3. Set `<title>` to `Software Finder: [scope], [weekday date]` and end with
   `<footer>Software Finder v[version] (alpha) · [scope] · times in [timezone] · [n] read-only calls</footer>`.
4. **Check before delivering.** The page starts with exactly `<!DOCTYPE html>`,
   `<html lang="en">`, `<head>`, `<meta charset="utf-8">`, nothing between them; it has one
   `<html>`, one `<head>`, one `<style>`, one `<body>`, and no `<script>`. If anything is out
   of place, rebuild from the template. With code execution, check with a short script.
5. Deliver it as an **HTML artifact** with the same title; where artifacts are not
   available, save `software-finder-[scope]-[yyyy-mm-dd].html` and give the user the file.
6. In the chat, write at most three lines: the verdict sentence, action 1, and the version
   line. Do not repeat the Markdown report.

## Mapping

| Template element | Fill with |
|---|---|
| `header.verdict` | Colour: red ACTION, amber REVIEW, blue INFO. Stats: devices, online, servers, lists read, versions seen. |
| Versions | Table: version, devices, note; `.sig disk` chip on the oldest or end-of-life row. |
| Devices that matter | Table: device, type, site, version, why listed. |
| Where it is | Two panels of `.offrow` bars: by class (class `all` on servers) and top sites; names matched in a note. |
| By product | In category and shadow-IT mode, a table: group, product, devices, online, servers, versions, note; `.sig disk` chip on EOL or ACTION entries. |
| Currency | In currency mode, a table: product, current release (looked up), current, behind, out of support, oldest seen; `.sig disk` chip on out-of-support counts, `.sig bak` on behind. |
| Possibly also | A panel with a `.defer` list of names not counted, each with "confirm with extra_watch_list". |
| Data quality and coverage | `details` "Data-quality flags ([n])" with `.dq` items; `details` "Coverage ([n] API calls)" with four `.cov` boxes (class `partial` when partial) and a note. |
