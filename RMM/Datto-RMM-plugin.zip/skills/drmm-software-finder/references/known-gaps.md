# Software Finder — known gaps and success measures

## Known gaps

- **No account-wide software search** in the public API/connector. Server-team ask: a
  software query across devices (name, version), as the portal's software audit offers.
- No install date or publisher on software rows.
- The connector cannot create device filters; the user has to create one in the portal.
- No CVE lookup. End-of-life marking is looked up live on endoflife.date; `references/software-lifecycle.md` is the offline fallback — refresh it with each release.
- macOS and Linux software lists depend on what the agent audits.
- **Per-user installs are not in the software audit** (confirmed by the Datto RMM team, 3 Oct
  2026): apps installed for one user — often Zoom, Teams, browsers, remote-access and AI tools —
  are invisible to every mode, including shadow IT.
- Currency mode looks current versions up live on the vendors' sites, so it needs a web search or
  fetch tool. Without one — or when a vendor blocks automated requests — it compares with the
  fleet's newest version only. The Microsoft 365 Apps channel is inferred from the build — the
  configured channel and update policy are not visible.
- Several Software Management products (FileZilla, Citrix Workspace, Visual C++, VMware Tools,
  Datto agents) have no public version feed; currency mode compares them with the fleet only.
- Category lists are fixed per release (dated in `references/categories.md`); new products show under "Possibly also … — not counted" until they are added. AI used in a browser or through extensions is never visible.

## Measuring whether this worked

- "Who has X?" answered with a true total in a few calls when a filter exists.
- A sampled answer is always labelled as a sample.
- "Not found" is only said after the scope was read completely.
- Splashtop Streamer and Datto's own agent are never flagged as shadow IT.
