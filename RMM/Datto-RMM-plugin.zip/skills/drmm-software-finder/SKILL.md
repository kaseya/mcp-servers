---
name: "drmm-software-finder"
description: Read-only software search across a Datto RMM account or chosen sites. Opens with a start-up note (version, expected wait). Answers "who has X installed, and which version?" — finds every managed device carrying an application, groups them by version and site, rates versions current, behind or end of life against the vendors' releases, looked up live, and flags tools that often signal shadow IT (personal VPNs, remote-control tools, P2P, other RMMs). Uses matching device filters, otherwise reads device software lists within a budget, asking for sites before reading thousands of devices. Use this whenever the user asks who or which devices have some software, where an app is installed, how many copies or versions exist, which machines run an old or outdated version, whether apps are up to date, whether anyone has TeamViewer, AnyDesk or a VPN, or for software inventory, licence counts, shadow-IT checks or a category such as browsers or AI tools. For one device's full list, use drmm-device-quick-look.
metadata:
  version: "0.1.17"
  last_updated: "2026-10-05"
  type: "Datto RMM Skill"
  stage: "alpha"
  execution: "read-only"
  author: "Kaseya Automation Content Team"
compatibility: Requires the Datto RMM connector (drmm v0.4.0 tool set — the "Datto RMM" desktop extension or the datto-mcp remote server). See "Tools" below.
---

# Software Finder

## Run banner and readme

A full run takes several minutes, and in Claude Desktop the user sees only a collapsed
progress box while tools run. So the skill's output has two parts: a short start-up note,
written as a chat message once you have read this file and before the first Datto RMM
call (step 0 below), and then the report. The start-up note is these four lines:

```
Software Finder v0.1.17 · last updated 5 Oct 2026 · read-only · Datto RMM
Developer note: alpha release by the Kaseya Automation Content Team. Check results before acting on them, and report anything odd.
Starting: reading device filters and software lists. This can take a few minutes on a large account; any permission prompts are for read-only Datto RMM tools.
Tip: say "drmm-software-finder readme" for the full guide and all parameters.
```

Then gather the data and write the report. Its Coverage line carries the version and the
alpha mark too, so the reader still sees them if the note scrolls away.

**Readme mode.** When the message contains the word `readme` (with or without a slash) or
asks you to explain this skill: `readme` is a mode word, not a file — do not search for a
README file. Open `references/readme-guide.md` in this skill's folder and follow it.
Gather no data and call no Datto RMM tools.

---

## Goal

Answer one question:

> **Who has this software installed, which versions, and is any of it a problem?**

The answer leads with the count and the version spread, then names the devices that
matter — oldest versions, servers, anything unexpected. A full device dump is available on
request, never the default.

The connector has **no account-wide software search.** Every answer is built either from
a device filter the account already has, or from per-device software lists. The skill is
honest about which it used and how much of the estate it actually read. An answer from 3 of
40 sites is labelled as such; it is never scaled up into a guess for the whole account.

Software Finder is diagnostic only. It never uninstalls, updates or blocks software.

---

## Tools

All Datto RMM calls go through the **Datto RMM connector** (drmm v0.4.0). Use these and
nothing else — with one exception: **web search or web fetch, read-only, for version and
end-of-life lookups** on the vendor sites and endoflife.date named in
`references/app-version-sources.md`. Never send device, site or customer data in a web request.

| Purpose | Tool | Notes |
|---|---|---|
| Software-based filters | `list_device_filters` | `filter_type: "default"` then `"custom"`. |
| Devices in a filter | `list_devices` with `filter_id` | `count` is the true total. Max 100 per page. |
| Devices in a site | `list_devices` with `site_uid` | Exactly one selector per call. |
| Sites | `list_sites` | `devices.total` per site drives the budget. |
| Current version and end of life | web fetch / web search | Only in currency mode or for an end-of-life mark; sources and rules in `references/app-version-sources.md` and `references/software-lifecycle.md`. Without a web tool, compare with the fleet only. |
| Software on a device | `list_device_software` | `name`, `version` only — **no install date, no publisher**. Max 250 per page; Windows devices fit in one page (~20–60 rows); macOS lists run past 250 rows of system components, so a Mac costs 2+ pages. 400 on network-discovered devices — skip those. |

### Default filters that are software searches

Resolve by name at run time. Use one only when it plainly matches the requested product.

`Google Chrome`, `Mozilla Firefox`, `Java`, `Adobe Flash`, `Microsoft Office`,
`No MS Office`, `Dropbox`, `Box.net`, `Acronis TrueImage`, `Veeam `, `Backup Exec`,
`StorageCraft`, `Ahsay`, `Datto Endpoint Backup`, `Datto File Protection`, `Datto EDR`,
`RocketCyber`, `SQL Server`, `SQL Express`, `No Splashtop Streamer`, and the AV vendor
filters (`Sophos`, `ESET`, `Webroot`, `Trend Micro`, `Symantec`, `McAfee`, `Kaspersky`,
`Panda`, `AVG`, `Avira`).

Custom filters whose name contains the product name are candidates too — confirm with the
user if the match is loose ("Adobe" vs "Adobe Reader").

### Page sizes

Claude Desktop rejects a tool result over about 50 KB. Per call, never request more than:
devices 100, open alerts 100, resolved alerts 50, sites 100, device software 250 (a Mac
needs two or more pages), patches 100, components 50. If the same page fails twice with
HTTP 500, one record in that range is unreadable: retry the range in smaller pages to read
around it, and report the range. Measured sizes: `references/connector-notes.md`.

---

## Parameters

Apply the default when not given, and state any non-default value in the coverage
footer. Users set these in plain words ("only Northwind Legal", "look back 14 days").

| Parameter | Default | Effect |
|---|---|---|
| `software` | required in `find` mode | Product name or pattern. `*` allowed as a wildcard. In `currency` mode, limits the check to that product. |
| `version` | none | Exact, prefix (`8.`) or comparison (`< 122`). |
| `sites` | none | Restrict to named sites. |
| `include_offline` | true | Offline devices are included, labelled last-known. |
| `mode` | `find` | `find` (one product), `category` (a group of products, see Category mode), `shadow-it` (shortcut for the shadow-IT categories) or `currency` (are apps up to date, see Currency mode). Plain words map too: "up to date", "outdated apps", "behind on updates" → `currency`. |
| `category` | none | `browsers`, `ai-tools`, `remote-access`, `other-rmm`, `personal-vpn`, `p2p-sync`, `tunnels-admin`, `crypto`, or `shadow-it`. Plain words map to these ("web browsers" → `browsers`, "AI apps" → `ai-tools`). Setting it implies `mode category`. |
| `extra_watch_list` | none | Extra product names counted in category and shadow-IT mode, for example the customer's own banned tools or a browser not on the list. Reported as "Customer list". |
| `timezone` | the user's | The connector has no account timezone. UTC if unknown — say so. |
| `html` | off | On when the user's message contains the word `html` ("drmm-software-finder html", "as HTML"). Same run, delivered as a styled HTML page: read `references/html-report.md` before writing the report. |

**Reading parameters.** Text in quotes is one value, taken exactly (`"Google Chrome"`,
`sites "- Datto Devices"`). Without quotes, a value runs until the next parameter word
(`version`, `sites`, `days`, `html`, `readme` …, or "for"/"at" before a site). Multi-word
names match as a whole phrase, case-insensitively, never word by word. If a word could
belong to two values, ask once before reading data. Coverage echoes what was understood
(Searched for "Google Chrome" · sites: Northwind Legal).

**Advanced — budgets.** Change these only when a run stops early on a large account.

| Budget | Default | Effect |
|---|---|---|
| `device_budget` | 150 | Software-list **pages** read in one run (a Mac can take 2–3). |
| `lookup_budget` | 15 | Products looked up on the web in one run, most devices first. |

---

## Scope boundary

| In scope | Out of scope |
|---|---|
| Who has a product, which versions | Whether third-party apps are compliant with policy → `drmm-patch-posture` |
| Version spread, oldest versions | AV/EDR coverage → `drmm-security-coverage-gaps` |
| Unsanctioned tools (shadow-IT mode) | One device's full software list → `drmm-device-quick-look` |

---

## Search strategy

0. **Post the start-up note** from "Run banner and readme" as a chat message, before
   any Datto RMM call below. Then continue straight away; do not wait for a reply.
   Between steps, a one-line progress note is fine ("Devices read, reading alerts next").

Pick the cheapest path that answers the question. Say which path was used.

**Path A — filter answers "who".** A filter matches the product.
1. Page `list_devices filter_id` → the device set and its true total.
2. If the user asked only "who / how many", stop here: no versions needed.
3. For versions: read `list_device_software` for up to `device_budget` devices from the
   set — **servers first**, then a spread across sites (round-robin, not the first site
   only). If the set is larger than the budget, the version spread is a **sample** and is
   labelled "versions from n of N devices".
4. **A filter with zero members** is not evidence of absence — the filter may be misdefined
   (live check: a custom "AnyDesk" filter returned 0 devices). When a filter whose name
   matches returns 0, say so and fall back to Path B or C before answering "not found".
   Membership of a non-empty filter did match the software lists in the live check
   (`Google Chrome`: 156 devices, including the server that has Chrome and not the desktop
   that does not).

**Path B — no filter, sites named.**
1. `list_sites` → resolve names. Sum `devices.total`. Above `device_budget`, say how many
   devices it would take and ask whether to continue, or narrow further.
2. `list_devices site_uid` per site; skip network devices, printers and ESXi hosts.
3. `list_device_software` per device, following `next_page` until the list ends.

**Path C — no filter, no sites (whole account).** Do not start reading devices. Say that
the connector has no software search, report the account's device total from
`list_sites`, and offer: (a) name the sites to search, (b) create a custom device filter in
the Datto RMM portal for the product and rerun (then it becomes Path A and covers the whole
account in a few calls), or (c) search a sample of up to `device_budget` devices across
all sites, labelled as a sample.

Retry any failing call once; list devices whose software could not be read in coverage.

### Matching

- Case-insensitive substring on `name`. A wildcard pattern becomes a substring split on
  `*`, all parts in order.
- A multi-word product matches as the whole phrase. If it matches nothing, try once
  without the vendor word ("Chrome" for "Google Chrome") and say so in Coverage:
  'No match for "Google Chrome"; matched "Chrome" instead.'
- **Normalise names** before grouping: drop architecture and version suffixes —
  `(x64)`, `(64-bit)`, `x86`, trailing version numbers, `- 14.50.35719` — so "Microsoft
  Visual C++ v14 Redistributable (x64) - 14.50.35719" groups under "Microsoft Visual C++
  v14 Redistributable".
- Beware over-matching short names: "Zoom" also matches "Zoom Outlook Plugin"; "Java"
  matches "JavaFX" and macOS "Java Web Start". Report each distinct normalised name found
  and let the user drop any.
- **Queries under 5 characters** ("Zoom", "Java", "Match") match whole words only.
- **macOS noise:** macOS software lists include hundreds of system components ("Remove",
  "Match", "Proof", "Dock", "Mission Control") with empty or 1.x versions. On a Mac, ignore
  entries whose name is a single common word unless the user searched for exactly that
  name.
- The Datto RMM agent itself appears as `Datto RMM` (Windows) or `AEM Agent` (macOS), with
  different version lines (seen: 4.4.12127 and 15.2.0.12397). Never count it as a finding.
- Compare versions numerically, part by part (`10.0.2` < `10.0.10`); non-numeric parts
  compare as text.

### Gotchas

Confirmed against a live drmm v0.4.0 connector. The full field list for each tool is in
`references/connector-notes.md`; read it when a field you need is missing or a value looks wrong.

- `list_device_software` returns only `name` and `version`; the name often contains the
  version too. There is no install date or publisher.
- On some devices `version` arrives as a JSON string —
  `{"version":"78.0.3904.108","idNumber":"…"}`. Parse it and use the inner `version`;
  never print the raw string, and name the device in coverage.
- A device is a **server** when `operatingSystem` contains `Server`. `device_type` is the
  hardware chassis; never read the class from it.
- Rows with a null `operatingSystem` (network devices, ESXi) have no software list. Skip
  them.

---

## Computation

### Version spread

Per normalised product: versions → device count, newest first. The **newest version seen**
is the reference; everything else is "behind". Mark a version **end of life** only from
a live endoflife.date lookup as `references/software-lifecycle.md` describes (its tables are the
offline fallback), and name the source and date in Coverage. A product not in that file gets "no
lifecycle data"; never mark end of life from memory. Adobe Flash is end of life in every
version. When the product is in `references/app-version-sources.md` and a web tool is available, the
Note column also gives its state (Current, Behind, Out of support) against the vendor's current
release, looked up live.

### Devices that matter

List by name only:
- Devices on the **oldest** version bucket (max 15).
- **Servers** carrying the product when it is a client application (browser, VPN client,
  personal cloud sync, remote-access tool).
- Devices matching `version` when the user gave one.

### Category mode

Read `references/categories.md` before searching. **Only its entries are counted**, so the
same data always gives the same totals; the agent's own judgement only suggests.

1. **Resolve the category** from `category` or the wording. `shadow-it` means its six
   categories, reported as groups. Unknown category: list the available ones and ask.
2. **Path.** Products with a default filter (`Google Chrome`, `Mozilla Firefox`) use Path A
   for "who". Every other product needs per-device software lists, so the run follows the
   Path B and C rules: sites named, a labelled sample, or a custom filter first.
3. **Match** each entry's names with the Matching rules; exclusions win; `=Name` entries
   must equal the whole software name. Never count Datto RMM's own components.
4. **Built-in entries** (Edge, Safari, Quick Assist, the Copilot app) get one count line,
   never a place in Devices that matter.
5. **Possibly also … — not counted.** Names the agent recognises as belonging to the
   category but not in the list or its exclusions go to their own section: name, devices,
   and "confirm with `extra_watch_list`". They never enter totals or the verdict.
6. **Coverage** names the list and its date ("Category list: browsers, 2 Oct 2026"). For
   `ai-tools` it always adds: "Installed apps only — AI used in a browser, through
   extensions or inside other products is not visible."

None of the shadow-IT products is wrong by itself — MSPs use several — so the output asks
the technician to confirm each is sanctioned for that customer.

### Currency mode

Read `references/app-version-sources.md` before judging any version. It says **where** each
vendor publishes its current release; the version itself is **looked up live** on every run,
never taken from memory or from an earlier run.

1. **Scope and path.** With `software`, check that product (Path A when a filter matches).
   Without it, check every product in the sources file that the devices carry: one software
   list per device covers all of them, so follow the Path B and C rules (sites named, a
   labelled sample, or a filter).
2. **Look up** the current release of each product found, most devices first, within
   `lookup_budget`, from the sources in their order (vendor feed or release page, then a search
   on the vendor's domain). End-of-life lines come from a live endoflife.date lookup. Post one
   progress line first: "Looking up current versions on the vendors' sites (n products)".
3. **Rate** each installed copy: Current, Behind, Out of support or Not compared, by the
   product's rule. Microsoft 365 Apps: rate the build against the supported-versions table on
   Microsoft's update-history page; the channel is inferred, never read.
4. **No web tool, or a lookup fails:** compare with the newest version seen in the fleet and mark
   it "fleet only" — never fill the gap from memory. Say so in Coverage and how to turn web
   lookups on.
5. **Summarise per product:** current release (with its source), devices current / behind / out
   of support, oldest version seen. Products with no copies are left out.
6. **Actions** point at the fix: products in Datto RMM's Software Management can be updated there
   or with their ComStore component; name it, never run it.
7. **Coverage** lists each lookup (product, version found, source, time), says "system-wide
   installs only" — per-user copies are not in the software audit — and names any product left
   at "fleet only".

### Verdict

- **ACTION** — any end-of-life or out-of-support version (in currency mode: on a server,
  or on more than a tenth of the devices with that product), any end-of-life product (`EOL` in the category list), any
  remote-access or other-RMM hit on a server, or any entry marked "always ACTION".
- **REVIEW** — anything else from the shadow-IT categories, any AI tool on a server, more
  than three versions of one product, or (currency mode) any Behind or out-of-support copy
  not already ACTION.
- **INFO** — a plain inventory answer.

---

## Output

The start-up note is already written; write the report below it. The reader is a
technician deciding what to do next: lead with the answer, keep lines short, and put
how the data was read at the end.

```markdown
# Software Finder: "[software]" · [account | sites]
**[date time tz]** · path [A, filter "name" | B, sites | C, sample] · read [n] of [N] devices

## [🔴|🟠|🔵] Verdict: [ACTION|REVIEW|INFO]
[Count, version spread and worst finding, in one or two sentences.]

---

## What to do  ← only for ACTION or REVIEW
| # | Devices | Task | Why |
|---|---|---|---|
| 1 | [n] | **[Update / Remove / Confirm …] [what]** | [evidence] |

---

## Found
- **[product]** on [n] devices ([n] online, [n] offline, last known) at [n] sites

## Versions
| Version | Devices | Note |
|---|---|---|

## Devices that matter
| Device | Type | Site | Version | Why listed |
|---|---|---|---|---|

## By site
| Site | With it | Read |
|---|---|---|

## By product  ← category and shadow-IT mode
| Group | Product | Devices | Online | Servers | Versions | Note |
|---|---|---|---|---|---|---|

## Currency  ← currency mode
| Product | Current release (looked up) | Current | Behind | Out of support | Oldest seen |
|---|---|---|---|---|---|

## Possibly also [category] — not counted
- [software name] on [n] devices — confirm with `extra_watch_list`

## Names matched
- [every distinct normalised name that matched; names seen and not counted]

---

## Coverage
| Area | Status |
|---|---|
| Filter · Software lists · Failed devices | [complete, partial or sample] |

[Scope], [timezone] · [n] read-only calls · Software Finder v[version] (alpha)
```

**Format.** Markdown laid out like the template — not a code block, not plain text: a `#`
title, a bold date line, the verdict as a `##` heading with its colour dot, `---` between
sections, the action list as a table, and Coverage as an Area | Status table. Omit any
section that would be empty.

**Writing rules.**
- Lead with the answer: one or two sentences under the verdict, with the key device names
  and numbers in **bold**.
- Action rows start with a verb ("Free up disk on…", "Reboot…", "Deploy…"). The Why cell
  holds the evidence and the ticket number or "No ticket." in one or two short sentences.
- Under the action table, a **Where to start on item 1:** line names the concrete first
  check. Add one for item 2 only when it needs its own.
- Other sections use a bold lead line with short bullets under it, one fact per bullet.
- Raw field and monitor names (`perf_disk_usage_ctx`, `patch.status`) appear only in "Data
  you shouldn't trust" and Coverage. Elsewhere say "disk alerts", "reboot pending".
- Dates as "11 Sep"; times in the user's timezone.
- End Coverage with one line: window or scope, timezone and where it came from, `[n]
  read-only calls`, and the skill name and version. If a fuller run would close a gap,
  offer it in one closing sentence after Coverage — never more than one.

Offline devices are counted with "(last known)". End with one line when more rows exist:
"Full device list available — ask for it as a CSV."

**Coverage** — Area | Status rows and the closing line, covering: path, filter used (name and ID), devices read vs in scope, devices that
failed, sampling statement if any, timezone (user's, else UTC), non-default parameters.

**HTML.** With `html` on, build the page from `assets/report-template.html` as
`references/html-report.md` describes, instead of the Markdown report.

See `references/example-output.md` for the shape.

---

## Handoffs

| Finding | Hand off to |
|---|---|
| Old versions are a patching problem | `drmm-patch-posture` |
| Security product questions | `drmm-security-coverage-gaps` |
| An unexpected tool — when did it appear? | `drmm-device-timeline` |
| One device in detail | `drmm-device-quick-look` |

---

## Quit conditions

- `software` not given — ask for it.
- Path C and the user has not chosen an option.
- Every device read fails — report the failures; never report "not found".

---

## Known gaps

What this skill cannot do yet, and how to tell that it worked, is in
`references/known-gaps.md`. Read it in readme mode, or when the user asks about limits.
