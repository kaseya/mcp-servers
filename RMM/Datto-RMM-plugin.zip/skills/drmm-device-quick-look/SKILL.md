---
name: "drmm-device-quick-look"
description: Read-only triage of one Datto RMM server or workstation. Opens with a start-up note (version, expected wait). Finds the device from a hostname, partial name, site, UID, numeric ID or MAC address, then answers what is wrong with it right now and what the technician should look at first. Reads the device record, hardware audit, open alerts, seven days of resolved alerts, the device's activity-log entries, its patch list and installed software; trends disk free space across alerts and audit, groups duplicate and recurring alerts, and labels everything on an offline device as last-known. Use this whenever the user names one device and asks what is going on with it, why it alerted, whether it is healthy, what to check first, or for a quick look, deep dive, status or details on a single server, desktop or laptop (other device types get a limited view) — even if they only give part of the name or a MAC address. Prefer it over ad-hoc device lookups for one-machine questions.
metadata:
  version: "0.2.14"
  last_updated: "2026-10-05"
  type: "Datto RMM Skill"
  stage: "alpha"
  execution: "read-only"
  author: "Kaseya Automation Content Team"
compatibility: Requires the Datto RMM connector (drmm v0.4.0 tool set — the "Datto RMM" desktop extension or the datto-mcp remote server). See "Tools" below.
---

# Device Quick Look

## Run banner and readme

A full run takes several minutes, and in Claude Desktop the user sees only a collapsed
progress box while tools run. So the skill's output has two parts: a short start-up note,
written as a chat message once you have read this file and before the first Datto RMM
call (step 0 below), and then the report. The start-up note is these four lines:

```
Device Quick Look v0.2.14 · last updated 5 Oct 2026 · read-only · Datto RMM
Developer note: alpha release by the Kaseya Automation Content Team. Check results before acting on them, and report anything odd.
Starting: finding the device, then reading its record, hardware, alerts, patches and software. This can take a few minutes on a large account; any permission prompts are for read-only Datto RMM tools.
Tip: say "drmm-device-quick-look readme" for the full guide and all parameters.
```

Then gather the data and write the report. Its Coverage line carries the version and the
alpha mark too, so the reader still sees them if the note scrolls away.

**Readme mode.** When the message contains the word `readme` (with or without a slash) or
asks you to explain this skill: `readme` is a mode word, not a file — do not search for a
README file. Open `references/readme-guide.md` in this skill's folder and follow it.
Gather no data and call no Datto RMM tools.

---

## Goal

Answer one question for a technician, usually right after an alert fired:

> **What is wrong with this device right now, and what should I look at first?**

Everything below serves that question. The output leads with a single "look at first"
item backed by evidence, not with an inventory sheet. A device where nothing is wrong
gets a short answer saying so. Filling the page with specs to look thorough is the
failure this skill most needs to avoid.

Device Quick Look is diagnostic only. It never calls a write tool (`resolve_alert`,
`update_device_udfs`, `create_job`). What happens next is the technician's decision.

---

## Scope

**Full view:** servers and workstations running the Datto RMM agent — devices whose
`operatingSystem` is not null and whose class (below) is Server or Workstation.

**Limited view:** every other device — ESXi hosts, printers, network devices, Datto
networking and Datto Continuity appliances, which have little or no audit data here. Skip
the software call, try the audit once, and report identity, online state, alerts and
activity, with "No audit data for [type] through this connector" in Device health if the audit
fails. Findings rules still apply. Datto networking devices can report offline with a
current `lastSeen`: offline time unknown, flag it.

### Device class

`device_type` is the **hardware chassis type**, not the RMM category. Classify:

1. **Server** — `operatingSystem` contains `Server`. For a non-Windows OS that might be a
   server (Linux, FreeBSD), check the `All Server O/S` filter: resolve it with
   `list_device_filters default`, and if its `count` is 500 or less, page `list_devices
   filter_id` and look for the device's `device_uid`. Larger than that, label the class
   "unconfirmed" rather than spend the calls.
2. **ESXi host / Network / Printer / Datto** — by `device_type` (network: `Network Device`,
   `Router`, `Firewall`, `Switch`, `Network Appliance`, `UPS`, `SAN`, `NAS`).
3. **Workstation** — anything else with a non-null `operatingSystem`; laptop when
   `device_type` is `Portable`, `Notebook`, `Laptop`, `MacBook` or `Sub Notebook`.

Show the class, and the raw `device_type` in brackets when they differ.

One device per run. If the user names several, ask which to start with.

---

## Tools

All calls go through the **Datto RMM connector** (drmm v0.4.0). Use these and nothing else.

| Purpose | Tool | Notes |
|---|---|---|
| Resolve by UID | `get_device` `device_uid` | The first call doubles as the access check. |
| Resolve by numeric ID | `list_devices` `device_id` | The number in a portal URL (`/device/479352`). |
| Resolve by MAC | `list_devices` `mac_address` | 12 hex characters, **no separators**. May return more than one device. |
| Resolve by name | `list_devices` `hostname` | **Partial match, account-wide, one call.** `count` is the true total. |
| Resolve by site | `list_sites`, then `list_devices` `site_uid` | One selector per call — site and hostname cannot be combined. |
| Hardware | `get_device_audit` | Inventory snapshot: disks, NICs, CPU, RAM, BIOS, logged-in user. |
| Open alerts | `list_alerts` `device_uid`, `status: "open"` | Max 100. Can hold alerts months old. |
| History | `list_alerts` `device_uid`, `status: "resolved"` | Newest first, **no date filter**. |
| Patches | `list_patches` `device_uid` | Per-patch title, KB, `installStatus`. |
| Installed software | `list_device_software` `device_uid` | Name and version only. |
| Activity log | `list_activity_logs` `device_uid`, `time_from`, `time_to` | **Both times required.** Page with `search_after`. Never pass `filter_uid`. |

### Page sizes

Claude Desktop rejects a tool result over about 50 KB. Per call, never request more than:
devices 100, open alerts 100, resolved alerts 50, sites 100, device software 250 (a Mac
needs two or more pages), patches 100, components 50. If the same page fails twice with
HTTP 500, one record in that range is unreadable: retry the range in smaller pages to read
around it, and report the range. Measured sizes: `references/connector-notes.md`.

---

## Parameters

Apply the default when not given, and state any non-default value in the coverage
footer. Users set these in plain words ("only Northwind Legal", "look back 14 days").

| Parameter | Default | Effect |
|---|---|---|
| `device` | required | Hostname (full or partial, optionally with a site), UID, numeric device ID or MAC address. If missing, ask for it before calling any tool. |
| `history_days` | 7 | Window for resolved-alert history and the activity log. |
| `disk_warn` | 10% | Free space below this on a fixed volume is a finding. |
| `disk_critical` | 5% | Free space below this is the top finding on an online device. |
| `disk_full_days` | 14 | A falling volume projected full within this many days is top tier. |
| `stale_alert_days` | 30 | Open alerts older than this are reported as stale. |
| `timezone` | the user's | The connector has no account timezone. UTC if unknown — say so. |
| `html` | off | On when the user's message contains the word `html` ("drmm-device-quick-look html", "as HTML"). Same run, delivered as a styled HTML page: read `references/html-report.md` before writing the report. |

**Reading parameters.** Text in quotes is one value, taken exactly (`"Google Chrome"`,
`sites "- Datto Devices"`). Without quotes, a value runs until the next parameter word
(`version`, `sites`, `days`, `html`, `readme` …, or "for"/"at" before a site). Multi-word
names match as a whole phrase, case-insensitively, never word by word. If a word could
belong to two values, ask once before reading data. Coverage echoes what was understood
(Searched for "Google Chrome" · sites: Northwind Legal).

**Advanced — budgets.** Change these only when a run stops early on a large account.

| Budget | Default | Effect |
|---|---|---|
| `alert_page_budget` | 5 | Pages (at 100) of open alerts before marking them partial. |
| `history_page_budget` | 6 | Pages (at 50) of resolved alerts before marking history partial. |
| `activity_page_budget` | 3 | Activity-log pages. |

---

## Resolution — finding the device

0. **Post the start-up note** from "Run banner and readme" as a chat message, before
   any Datto RMM call below. Then continue straight away; do not wait for a reply.
   Between steps, a one-line progress note is fine ("Devices read, reading alerts next").

1. **UID** (a UUID, or `siteUid-MAC` for agentless devices) → `get_device`.
2. **Numeric ID or portal URL** → `list_devices device_id`.
3. **MAC** in any format (`00:50:56:8C:63:3E`, `00-50-56-…`, `0050568C633E`) → strip
   separators, uppercase, `list_devices mac_address`. One result: use it. Several: list them
   (hostname, site, class, online) and ask.
4. **Name** (± site) → `list_devices hostname: <text>`, paging if `count` > 100. If a site was
   given, match site names from `_enhanced.siteNames` case-insensitively as a substring and
   keep only those rows. A site that matches nothing: say so and ask.

**Matching** on `hostname`, case-insensitively (no match: suggest the MAC or the site):

- One exact match → use it.
- Exact matches at more than one site → list them and ask.
- No exact match, one partial match → use it and say "matched on partial name".
- 2–10 partial matches → list hostname, site, class, online state, and ask.
- More than 10 → ask the user to narrow it (add the site, or more of the name).

When listing candidates to choose from, do not pull audits or alerts for any of them.

---

## Data gathering

Once one device is resolved and in scope:

1. `get_device` for the current record.
2. `get_device_audit` (full view; one try on limited view).
3. `list_alerts device_uid status open`, paged to the end or `alert_page_budget`.
4. `list_alerts device_uid status resolved`, page 0, then further pages only while the
   oldest alert on the last page is still inside `history_days`, up to
   `history_page_budget`. On a noisy device this covers hours, not days: report the window
   actually covered; never scale it up.
5. `list_patches device_uid` (full view), paged to the end.
6. `list_device_software device_uid`, paged to the end (full view only).
7. `list_activity_logs device_uid, time_from = now − history_days, time_to = now`, paged
   with `search_after` to `activity_page_budget`.

Retry a failing call once. If the device record cannot be read, stop. If the audit, alerts, patches, software or activity log
fail, carry on without that section and say so in coverage. Never retry on `rate_limited`.

### Activity log

Entry fields: `category`, `action`, **`date` in epoch seconds** (not milliseconds), `actor`
and `summary` (cut at about 200 characters) — details in `references/connector-notes.md`.
Never repeat e-mail addresses or IPs from summaries.

List entries newest first: time, category/action, who, short detail. Cap at 15; count the
rest. An entry within 24 hours before the look-at-first evidence (a job,
patch action or configuration change just before a disk jump or shutdown) is attached to
that finding as possible context — stated as timing, never as cause. For a full timeline,
hand off to `drmm-device-timeline`.

**When it is empty.** Say "No activity-log entries for this device in the last
[history_days] days." **When it failed**, say so — never present a failed call as "no
activity".

### Secrets in text

Alert `diagnostics` and software names are free text; if any contains a product key (five groups of five
alphanumerics), a BitLocker recovery key (eight groups of six digits), or text following
`password`, `pwd`, `secret`, `token`, `apikey`, `key=`, replace it with
`[redacted: type]` before printing, and add a data-quality flag.

### Gotchas

Confirmed against a live drmm v0.4.0 connector. The full field list for each tool is in
`references/connector-notes.md`; read it when a field you need is missing or a value looks wrong.

- `online` is the only authority for current state. `lastSeen` is **not a heartbeat**; use
  it only on an offline device, as the approximate drop time.
- `antivirus: {}` means "no AV data reported", never "no antivirus". Take protection from
  the software list instead.
- `FullyPatched` means every **approved** patch is installed. `APPROVED_PENDING` in a patch
  list is approved and waiting, not failed.
- RAM is `systemInfo.totalPhysicalMemory` (bytes); `physicalMemory` pads out on a VM. Disk
  sizes are bytes; fixed volumes say `Local Fixed Disk`.
- Disk alerts carry **no** `diagnostics`; the level comes from the audit only. CPU alerts
  list processes in `diagnostics`, first process first.
- `priority` is the monitor's setting, not severity. Never rank on it.
- Not returned at all: last audit date, last reboot, third-party compliance, UDFs, domain,
  IP addresses from the device record, numeric ID, description. Never infer them.

---

## Computation

Read `references/security-and-backup-agents.md` before writing the security and backup
lines: it holds the product names, evidence order and wording rules.

### Freshness

- **Online device:** audit and patch data are as of the last audit, whose date v0.4.0 does
  **not** expose. Say once in the header: "audit date not exposed by the connector". Do not
  show `lastSeen`.
- **Offline device:** the verdict is `OFFLINE`. Show "offline since" from `lastSeen`, and
  mark every other section as last-known ("last reported", never current state).

### Disks

For each fixed volume: free % = `freespace / size`. Below `disk_critical` or `disk_warn`,
it is a finding.

**Trend.** Disk alerts carry no level, so the audit is normally the only data point: say
"one data point — trend not available through this connector". If alert `diagnostics` ever
carry levels, use them with the audit: with two points over 24 hours apart and free space
falling, give the daily rate and days until full as an estimate from the named points.

**Persistent disk alerts.** What the connector does give is *when* disk alerts fired. A
volume below `disk_warn` whose disk alerts fired on 3 or more different days, or stayed open
for more than 7 days, is a problem nobody has fixed — rank it top tier. A shrinking volume
outranks a static one at the same level.

### Grouping alerts

Raw alert rows are never listed. Group them first.

- **Signature** = `monitor_type` plus its key from `diagnostics`: disk name for disk
  alerts; event source + ID for event-log alerts; the HRESULT for patch alerts; the text
  with numbers removed for component monitors when present; the monitor type alone
  otherwise.
- **Duplicates:** alerts with the same signature raised within 60 seconds of each other are
  one event.
- **Recurring:** the same signature on two or more different days, open or resolved.
- Per group, report: event count, first and last time, how many are still open, ticket
  numbers (or "no ticket").
- **Noise:** a group of 10+ auto-resolved events with no tickets that matches no finding
  rule is reported as one line with its count and range.
- **Agent load:** when the first process in most CPU alert process lists is the Datto RMM
  agent (`AEMAgent.exe`, `CagService.exe`, `RMM.WebRemote.exe`), say so on the noise line —
  the monitor is mostly measuring the RMM agent itself. → `drmm-alert-noise-review`

### Findings

Evaluate every rule below, then rank. Each finding carries its evidence (values, times,
ticket numbers) and where the technician should look.

**Top tier — the device has stopped, or is about to:**
- Offline **server**.
- Fixed volume below `disk_critical`, falling and projected full within `disk_full_days`,
  or below `disk_warn` with persistent disk alerts (see Disks).
- Backup failing: `backup_management_ctx`, or `comp_script_ctx` whose `diagnostics`
  mention backup failed, paused, not registered or not detected.
- File system corruption: `eventlog_ctx` whose `diagnostics` name `Ntfs` and event `55`.
- AD replication failing on a domain controller: `comp_script_ctx` whose `diagnostics`
  report replication critical or failed.
- `patch_ctx` whose `diagnostics` contain `0x80070070` (a disk-full report).

**Second tier — the device is degraded:**
- Recurring unexpected shutdowns: event-log ID `6008` (EventLog) or `41` (Kernel-Power),
  two or more events. Note any regularity in the device-local times inside the
  descriptions; say what the pattern is, not what causes it.
- Fixed volume below `disk_warn`, not otherwise top tier.
- `antivirus.status` anything other than `RunningAndUpToDate`, **unless** the record is `{}`
  and the software list shows a running AV/EDR product — then report the product from the
  software list and flag the empty record in data quality.
  A record of `NotDetected` or `NotRunning` while the software list shows an AV/EDR product
  stays a finding, worded "record
  says none detected, software list shows [product] — check the AV service is running and
  reporting", with the disagreement flagged in data quality.
- `rebootRequired: true` or `patch.status: RebootRequired`.
- `patch.approved_pending` above zero, or `patch.status` other than `FullyPatched`. Name the
  pending patches (title, KB) from `list_patches` entries whose `installStatus` is
  `APPROVED_PENDING`.
- A patch in `list_patches` whose `installStatus` is not `INSTALLED` and reads as a
  failure (contains `FAIL` or `ERROR`) — name it with its KB.
- Any other recurring signature on a server.
- A component alert (`comp_script_ctx`) on a server that recurs, with no `diagnostics` —
  "component alert, output not exposed by the connector; check the component's result in
  the portal".

**Third tier — context worth one line:**
- Two or more EDR products installed (see agents below).
- Another RMM or remote-access agent installed (see agents below).
- Workstation offline — normal on its own; one line with "offline since".
- Open alerts older than `stale_alert_days`.
- `patch.not_approved` above zero — "review approvals in the patch policy".
- A muted alert whose signature matches a top- or second-tier rule. This moves the finding
  up to "look at first".

Within a tier, rank by the number of distinct signals on the device, then by most recent
evidence. When the verdict is RED, AMBER or OFFLINE, the first item becomes
**Look at first** and the next up to three become **Then** rows.

When the verdict is **GREEN**, nothing is failing, so nothing is promoted to look-at-first.
the Look at first row reads exactly "Nothing needs action now." and up to three third-tier items
follow as Then rows for housekeeping. With no findings at all, the Then rows are omitted and the answer
stays short. A healthy device must never read as if it had a problem.

### Verdict

- **RED** — any top-tier finding.
- **AMBER** — any second-tier finding.
- **GREEN** — neither.
- **OFFLINE** — for any offline device, in place of the colour. For an offline server,
  offline is itself the look-at-first item.

---

## Output

The start-up note is already written; write the report below it. The reader is a
technician deciding what to do next: lead with the answer, keep lines short, and put
how the data was read at the end.

```markdown
# Device Quick Look: [hostname]
**[date time tz]** · [class] · [site] · found by [UID | ID | MAC | name (+ site)]

## [🔴|🟠|🟢|⚫] Verdict: [RED|AMBER|GREEN|OFFLINE]
[What drove it, in one or two sentences.]

---

## Look at first
| # | Priority | Task | Why |
|---|---|---|---|
| 1 | Look at first | **[Verb] [what]** | [evidence] [ticket or "No ticket."] |
| 2 | Then | **[Verb] [what]** | [evidence] |

**Where to start on item 1:** [volume, event, service or agent to open first].

---

## Device health
| Area | Status |
|---|---|
| Status | [online, or offline since…] · [reboot pending or not] |
| System | [OS] · [model] · [CPU] · [RAM] |
| Disks | [each fixed volume: free of size (%)] |
| Patching | [status and counts; failed or pending updates by KB] |
| Security & backup | [antivirus] · [EDR/MDR] · [backup] · [other RMM or remote access] |
| Network | [NICs, IPs, MACs] · last user [name] |

---

## Alerts and activity
**Open alerts** — grouped
- [group: count, first–last, open, ticket]

**Last [n] days** — grouped; noise as one line
- [group]

**Recent activity**
- [time · what · who], or why there is none

---

## Data you shouldn't trust
- **[lead]** [one line]

---

## Coverage
| Area | Status |
|---|---|
| Device record · Audit · Open alerts · Alert history · Patches · Software · Activity log | [complete, or partial and how far] |

[History window covered], [timezone] · [n] read-only calls · Device Quick Look v[version] (alpha)
```

**Format.** Markdown laid out like the template — not a code block, not plain text: a `#`
title, a bold date line, the verdict as a `##` heading with its colour dot, `---` between
sections, the action list as a table, and Coverage as an Area | Status table. Omit any
section that would be empty.

**Writing rules.**
- Lead with the answer: one or two sentences under the verdict, with the key device names
  and numbers in **bold**.
- Action rows start with a verb ("Free up disk on…", "Reboot…", "Deploy…"). The Why cell
  holds the evidence and the ticket number or "No ticket." in one or two short sentences.
- Under the action table, a **Where to start on item 1:** line names the concrete first
  check. Add one for item 2 only when it needs its own.
- Other sections use a bold lead line with short bullets under it, one fact per bullet.
- Raw field and monitor names (`perf_disk_usage_ctx`, `patch.status`) appear only in "Data
  you shouldn't trust" and Coverage. Elsewhere say "disk alerts", "reboot pending".
- Dates as "11 Sep"; times in the user's timezone.
- End Coverage with one line: window or scope, timezone and where it came from, `[n]
  read-only calls`, and the skill name and version. If a fuller run would close a gap,
  offer it in one closing sentence after Coverage — never more than one.

**Look at first** is one row: what, the evidence, why it ranks first, ticket number or
"No ticket.", and in the line below the table the concrete place to start (volume, event,
agent). **Then** rows, at most three, follow in the same shape. Where a follow-up belongs
to another skill (see Handoffs), end that Why cell with `→ skill-name`.

**Data you shouldn't trust** — candidates: duplicate alerts per event; open alerts older than
`stale_alert_days`; alerts whose `actions` include `TICKET_CREATED` but whose
`ticketNumber` is null or empty; alert `diagnostics` missing where a rule needed them;
redacted secrets in text (count only); raw `device_type` that disagrees with the class;
an empty `antivirus` record on a device whose software list shows AV/EDR; open alerts whose
`source.site_name` differs from the device's current site (moved or re-enrolled); a device
reporting `online: true` with an offline alert still open or a `lastSeen` years old — its
online state cannot be trusted.

**Coverage** — Area | Status rows and the closing line, covering: calls made, how the device was resolved, anything partial (with the oldest
alert seen), activity-log window and entries read, the history window actually covered,
the timezone and where it came from, non-default parameters, and: "v0.4.0 does not return
UDFs, audit date, last reboot or third-party application compliance."

**HTML.** With `html` on, build the page from `assets/report-template.html` as
`references/html-report.md` describes, instead of the Markdown report.

See `references/example-output.md` for a worked example. Read it before the first run of a
session and match its shape.

---

## Handoffs

| Finding | Hand off to |
|---|---|
| The question is about the whole account or "what broke overnight" | `drmm-morning-pulse` |
| What changed on the device before the problem | `drmm-device-timeline` |
| A recurring alert that looks like noise (e.g. the bandwidth monitor) | `drmm-alert-noise-review` |
| Patch status, pending or not-approved patches | `drmm-patch-posture` |
| Top-tier finding with no ticket | `alert-to-ticket-pipeline` |
| Device offline for weeks, or looks like a duplicate enrolment | `drmm-stale-and-ghost-devices` |
| Which other devices carry the same unexpected agent | `drmm-software-finder` |

---

## Quit conditions

- The first call fails twice (access or connector problem).
- The device cannot be resolved to exactly one record, and the user has not answered.
- `get_device` fails twice.

---

## Known gaps

What this skill cannot do yet, and how to tell that it worked, is in
`references/known-gaps.md`. Read it in readme mode, or when the user asks about limits.
