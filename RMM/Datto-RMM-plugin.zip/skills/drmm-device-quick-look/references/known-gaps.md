# Device Quick Look — known gaps and success measures

## Known gaps

- **UDFs are not returned** by v0.4.0. They held the richest component data (backup
  checks, BitLocker, Windows 11 readiness) and the first live check found a product key in
  one. Server-team ask: return UDFs (with labels), and the skill will restore the COMPONENT
  DATA section with its redaction rules.
- **Structured alert context is not returned**; disk, event and patch rules read
  `diagnostics` text, which is absent on component alerts. Server-team ask.
- `lastAuditDate`, `lastReboot`, `softwareStatus`, domain, IPs and `description` are not
  returned. Server-team ask.
- The activity log returns HTTP 500 on some tenants (the sandbox); the section is then
  marked unavailable.
- **Role versus name.** A server named for a role (SQL, Exchange, DC, file) with no matching
  software — seen on `SQL-SRV01`. Not a rule yet.
- No CPU or memory utilisation, no services, no NIC speed — not in the connector's audit.
- No install dates on software or patches.
- Resolved alerts have no date filter.
- OS support lifecycle (e.g. Windows 10) is not evaluated.
- Non-agent devices get a limited view; ESXi audits carry no datastores or guest VMs.

## Measuring whether this worked

- The technician starts on the look-at-first item without opening the console.
- A device with nothing wrong gets a short GREEN answer, not a spec sheet.
- A falling disk is caught before its alert escalates.
- Duplicate and recurring alerts appear as one line each, never as rows.
- Nothing on an offline device is presented as current.
- A missing field is reported as "not exposed", never guessed.
- A failed activity-log call is never reported as "no activity".
