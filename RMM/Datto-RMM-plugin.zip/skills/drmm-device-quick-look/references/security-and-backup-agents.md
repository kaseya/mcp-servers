# Device Quick Look — security and backup agents

## Security and backup agents

Match installed software names (case-insensitive, substring) against these lists and
report what is present, with versions:

- **EDR/MDR:** Datto EDR Agent, CrowdStrike, SentinelOne, Sophos, Bitdefender, ESET,
  Huntress, RocketAgent (RocketCyber), Microsoft Defender for Endpoint, Carbon Black (its
  macOS sensor is listed as `VMware CBCloud`).
- **Backup:** Datto Endpoint Backup, Datto Windows Agent, Veeam Agent, Acronis, Cove /
  N-able Backup.
- **Other RMM and remote access:** Kaseya VSA / VSA X, ConnectWise Automate, ConnectWise
  ScreenConnect / Control, N-able N-central / N-sight / Take Control, NinjaOne, Atera,
  Syncro, Level, TeamViewer, AnyDesk, RustDesk, LogMeIn, GoTo Resolve, Microsoft Remote
  Help, Quick Assist.
  Do **not** count Datto RMM itself or Splashtop Streamer, which is Datto RMM's own
  remote-access component.

**Evidence beyond the software list.** Some agents never appear in the software list. Count an
EDR/MDR product as present, and name where it was seen, when either of these shows it:
- a process in the CPU or memory alert process lists — `MsSense.exe`, `SenseNdr.exe`, `SenseCE.exe`,
  `SenseTVM.exe` (Microsoft Defender for Endpoint), `CSFalconService.exe` (CrowdStrike),
  `SentinelAgent.exe` (SentinelOne), `RepMgr.exe` (Carbon Black), `HuntressAgent.exe` (Huntress);
- a patch title in `list_patches` naming the product (seen live: "Update for Microsoft Defender for
  Endpoint").
Write it as "Microsoft Defender for Endpoint — seen as a process and in the patch list, not in the
software list". Live check (30 Sep 2026): a laptop ran CrowdStrike and Defender for Endpoint, and
only CrowdStrike was in its software list.

Two or more EDR/MDR products is a third-tier finding (possible conflict). Any match in the
other RMM and remote-access list is a third-tier finding: a second management agent can
fight Datto RMM over patching and scripts, and remote-access tools nobody expects are a
common way in for attackers. State what was found and ask the technician to confirm it is
intended — the skill cannot tell a migration in progress from a leftover or an intrusion.
The first live GREEN run found VSA X 10.7.1 beside Datto RMM on a server. "None found" is
reported as a fact, not a problem — protection can sit outside the software list.
