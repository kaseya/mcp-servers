# Device Quick Look — HTML report

Read this only when `html` is set. The data, rules and ranking are exactly those of the
normal run; only the presentation changes. Every number comes from the run — never invent
a value to fill a slot. Leave a section out rather than fill it.

## Build

1. Read `assets/report-template.html`. Copy its `<head>`, including the whole `<style>`
   block, **unchanged**. Add no CSS, scripts or other external resources; the page must read
   correctly without the Google Fonts link.
2. Rebuild `<body>` with the template's elements and class names, section by section, from
   this run's data (mapping below). Escape `&`, `<` and `>` in names.
3. Set `<title>` to `Device Quick Look: [scope], [weekday date]` and end with
   `<footer>Device Quick Look v[version] (alpha) · [scope] · times in [timezone] · [n] read-only calls</footer>`.
4. **Check before delivering.** The page starts with exactly `<!DOCTYPE html>`,
   `<html lang="en">`, `<head>`, `<meta charset="utf-8">`, nothing between them; it has one
   `<html>`, one `<head>`, one `<style>`, one `<body>`, and no `<script>`. If anything is out
   of place, rebuild from the template. With code execution, check with a short script.
5. Deliver it as an **HTML artifact** with the same title; where artifacts are not
   available, save `device-quick-look-[scope]-[yyyy-mm-dd].html` and give the user the file.
6. In the chat, write at most three lines: the verdict sentence, action 1, and the version
   line. Do not repeat the Markdown report.

## Mapping

| Template element | Fill with |
|---|---|
| `header.verdict` | Colour by verdict (grey for OFFLINE). Stats: free space on the worst volume, open alerts, recent drops, pending reboots, tickets. |
| `.warn` | Activity log unavailable, or an offline device shown as last known. |
| Look at first `.plan .card` | Card 1 = Look at first, cards 2–3 = Then rows: task as title, priority · effort, facts with `hot` on the evidence, why, ticket chips. |
| Device health | Two-column table (class `kv narrow`): Status, System, Disks (`.sig disk` chip on a low volume), Patching, Security & backup, Network. |
| Alerts | Two panels: open alerts and history, each a `.defer` list with the count as `.r`. |
| Data quality and coverage | `details` "Data-quality flags ([n])" with `.dq` items; `details` "Coverage ([n] API calls)" with four `.cov` boxes (class `partial` when partial) and a note. |
