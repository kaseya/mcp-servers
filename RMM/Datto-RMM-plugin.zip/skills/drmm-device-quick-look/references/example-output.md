# Example output — Device Quick Look

Adapted to the drmm v0.4.0 connector from a live check against the Clouds Above IT demo
account on 21 Sep 2026 (made with the earlier connector). Fields v0.4.0 does not return —
UDFs, last reboot, third-party compliance, domain, external IP, audit date — have been
removed. The activity lines are illustrative until the first v0.4.0 production run. The
fences only mark the example — the real report is rendered Markdown, not a code block.
Prompt: *"What's going on with CAIT-B-APP1?"*

**Start-up note** — its own chat message, before the first Datto RMM call:

```
Device Quick Look v0.2.14 · last updated 5 Oct 2026 · read-only · Datto RMM
Developer note: alpha release by the Kaseya Automation Content Team. Check results before acting on them, and report anything odd.
Starting: finding the device, then reading its record, hardware, alerts, patches and software. This can take a few minutes on a large account; any permission prompts are for read-only Datto RMM tools.
Tip: say "drmm-device-quick-look readme" for the full guide and all parameters.
```

**Report:**

````markdown
# Device Quick Look: CAIT-B-APP1
**21 Sep 2026, 09:20 EDT** · Server (Main System Chassis) · Clouds Above IT · found by name (exact match)

## 🔴 Verdict: RED
**C: is at 7.6 % free** and the disk monitor has fired on three days this week. The server also has **four unexpected shutdowns since May**.

---

## Look at first

| # | Priority | Task | Why |
|---|---|---|---|
| 1 | Look at first | **Free up disk on C:** | 4.0 GB free of 52.9 GB. Disk alerts on 14, 17 and 18 Sep; the 18 Sep one is still open. Ticket T20260918.0004. |
| 2 | Then | **Find what runs at :33 past the hour** | Four unexpected shutdowns (event 6008) on 5 May, 17 Jun, 28 Jul and 26 Aug, all at :33 or :34. Four open tickets. |
| 3 | Then | **Confirm two EDR products are intended** | Datto EDR Agent 3.17.1 and CrowdStrike Windows Sensor 7.39 are both installed; overlapping EDRs can conflict. |

**Where to start on item 1:** what has grown on C: this month. The trend can't be shown — disk alerts carry no level, only the audit gives one data point.

---

## Device health

| Area | Status |
|---|---|
| Status | Online · no reboot pending |
| System | Windows Server 2022 Standard · VMware VM · Xeon E5-2630 v4, 2 cores · 4.0 GB RAM |
| Disks | C: 7.6 % free (4.0 of 52.9 GB) |
| Patching | Fully patched · 4 installed · nothing pending or failed |
| Security & backup | Datto AV running and up to date · EDR: Datto EDR, CrowdStrike, RocketAgent · Datto Endpoint Backup, no backup alerts |
| Network | Intel 82574L · 10.21.89.131 · last user SELAB\!sriccio |

---

## Alerts and activity

**Open alerts**
- Disk usage on C: — 1 open since 18 Sep 05:00 · T20260918.0004
- Unexpected shutdown — 4 events (10 alerts), 6 May to 26 Aug · 4 tickets

**Last 7 days**
- Disk usage on C: — fired 14 and 17 Sep, cleared itself in 4–6 min, fired again 18 Sep
- Bandwidth monitor — 41 events, all cleared themselves, no tickets. Noise → drmm-alert-noise-review

**Recent activity**
- 18 Sep 02:10 · patch job "Monthly Servers" completed · system
- 17 Sep 11:45 · web remote session · j.lind

---

## Data you shouldn't trust

- **Each unexpected shutdown raised 2–3 alerts** — 10 alerts for 4 events.
- **4 open alerts are older than 30 days**, the oldest from 6 May.

---

## Coverage

| Area | Status |
|---|---|
| Device record and audit | Complete (audit date not exposed by the connector) |
| Open alerts | Complete |
| Alert history | 12–21 Sep in 1 page — the 7-day window is covered |
| Patches and software | Complete |
| Activity log | 14–21 Sep, 1 page, 2 entries |

History 14–21 Sep, America/New_York (from the user) · 9 read-only calls · Device Quick Look v0.2.14 (alpha)
The connector does not return UDFs, audit date, last reboot or third-party application compliance.
````

## Notes on the example

- **RED at 7.6 % free:** the level alone is second tier; disk alerts on three different
  days make it a persistent, unfixed problem, which is top tier.
- **No trend line:** v0.4.0 gives no level on disk alerts, so the report says so instead of
  guessing a rate.
- **The bandwidth monitor produced 41 of the week's events** and is one bullet.
