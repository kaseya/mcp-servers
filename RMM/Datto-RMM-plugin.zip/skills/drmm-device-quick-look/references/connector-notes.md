# Device Quick Look — connector notes

Reference for the drmm v0.4.0 Datto RMM connector, measured live on 30 Sep 2026.
Read when a field you need is missing, a value looks wrong, or a page fails.

## Page sizes

A tool result larger than about 50 KB fails in Claude Desktop, so never request more than
these per call (sizes measured live on 30 Sep 2026):

| Call | Max per page | Size at that max |
|---|---|---|
| `list_devices` | 100 | ~45 KB |
| `list_alerts` open | 100 | ~45 KB |
| `list_alerts` resolved | 50 | ~35 KB |
| `list_sites` | 100 | ~35 KB (150 measured ~50 KB — too close to the limit) |
| `list_device_software` | 250 | ~25 KB on Windows; macOS lists run past 250 rows of system components |
| `list_patches` | 100 | small |
| `list_components` | 50 | ~23 KB |

If the same page fails twice with HTTP 500, one record in that range is unreadable (seen live:
sites 2,550–2,599 failed at every page size). Retry the range in smaller pages — half, then a
tenth — to recover the rest, and report the range that could not be read.

## Fields by tool

Confirmed against a live drmm v0.4.0 connector.

**Device record (`get_device`):** `hostname`, `device_uid`, `siteUid`, `device_type`
(chassis), `operatingSystem`, `online`, `lastSeen` (epoch ms), `rebootRequired`,
`patch{status, installed, approved_pending, not_approved}`, `antivirus{product, status}`.
Site name in `_enhanced.siteName`.
- `online` is the only authority for current state. `lastSeen` is **not a heartbeat** —
  an online server showed a `lastSeen` two days old. On an offline device, `lastSeen`
  approximates when it dropped.
- `patch.status` values seen: `FullyPatched`, `InstallError`, `NoPolicy`, `NoData`,
  `RebootRequired`. `FullyPatched` means every **approved** patch is installed.
- `antivirus.status` values seen: `RunningAndUpToDate`, `RunningAndNotUpToDate`,
  `NotRunning`, `NotDetected` (with `product: null`).
- `antivirus: {}` (empty) is **common on agent devices** — 1,146 of 1,310 in the live
  check — and can change between runs: one desktop reported CrowdStrike one day and `{}` the
  next while CrowdStrike was still installed. Read `{}` as "no AV data reported", never as
  "no antivirus"; take protection from the software list instead.
- **Not in v0.4.0:** `lastAuditDate`, `lastReboot`, `softwareStatus` (third-party
  application compliance), UDFs, `domain`, `lastLoggedInUser`, internal/external IP,
  `cagVersion`, numeric `id`, `description`. Do not report them, and do not infer them.

**Audit (`get_device_audit`):**
- `systemInfo`: `manufacturer`, `model`, `totalCpuCores`, `totalPhysicalMemory` (bytes),
  `username` (last logged-in user, may be empty), `dotNetVersion`. Use
  `totalPhysicalMemory` for RAM, not `physicalMemory`, which pads out on a VM.
- `processors[].name`, `bios{instance, releaseDate, serialNumber}`, `baseBoard`.
- `logicalDisks[]`: `diskIdentifier`, `description`, `freespace` and `size` in **bytes**.
  Fixed volumes have `description: "Local Fixed Disk"`; CD-ROM entries have null sizes.
- `nics[]`: `instance`, `ipv4`, `ipv6`, `macAddress` (with colons), `type`. No link speed.
- `_enhanced.sections_available` lists what the audit holds.

**Alerts:** `alertUid`, `priority` (`Critical`, `High`, `Moderate`, `Low`, `Information` —
how the monitor was configured, not severity; rank on type and evidence, never on
priority), `timestamp` (epoch ms), `resolved`, `resolution{by, on}` (`by` seen: `CAG`,
`AUTORESOLVER`, `autoresolver` — compare case-insensitively), `muted`, `ticketNumber` (null or empty when none), `diagnostics` (text;
**absent** on offline, `perf_mon_ctx` and component alerts), `actions` (codes such as
`EMAIL_SENT`, `TICKET_CREATED`, `COMPONENT`), `monitor_type`, `source{…}`.
v0.4.0 does **not** return the structured context (`freeSpace`, `totalVolume`, event
`source`/`code`, patch `result`, component `samples`). Read `diagnostics` as text:
- disk — **verified live: disk alerts carry no `diagnostics`**; levels come from the audit;
- CPU / memory (`perf_resource_usage_ctx`) — a top-process list such as
  `AEMAgent.exe : 73 % wevtutil.exe : 1 % …`. The first process is the main consumer;
- event log — source (`Ntfs`, `EventLog`, `Kernel-Power`), event ID, and any device-local
  time inside the text;
- patch — an HRESULT (`0x` + 8 hex) and the patch name.
When the text is missing or holds no such value, say "not reported by the connector". The
exact formats are **not yet verified live**; record an example here on the first run that
sees one.

**Patches (`list_patches`):** `patchId`, `title`, `kbArticleId`, `severity` (seen:
`CRITICAL`, `UNSPECIFIED`), `installStatus` (seen: `INSTALLED`, and `APPROVED_PENDING` — approved, waiting to install), `type`, `rebootRequired`,
`releaseDate` (platform-local, no zone). No install date.

**Software:** `name`, `version`. Nothing else.

## Live evidence behind the rules

- `antivirus: {}` on 1,146 of 1,310 agent devices; an offline workstation still reported
  `RunningAndUpToDate` two and a half months after it dropped.
- Two Macs had Webroot SecureAnywhere installed while the record said none detected.
- 100 resolved alerts on one server spanned 81 minutes, all one CPU monitor.
- Disk: a server at 5.3 % free with disk alerts open since 11, 26 and 28 Sep. In an earlier
  check the alert said 9.5 %, the audit three days later 7.6 %, and history 10.0 % the day
  before: the trend was the finding.
- One unexpected shutdown was raised three times (three alerts, one ticket); 49 of 50
  history entries were one bandwidth monitor; the RMM agent topped 81–89 % of CPU alerts
  on three devices.
- `get_device_audit` and `list_device_software` return 400 "not of class device" on some
  network-discovered devices; ESXi audits have no datastores or guest VMs.
- The record has no `description`, so a renamed machine is found only under its current
  hostname. `get_device` and `list_devices` return the same trimmed record.
- Activity-log entries (verified live 5 Oct 2026; the sandbox returns HTTP 500):
  `id`, `entity` (e.g. `USER`, `DEVICE`), `category` (e.g. `account`), `action` (e.g. `login`),
  **`date` — epoch seconds with decimals** (e.g. `1791191241.299`; alerts and `lastSeen` are
  milliseconds), `hostname` (null for account events), `actor` (user name or system),
  `summary` (JSON text, cut at about 200 characters), `has_output`. Paging: pass
  `_enhanced.next_search_after` back as `search_after`. Summaries can hold a user's e-mail and
  source IP — never repeat them.
