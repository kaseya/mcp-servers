---
name: "drmm-security-coverage-gaps"
description: Read-only, vendor-agnostic antivirus and EDR coverage audit for a Datto RMM account or chosen sites. Opens with a start-up note (version, expected wait). Reads the antivirus product and status Datto RMM records on every server, desktop and laptop, uses the account's software-based device filters to find which endpoints carry an EDR or MDR agent, and reports endpoints with no protection, protection that is stopped or out of date, no EDR, or conflicting security products — servers first, offline devices kept apart as last-known. Produces per-site coverage figures a technician can act on and an MSP can hand to a customer, auditor or cyber-insurance questionnaire. Use this whenever the user asks about antivirus or EDR coverage, unprotected endpoints, disabled or outdated AV, which devices lack EDR, security gaps, Defender status, insurance or compliance questions about endpoint protection, or whether a customer is protected. For one named device, use drmm-device-quick-look instead.
metadata:
  version: "0.1.15"
  last_updated: "2026-10-05"
  type: "Datto RMM Skill"
  stage: "alpha"
  execution: "read-only"
  author: "Kaseya Automation Content Team"
compatibility: Requires the Datto RMM connector (drmm v0.4.0 tool set — the "Datto RMM" desktop extension or the datto-mcp remote server). See "Tools" below.
---

# Security Coverage Gaps

## Run banner and readme

A full run takes several minutes, and in Claude Desktop the user sees only a collapsed
progress box while tools run. So the skill's output has two parts: a short start-up note,
written as a chat message once you have read this file and before the first Datto RMM
call (step 0 below), and then the report. The start-up note is these four lines:

```
Security Coverage Gaps v0.1.15 · last updated 5 Oct 2026 · read-only · Datto RMM
Developer note: alpha release by the Kaseya Automation Content Team. Check results before acting on them, and report anything odd.
Starting: reading devices, antivirus records and security software filters. This can take a few minutes on a large account; any permission prompts are for read-only Datto RMM tools.
Tip: say "drmm-security-coverage-gaps readme" for the full guide and all parameters.
```

Then gather the data and write the report. Its Coverage line carries the version and the
alpha mark too, so the reader still sees them if the note scrolls away.

**Readme mode.** When the message contains the word `readme` (with or without a slash) or
asks you to explain this skill: `readme` is a mode word, not a file — do not search for a
README file. Open `references/readme-guide.md` in this skill's folder and follow it.
Gather no data and call no Datto RMM tools.

---

## Goal

Answer one question:

> **Which managed endpoints are not protected right now, and which do we fix first?**

"Protected" has two layers, and the output keeps them separate:

1. **Antivirus** — a product is installed, running and up to date (what Datto RMM records
   on every agent device).
2. **EDR / MDR** — an endpoint detection agent is present (found through the account's
   software-based device filters).

A single blended "security score" hides which layer is missing and is not used. Neither is
the insurance-premium arithmetic from earlier drafts: the skill reports facts an insurer or
auditor can check, and leaves the pricing to them.

**Vendor-agnostic.** The review judges capability, not brand: is there an antivirus engine,
is it running and current, is there an EDR agent. Every vendor counts the same — a Datto,
Microsoft, CrowdStrike, Sophos or any other product scores identically for the same state.
The skill never favours, recommends or suggests replacing a product, never treats one
vendor's filter as more authoritative than another, and words every fix as "deploy / start /
update the MSP's standard AV or EDR" rather than naming a vendor. Where the MSP runs several
products, it reports what is present and leaves the choice to them.

Security Coverage Gaps is diagnostic only. It never installs, starts or reconfigures an
agent, and never runs a job. The connector's write tools are not called.

---

## Tools

All calls go through the **Datto RMM connector** (drmm v0.4.0). Use these and nothing else.

| Purpose | Tool | Notes |
|---|---|---|
| Filter IDs | `list_device_filters` | `filter_type: "default"`, then `"custom"`. Resolve by **name**. |
| Population | `list_devices` with `filter_id` | `count` is the true total for filters. Max 100 per page. |
| One site | `list_devices` with `site_uid` | Exactly one selector per call. |
| Sites | `list_sites` | Names, `devices.total`, `autotaskCompanyId`. |
| Spot-check software | `list_device_software` | For current devices with no AV data, servers with no EDR evidence, and conflicts — within `software_budget`. Fails with 400 on network-discovered devices. macOS lists run past 250 rows — read every page before concluding a product is absent (live: the AV product was on page 2). |

### Filters this skill uses

Resolve each by name at run time; skip any the account does not have and say so.

| Role | Default filter names |
|---|---|
| Population | `All Server O/S`, `All Desktop O/S`, `All Laptops`, `MacOS` |
| Platform AV gap list (any vendor) | `Antivirus Disabled` |
| Vendor-named filters (all equal) | `AVG`, `Avira`, `Datto EDR`, `ESET`, `Kaspersky`, `McAfee`, `Panda`, `RocketCyber`, `Sophos`, `Symantec`, `Trend Micro`, `Webroot` |

These twelve are the vendor-named default filters Datto RMM happens to ship (verified live).
They are a convenience, not a preference: each one only proves "this vendor's software is
installed", and its role (AV, EDR or both) comes from the vendor catalogue, the same as for
any other vendor. Vendors without a default filter are found just as completely through the
**vendor catalogue** below, in three places: custom filter names, the `antivirus.product`
text, and software spot-check names.

Then read **custom** filters and add any whose name contains (case-insensitive) `EDR`,
`MDR`, `XDR`, `EPP`, `antivirus`, `AV `, or any vendor or product name from the catalogue.
Give each the role its catalogue row says (AV, EDR or both). List the custom filters used in
coverage — the skill trusts the MSP's naming and says so.

### Vendor catalogue

About 40 vendors, each with the product and software names to match and whether a match
counts as AV, EDR or both, plus the EDR process names and the products that never count as
protection, are in `references/vendor-catalogue.md`. **Read it before classifying any
product.** Match case-insensitively on substrings. Every vendor counts the same.

### Page sizes

Claude Desktop rejects a tool result over about 50 KB. Per call, never request more than:
devices 100, open alerts 100, resolved alerts 50, sites 100, device software 250 (a Mac
needs two or more pages), patches 100, components 50. If the same page fails twice with
HTTP 500, one record in that range is unreadable: retry the range in smaller pages to read
around it, and report the range. Measured sizes: `references/connector-notes.md`.

---

## Parameters

Apply the default when not given, and state any non-default value in the coverage
footer. Users set these in plain words ("only Northwind Legal", "look back 14 days").

| Parameter | Default | Effect |
|---|---|---|
| `sites` | none | Restrict to named sites (per-site gathering). |
| `include_workstations` | true | Servers are always in scope. |
| `offline_after` | 7 days | Offline longer than this goes to "last known", not to the gap lists. |
| `edr_required` | true | When false, missing EDR is reported as a count only, not a gap. |
| `standard_products` | none | The customer's own standard AV and/or EDR products, in the customer's words. When given, also count current devices that run none of them (see "Not on standard"). Every vendor is still judged the same way; this only reflects the customer's choice. |
| `timezone` | the user's | The connector has no account timezone. UTC if unknown — say so. |
| `html` | off | On when the user's message contains the word `html` ("drmm-security-coverage-gaps html", "as HTML"). Same run, delivered as a styled HTML page: read `references/html-report.md` before writing the report. |

**Reading parameters.** Text in quotes is one value, taken exactly (`"Google Chrome"`,
`sites "- Datto Devices"`). Without quotes, a value runs until the next parameter word
(`version`, `sites`, `days`, `html`, `readme` …, or "for"/"at" before a site). Multi-word
names match as a whole phrase, case-insensitively, never word by word. If a word could
belong to two values, ask once before reading data. Coverage echoes what was understood
(Searched for "Google Chrome" · sites: Northwind Legal).

**Advanced — budgets.** Change these only when a run stops early on a large account.

| Budget | Default | Effect |
|---|---|---|
| `page_budget` | 100 | Total `list_devices` pages (at 100) before stopping and asking. |
| `software_budget` | 30 | `list_device_software` spot-checks. |

---

## Scope boundary

| In scope | Out of scope |
|---|---|
| AV presence, running state, definitions | Security alerts and incidents → `alert-to-ticket-pipeline` |
| EDR/MDR presence by filter | Patch exposure → `drmm-patch-posture` |
| Conflicting security products | One device's full picture → `drmm-device-quick-look` |
| Per-site coverage figures | Firewall, BitLocker, MFA — not in the connector (see gaps) |

---

## Data gathering

0. **Post the start-up note** from "Run banner and readme" as a chat message, before
   any Datto RMM call below. Then continue straight away; do not wait for a reply.
   Between steps, a one-line progress note is fine ("Devices read, reading alerts next").

1. `list_device_filters` default and custom → resolve names to IDs.
2. **Population.** For each population filter, page `list_devices filter_id` (or, with
   `sites`, page `list_devices site_uid` per site). Budget check first: sum the
   filter `count`s, divide by 100; above `page_budget`, say how many pages it would take
   and ask whether to narrow to sites.
3. **Protection sets.** For every EDR and vendor filter, page `list_devices filter_id` and
   keep only the set of `device_uid`s. These are usually small.
4. `list_devices` with `Antivirus Disabled` → cross-check set.
5. `list_sites` for names and totals (page at 100).
6. **Spot-checks** — up to `software_budget` `list_device_software` calls, spent in this
   order: current **servers** with no AV data, current servers flagged "no EDR" (to
   confirm), current workstations with no AV data, current devices whose record says none
   detected or not running (to see what is installed), then devices with two or more security
   products (to confirm the conflict). Match the software names against the AV and EDR
   product lists below; a match overrides the empty record.

Retry a failing page once. A population filter that fails twice stops the run; a
protection-set filter that fails is listed in coverage and its product is treated as
"unknown", never as "absent".

### Gotchas

Confirmed against a live drmm v0.4.0 connector. The full field list for each tool is in
`references/connector-notes.md`; read it when a field you need is missing or a value looks wrong.

- `antivirus: {}` means "no AV data reported", never "no antivirus" (1,146 of 1,310 agent
  devices in the live check, and it can change between runs).
- `status` values seen: `RunningAndUpToDate`, `RunningAndNotUpToDate`, `NotRunning`,
  `NotDetected`. Show anything else verbatim as unknown.
- `product` is free text from the endpoint, misspellings included
  (`Mcafeee Total Protection`). Match on substrings; never correct it in the output.
- `device_type` is the hardware chassis. Never read "server" from it.
- The device record has no definition date, EDR field, firewall or encryption state.

---

## Computation

### In scope

Endpoints only: rows whose `operatingSystem` is Windows, macOS or Linux. Exclude mobile
(`iOS`, `iPadOS`, `Android`), ESXi (`VMware ESXi`) and rows with a null `operatingSystem`.
Keep rows with `antivirus: {}` — they are in scope with the state "no AV data".
Deduplicate by `device_uid` across population filters.

**Class:** **server** if the row came from `All Server O/S` or `operatingSystem` contains
`Server`; otherwise **workstation**. In site mode (no population filters), page
`All Server O/S` once to get the server set when its `count` is under 2,000; otherwise
classify by `operatingSystem` only and say so in coverage.

Split into **current** (online, or offline ≤ `offline_after`) and **last known** (offline
longer). Only current devices feed the gap lists, the percentages and the verdict.

### AV state per device

| State | Rule |
|---|---|
| **Protected** | `status` = `RunningAndUpToDate` |
| **Out of date** | `RunningAndNotUpToDate` |
| **Not running** | `NotRunning`, or the device is in `Antivirus Disabled` |
| **None detected** | `NotDetected`, or `product` null with a status present |
| **No AV data** | `antivirus` is `{}`. If a spot-check finds an AV/EDR product in the software list, use that product and mark it "from software list"; otherwise the state stays "no AV data" |
| **Unknown** | any other value |

**Record and software disagree.** A `NotDetected` record is not proof that nothing is
installed: in the live check two Macs reported `NotDetected` while a vendor filter and their
software lists showed an AV product and an EDR sensor. When a current device is
`NotDetected` or `NotRunning` but sits in a vendor filter, or a spot-check finds a catalogue
product:
- keep it in the fix list at its rank — an engine the platform cannot see running is still a
  gap;
- name the installed product on the row ("AV none detected by the record; [product]
  installed");
- make the next step "check the AV service is running and reporting", not "deploy";
- count its EDR state from the software list as usual;
- add a data-quality flag.
Never upgrade such a device to Protected from the software list alone — only an empty record
(`{}`) is overridden by the software list.

### EDR state per device

- **EDR present** — the device is in any EDR-role set, **or** `antivirus.product` or a
  spot-checked software name matches a catalogue row of type **EDR** or **AV+EDR**, **or**
  (supporting evidence only) an EDR process name appears in its alert process lists.
- **AV only** — AV present but no EDR evidence.
- **No EDR evidence** — neither. This is "not found through filters", not proof of
  absence; say so in the section header.

### Conflicts

A device with two or more products whose catalogue type includes **AV** (AV or AV+EDR) from
different vendors — for example Sophos and Webroot, or CrowdStrike and Bitdefender — is a
**possible conflict**. Not conflicts: Microsoft Defender Antivirus alongside a third-party
product (Defender goes passive); an agent whose catalogue type is EDR only (for example
Arctic Wolf, Blackpoint, Datto EDR, Defender for Endpoint, Huntress, Rapid7, RocketCyber)
alongside any AV. Two EDR agents from
different vendors are not a conflict but a **duplicate spend** worth one line. Confirm with
a software spot-check when budget allows; otherwise label "unconfirmed".

### Not on standard (only with `standard_products`)

Count current devices whose AV product and EDR evidence match none of the products the
customer named. Report counts per site, names when five or fewer. It is not a gap on its
own and never changes a device's rank or the verdict: another vendor's working product is
still protection.

### Ranking the fix list

1. **Server, AV none detected or not running** — the worst exposure on the account.
2. **Server, no EDR evidence** (when `edr_required`).
3. **Server, AV out of date**, or **server with no AV data** after the software
   spot-check found nothing — "cannot confirm protection".
4. **Workstation, AV none detected or not running.**
5. **Conflict** on any device.
6. **Workstation, no EDR evidence** — reported per site as counts, listed only when a site
   has five or fewer.
7. **Workstation, AV out of date** — counts per site.
8. **Workstation, no AV data** — counts per site; never listed as unprotected.

Within a rank, sort by site with the most gaps, then hostname.

### Site coverage

Per site, over **current** devices:
`AV protected x/y · EDR present x/y · no AV data n · gaps [n]`. Devices with no AV data
are left out of the `y` in "AV protected x/y" and shown separately, so an empty record never
lowers or raises coverage. Sort sites by gaps descending. Sites with
zero gaps collapse into one line: "[n] sites fully covered".

### Verdict

- **RED** — any rank 1 or rank 2 item.
- **AMBER** — any rank 3–5 item, or AV-protected below 95 % of current devices with AV
  data. If more than half of current devices have no AV data, say that coverage cannot be
  measured from this connector and name the spot-check results instead.
- **GREEN** — otherwise.

Last-known devices never affect the verdict.

---

## Output

The start-up note is already written; write the report below it. The reader is a
technician deciding what to do next: lead with the answer, keep lines short, and put
how the data was read at the end.

```markdown
# Security Coverage Gaps: [account or sites]
**[date time tz]** · [n] endpoints in scope · [n] current · [n] last known

## [🔴|🟠|🟢] Verdict: [RED|AMBER|GREEN]
[The worst exposure, in one or two sentences.]

---

## Fix first
| # | Rank | Task | Why |
|---|---|---|---|
| 1 | [1–5 · reason in two words] | **[Start / Update / Deploy …] on [device]** ([site], [type]) | [state and product] |

**Where to start on item 1:** [the concrete first check]. → drmm-device-quick-look for servers

---

## Protection by site
| Site | AV protected | EDR present | No AV data | Gaps |
|---|---|---|---|---|

[n] sites fully covered. Account, current devices: [one line of totals].

---

## What else we found
**No EDR evidence** — not found through filters, products or software; not proof of absence
- [site: count, or names when five or fewer]

**Conflicts** · **Not on standard** (only with `standard_products`) · **AV out of date**
- [one fact per bullet]

**Last known** (offline over [n] days, never in the verdict)
- [counts by state; top sites]

**Products seen**
- [product: count, top 10]

---

## Data you shouldn't trust
- **[lead]** [one line]

---

## Coverage
| Area | Status |
|---|---|
| Population filters · Protection filters · Software spot-checks · Sites | [complete, or partial] |

[Scope], [timezone] · [n] read-only calls · Security Coverage Gaps v[version] (alpha)
EDR detection relies on device filters; an agent not covered by a filter shows as no EDR evidence.
```

**Format.** Markdown laid out like the template — not a code block, not plain text: a `#`
title, a bold date line, the verdict as a `##` heading with its colour dot, `---` between
sections, the action list as a table, and Coverage as an Area | Status table. Omit any
section that would be empty.

**Writing rules.**
- Lead with the answer: one or two sentences under the verdict, with the key device names
  and numbers in **bold**.
- Action rows start with a verb ("Free up disk on…", "Reboot…", "Deploy…"). The Why cell
  holds the evidence and the ticket number or "No ticket." in one or two short sentences.
- Under the action table, a **Where to start on item 1:** line names the concrete first
  check. Add one for item 2 only when it needs its own.
- Other sections use a bold lead line with short bullets under it, one fact per bullet.
- Raw field and monitor names (`perf_disk_usage_ctx`, `patch.status`) appear only in "Data
  you shouldn't trust" and Coverage. Elsewhere say "disk alerts", "reboot pending".
- Dates as "11 Sep"; times in the user's timezone.
- End Coverage with one line: window or scope, timezone and where it came from, `[n]
  read-only calls`, and the skill name and version. If a fuller run would close a gap,
  offer it in one closing sentence after Coverage — never more than one.

Each Fix first row's Task names the concrete next step: "start the AV service / check the
policy", "deploy the MSP's standard EDR", "update definitions — check the device can reach the vendor", and
`→ drmm-device-quick-look` for servers.

**Data you shouldn't trust** — candidates: devices in `Antivirus Disabled` whose record says
`RunningAndUpToDate` (or the reverse); products with misspelled or generic names;
protection filters that failed; population filter totals that differ from rows read;
devices whose record says none detected or not running while a vendor filter or the software
list shows a product; the share of devices with no AV data; devices whose empty record was overridden by the
software list.

**Coverage** — Area | Status rows and the closing line, covering: calls, filters used (name and ID, default vs custom), pages read, spot-checks
used, anything partial, timezone (user's, else UTC — the connector exposes none),
non-default parameters, and this line: "EDR detection relies on device filters; an agent
not covered by a filter is reported as no EDR evidence."

**HTML.** With `html` on, build the page from `assets/report-template.html` as
`references/html-report.md` describes, instead of the Markdown report.

See `references/example-output.md` for the shape.

---

## Handoffs

| Finding | Hand off to |
|---|---|
| A server gap needs a full look | `drmm-device-quick-look` |
| "Which devices have product X, which version?" | `drmm-software-finder` |
| Unprotected devices that are long offline | `drmm-stale-and-ghost-devices` |
| Gap on a server with no ticket | `alert-to-ticket-pipeline` |

---

## Quit conditions

- `list_device_filters` fails twice, or no population filter resolves.
- The population exceeds `page_budget` and the user has not narrowed it.
- Zero agent devices in scope — say so; never report GREEN.

---

## Known gaps

What this skill cannot do yet, and how to tell that it worked, is in
`references/known-gaps.md`. Read it in readme mode, or when the user asks about limits.
