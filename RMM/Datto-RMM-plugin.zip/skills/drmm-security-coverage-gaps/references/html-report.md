# Security Coverage Gaps — HTML report

Read this only when `html` is set. The data, rules and ranking are exactly those of the
normal run; only the presentation changes. Every number comes from the run — never invent
a value to fill a slot. Leave a section out rather than fill it.

## Build

1. Read `assets/report-template.html`. Copy its `<head>`, including the whole `<style>`
   block, **unchanged**. Add no CSS, scripts or other external resources; the page must read
   correctly without the Google Fonts link.
2. Rebuild `<body>` with the template's elements and class names, section by section, from
   this run's data (mapping below). Escape `&`, `<` and `>` in names.
3. Set `<title>` to `Security Coverage Gaps: [scope], [weekday date]` and end with
   `<footer>Security Coverage Gaps v[version] (alpha) · [scope] · times in [timezone] · [n] read-only calls</footer>`.
4. **Check before delivering.** The page starts with exactly `<!DOCTYPE html>`,
   `<html lang="en">`, `<head>`, `<meta charset="utf-8">`, nothing between them; it has one
   `<html>`, one `<head>`, one `<style>`, one `<body>`, and no `<script>`. If anything is out
   of place, rebuild from the template. With code execution, check with a short script.
5. Deliver it as an **HTML artifact** with the same title; where artifacts are not
   available, save `security-coverage-gaps-[scope]-[yyyy-mm-dd].html` and give the user the file.
6. In the chat, write at most three lines: the verdict sentence, action 1, and the version
   line. Do not repeat the Markdown report.

## Mapping

| Template element | Fill with |
|---|---|
| `header.verdict` | Colour by verdict. Stats: current endpoints, AV protected x/y, EDR present x/y, conflicts, last known. |
| Fix first | Table: #, rank as a `.sig` chip (`disk` for ranks 1–2, `bak` for 3–4, `ntfs` for 5), task with site and type on a second line, why (with `→ drmm-device-quick-look` for servers). |
| Protection by site | Table, sites with gaps only; the fully covered sites go in the section subtitle. |
| What else we found | Left panel: bold-lead lists (no EDR evidence, AV out of date, duplicate EDR, not on standard). Right panel: last-known states as `.offrow` bars, class `all` on unprotected states. |
| Data quality and coverage | `details` "Data-quality flags ([n])" with `.dq` items; `details` "Coverage ([n] API calls)" with four `.cov` boxes (class `partial` when partial) and a note. |
