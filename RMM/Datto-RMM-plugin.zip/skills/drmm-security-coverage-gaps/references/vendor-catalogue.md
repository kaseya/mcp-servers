# Security Coverage Gaps — vendor catalogue

Match case-insensitively on substrings of the product or software name. **Type** decides
how a match counts: **AV** = an antivirus / endpoint-protection engine; **EDR** = detection
and response agent (including MDR and XDR agents); **AV+EDR** = one agent that does both.
Where a vendor sells the two separately, the product name decides — "Sophos Endpoint" is AV,
"Sophos Intercept X" is AV+EDR.

| Vendor | Match on (product / software names) | Type |
|---|---|---|
| Acronis | `Acronis Cyber Protect` (AV); `Acronis EDR` | AV / AV+EDR |
| Arctic Wolf | `Arctic Wolf Agent`, `Arctic Wolf` | EDR / MDR |
| Avast / AVG / Avira / Norton | `Avast`, `AVG`, `Avira`, `Norton` | AV (consumer — note it on business endpoints) |
| Bitdefender | `GravityZone`, `Bitdefender Endpoint Security Tools` (AV+EDR); `Bitdefender` (AV) | AV / AV+EDR |
| BlackBerry / Cylance | `CylancePROTECT` (AV), `CylanceOPTICS` (EDR), `Cylance` | AV / EDR |
| Blackpoint Cyber | `Blackpoint`, `SnapAgent`, `SNAP-Defense` | EDR / MDR |
| Broadcom / Symantec | `Symantec Endpoint Protection`, `Symantec Endpoint Security` (Carbon Black has its own row) | AV (+EDR in SES Complete) |
| Check Point | `Harmony Endpoint`, `Endpoint Security` (Check Point) | AV+EDR |
| Cisco | `Cisco Secure Endpoint`, `AMP for Endpoints`, `Immunet` | AV+EDR |
| Comodo / Xcitium | `Comodo`, `Xcitium` | AV+EDR |
| Coro | `Coro` | AV+EDR |
| CrowdStrike | `CrowdStrike`, `Falcon Sensor`, `CrowdStrike Windows Sensor` | AV+EDR |
| Cybereason | `Cybereason`, `ActiveProbe` | AV+EDR |
| Datto AV | `Datto AV` | AV |
| Datto EDR | `Datto EDR`, `Infocyte` | EDR |
| Deep Instinct | `Deep Instinct` | AV |
| Elastic | `Elastic Defend`, `Elastic Endpoint`, `Elastic Agent` | AV+EDR |
| Emsisoft | `Emsisoft` | AV |
| ESET | `ESET Inspect` (EDR); `ESET Endpoint Security`, `ESET Endpoint Antivirus`, `ESET Server Security`, `ESET PROTECT` (AV) | AV / EDR |
| Field Effect | `Covalence` | EDR / MDR |
| Fortinet | `FortiEDR` (EDR); `FortiClient` (AV) | AV / EDR |
| G DATA | `G DATA` | AV |
| Heimdal | `Heimdal` | AV / AV+EDR |
| Huntress | `Huntress` | EDR / MDR (managed Defender AV on top) |
| Kaspersky | `Kaspersky Endpoint Security`, `Kaspersky Endpoint Detection` | AV / AV+EDR |
| Malwarebytes / ThreatDown | `Malwarebytes`, `ThreatDown` | AV / AV+EDR |
| Microsoft Defender Antivirus | `Windows Defender`, `Microsoft Defender Antivirus` | AV (passive when another AV runs) |
| Microsoft Defender for Endpoint | `Defender for Endpoint`, `Microsoft Defender ATP`, `Sense` (service) | EDR |
| Palo Alto Networks | `Cortex XDR`, `Traps` | AV+EDR |
| Panda / WatchGuard | `Panda Adaptive Defense`, `WatchGuard EPDR`, `WatchGuard Endpoint Security` (AV+EDR); `Panda Endpoint Protection` (AV) | AV / AV+EDR |
| Qualys | `Qualys Cloud Agent` with EDR module | EDR (only if the MSP says the module is on) |
| Rapid7 | `Rapid7 Insight Agent`, `InsightIDR` | EDR |
| RocketCyber | `RocketAgent`, `RocketCyber` | EDR / MDR |
| SentinelOne | `SentinelOne`, `Sentinel Agent` | AV+EDR |
| Sophos | `Sophos Intercept X` (AV+EDR); `Sophos Endpoint`, `Sophos Anti-Virus` (AV) | AV / AV+EDR |
| Tanium / Uptycs / LimaCharlie / Wazuh | `Tanium`, `Uptycs`, `LimaCharlie`, `Wazuh` | EDR |
| Trellix / McAfee / FireEye | `Trellix Endpoint`, `McAfee Endpoint Security`, `McAfee Total Protection`, `FireEye Endpoint Agent`, `xagt` | AV / EDR |
| Trend Micro | `Vision One`, `Apex One` (AV+EDR); `Worry-Free`, `OfficeScan`, `Deep Security` (AV) | AV / AV+EDR |
| VIPRE | `VIPRE` | AV |
| VMware / Broadcom Carbon Black | `Carbon Black`, `CbDefense`, `VMware CBCloud`, `CBCloud` (the macOS sensor's name — seen live) | AV+EDR |
| Webroot | `Webroot SecureAnywhere`, `Webroot Business Endpoint` | AV |
| WithSecure / F-Secure | `WithSecure Elements`, `F-Secure` | AV / AV+EDR |

**Not AV or EDR** — application allowlisting and ringfencing (`ThreatLocker`,
`Airlock Digital`), vulnerability scanners and backup agents. Report them in PRODUCTS SEEN
if found, but they never count as protection.

**Generic names** — a product called only `Endpoint Security`, `Endpoint Protection` or
`Antivirus` (seen live: "Endpoint Security") cannot be attributed. Count it as AV present,
name it verbatim, and flag it in data quality.

**Process names as evidence.** CPU alert `diagnostics` list the top processes. These
names prove an EDR agent is running even when the record and software list are empty (seen
live: `SenseNdr.exe` on a desktop whose antivirus record was `{}`). Use them only as
supporting evidence, never to mark a device unprotected:
`MsSense.exe`, `SenseNdr.exe`, `SenseCE.exe`, `SenseTVM.exe` (Defender for Endpoint) · `CSFalconService.exe`
(CrowdStrike) · `SentinelAgent.exe` (SentinelOne) · `RepMgr.exe`, `cb.exe` (Carbon Black) ·
`cyserver.exe`, `CortexXDR` (Cortex XDR) · `HuntressAgent.exe` (Huntress) · `xagt.exe`
(Trellix / FireEye) · `SophosED.exe`, `SophosHealth.exe` (Sophos) · `EPProtectedService.exe`,
`bdservicehost.exe` (Bitdefender) · `ekrn.exe` (ESET) · `WRSA.exe` (Webroot) ·
`RocketAgent.exe` (RocketCyber) · `ArcticWolfAgent.exe` (Arctic Wolf) · `ir_agent.exe`
(Rapid7).
