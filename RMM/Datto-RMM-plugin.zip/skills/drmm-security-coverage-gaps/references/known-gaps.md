# Security Coverage Gaps — known gaps and success measures

## Known gaps

- No definition date or last-scan time on the device record — "out of date" relies on
  Datto's own status. Server-team ask.
- EDR presence depends on filters; the connector cannot create a filter or search
  software account-wide. Server-team ask: a software-search endpoint.
- No firewall, BitLocker or MFA state through this connector (the old draft's firewall and
  BitLocker columns are dropped until it does). BitLocker can sometimes be read from UDFs,
  which v0.4.0 does not return.
- No security-product health from the vendors' own management consoles (any AV or EDR);
  the skill sees only what Datto RMM records and what the software list shows.

## Measuring whether this worked

- A server with no running AV is always first.
- AV and EDR are never merged into one figure.
- Defender plus a third-party product is not called a conflict.
- Offline devices never drag the site percentages down.
- A customer-facing coverage line can be copied straight into a QBR or questionnaire.
