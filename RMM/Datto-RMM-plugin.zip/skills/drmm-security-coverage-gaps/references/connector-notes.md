# Security Coverage Gaps — connector notes

Reference for the drmm v0.4.0 Datto RMM connector, measured live on 30 Sep 2026.
Read when a field you need is missing, a value looks wrong, or a page fails.

## Page sizes

A tool result larger than about 50 KB fails in Claude Desktop, so never request more than
these per call (sizes measured live on 30 Sep 2026):

| Call | Max per page | Size at that max |
|---|---|---|
| `list_devices` | 100 | ~45 KB |
| `list_alerts` open | 100 | ~45 KB |
| `list_alerts` resolved | 50 | ~35 KB |
| `list_sites` | 100 | ~35 KB (150 measured ~50 KB — too close to the limit) |
| `list_device_software` | 250 | ~25 KB on Windows; macOS lists run past 250 rows of system components |
| `list_patches` | 100 | small |
| `list_components` | 50 | ~23 KB |

If the same page fails twice with HTTP 500, one record in that range is unreadable (seen live:
sites 2,550–2,599 failed at every page size). Retry the range in smaller pages — half, then a
tenth — to recover the rest, and report the range that could not be read.

## Fields by tool

From a live drmm v0.4.0 connector:

- `antivirus` is `{product, status}` or **`{}`**. The empty form is **not** limited to
  network devices: in the live check 1,146 of 1,310 agent devices had `{}`, and one desktop
  reported CrowdStrike one day and `{}` the next while its software list still showed
  CrowdStrike Windows Sensor 7.40. `{}` means "no AV data reported", never "no antivirus".
- `status` values seen live: `RunningAndUpToDate`, `RunningAndNotUpToDate`, `NotRunning`,
  `NotDetected` (with `product: null`). Treat anything else as unknown and show it verbatim.
- `product` is free text from the endpoint (`Windows Defender Antivirus`, `CrowdStrike
  Falcon Sensor`, `Datto AV`, and misspellings such as `Mcafeee Total Protection`). Match
  case-insensitively on substrings; never correct it in the output.
- `device_type` is the **hardware chassis type**, not the RMM category (`Desktop`,
  `Portable`, `Notebook`, `MacBook`, `Main System Chassis` for a Windows Server, `ESXi
  Host`, `Network Device`). Never read "server" from it. Also `online`, `lastSeen` (epoch
  ms), `siteUid`, `hostname`, `device_uid`, `operatingSystem`.
- The device record carries **no** definition date, EDR field, firewall state or
  encryption state.
