# Example output — Security Coverage Gaps

From a live run against a Datto RMM sandbox account on 30 Sep 2026. Device, site and user
names are replaced; the numbers are real. Long lists are shortened. The fences only mark the
example — the real report is rendered Markdown, not a code block. Product names are as the devices reported them.
Prompt: *"Which endpoints aren't protected?"*

**Start-up note** — its own chat message, before the first Datto RMM call:

```
Security Coverage Gaps v0.1.15 · last updated 5 Oct 2026 · read-only · Datto RMM
Developer note: alpha release by the Kaseya Automation Content Team. Check results before acting on them, and report anything odd.
Starting: reading devices, antivirus records and security software filters. This can take a few minutes on a large account; any permission prompts are for read-only Datto RMM tools.
Tip: say "drmm-security-coverage-gaps readme" for the full guide and all parameters.
```

**Report:**

````markdown
# Security Coverage Gaps: account
**30 Sep 2026, 14:26 CEST** · 1,347 endpoints in scope · 7 current · 1,340 last known

## 🔴 Verdict: RED
**NWL-APP01, the only current server, has antivirus but no EDR evidence.** Antivirus is fully protected on only **3 of 7** current endpoints.

---

## Fix first

| # | Rank | Task | Why |
|---|---|---|---|
| 1 | 2 · server, no EDR | **Deploy the standard EDR on NWL-APP01** (Northwind Legal, server) | Windows Defender Antivirus is running; no EDR in its 11 applications or in any EDR filter. → drmm-device-quick-look |
| 2 | 4 · AV not reporting | **Check the AV service on PCC-MAC02** (Pinecrest Clinic, MacBook Pro) | Record says none detected, but Webroot SecureAnywhere 9.4.1 is installed. EDR present (VMware CBCloud). |
| 3 | 4 · AV not reporting | **Check the AV service on BSM-MAC01** (Brightside Media, MacBook Pro) | Same as item 2. |
| 4 | 5 · conflict | **Choose one engine on both Macs** | Webroot and Carbon Black both run as antivirus — two vendors, confirmed in the software lists. |

**Where to start on item 1:** the MSP's standard EDR deployment for servers at Northwind Legal.

---

## Protection by site

| Site | AV protected | EDR present | No AV data | Gaps |
|---|---|---|---|---|
| Pinecrest Clinic | 0/2 | 2/2 | 0 | 2 |
| Northwind Legal | 1/1 | 0/1 | 0 | 1 |
| Brightside Media | 0/1 | 1/1 | 0 | 1 |
| Westgate Retail | 0/1 | 0/1 | 0 | 1 |

2 sites fully covered (Accura Tax, Hillford Freight). Account, current: AV protected 3 of 7 (43 %) · EDR present 5 of 7.

---

## What else we found

**No EDR evidence** — not found through filters, products or software; not proof of absence
- Westgate Retail: WGR-WS07 (software list holds only OneDrive and the RMM agent)

**AV out of date**
- WGR-WS07 and PCC-WS01 — update definitions and check each device can reach the vendor.

**Last known** (offline over 7 days, never in the verdict)
- 1,340 endpoints at 108 sites: no AV data 1,155 · protected 127 · none detected 29 · out of date 23 · not running 6

**Products seen**
- Windows Defender Antivirus 118 · CrowdStrike Falcon Sensor 13 · Webroot SecureAnywhere 9 · Datto AV 8 · Carbon Black Cloud 4

---

## Data you shouldn't trust
- **Two Macs report online but were last seen 16 Apr 2024** — their state and software lists may be years old.
- **1,155 of 1,347 endpoints (86 %) report no AV data** (`antivirus: {}`); all are last known.
- **Misspelled and generic product names:** "Mcafeee Total Protection", "Endpoint Security".

---

## Coverage

| Area | Status |
|---|---|
| Population filters | All Server O/S, All Desktop O/S, All Laptops, MacOS — complete |
| Protection filters | Datto EDR 41 · Webroot 18 · ESET 2 · 4 more; 10 custom filters read, none names a security product |
| Software spot-checks | 4 of 30 |
| Out of scope | 200 records with no OS, 4 iOS, 3 ESXi |

Account, Europe/Stockholm (from the user) · read-only · Security Coverage Gaps v0.1.15 (alpha)
EDR detection relies on device filters; an agent not covered by a filter shows as no EDR evidence.
````

With `standard_products` set ("our standard is CrowdStrike"), **Not on standard** joins What
else we found with per-site counts — it never changes a rank or the verdict.
